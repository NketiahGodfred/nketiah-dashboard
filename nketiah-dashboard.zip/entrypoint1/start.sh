#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_DIR="$ROOT/.run"
VITE_PORT="${NKJ_VITE_PORT:-5173}"
MOCK_PORT="${NKJ_MT4_PORT:-80}"
FALLBACK_MOCK_PORT=8787
EVENTS_FILE="$ROOT/mt4-integration/local-test-events.jsonl"
TOKEN_FILE="$RUN_DIR/device-token"
VITE_LOG="$RUN_DIR/vite.log"
MOCK_LOG="$RUN_DIR/mock.log"
APP_URL="http://127.0.0.1:${VITE_PORT}/?mt4Local=1"

mkdir -p "$RUN_DIR"
cd "$ROOT"

say() { printf '%s\n' "$*"; }

usage() {
  say "Usage: ./start.sh [start|stop|restart|status|test] [--open]"
  say "  start    (default) start MT4 mock if needed + webapp, verify the account feed"
  say "  stop     stop the webapp (the MT4 mock is left running so the EA stays connected)"
  say "  restart  stop then start"
  say "  status   show whether the mock and webapp are up"
  say "  test     run the Node and Python test suites"
  say "  --open   open the app in the default browser when ready"
}

mock_healthy() {
  curl -fsS -m 2 "http://127.0.0.1:${1}/health" 2>/dev/null | grep -q 'nketiah-mt4-local-test'
}

port_listener_pid() {
  ss -ltnpH "sport = :${1}" 2>/dev/null | grep -oP 'pid=\K[0-9]+' | sort -u | tr '\n' ' '
}

pid_is_vite() {
  [ -r "/proc/${1}/cmdline" ] && tr '\0' ' ' < "/proc/${1}/cmdline" | grep -q 'vite'
}

wait_for() {
  local url="$1" tries="${2:-30}" body
  for _ in $(seq 1 "$tries"); do
    if body="$(curl -fsS -m 2 "$url" 2>/dev/null)"; then printf '%s' "$body"; return 0; fi
    sleep 1
  done
  return 1
}

ensure_token() {
  if [ ! -s "$TOKEN_FILE" ]; then
    umask 077
    python3 -c 'import secrets; print(secrets.token_hex(32))' > "$TOKEN_FILE"
  fi
  cat "$TOKEN_FILE"
}

stop_vite() {
  local pids pid
  pids="$(port_listener_pid "$VITE_PORT")"
  if [ -z "${pids// /}" ]; then return 0; fi
  for pid in $pids; do
    if pid_is_vite "$pid"; then
      kill "$pid" 2>/dev/null || true
    else
      say "! Port ${VITE_PORT} belongs to another process (pid ${pid}); leaving it alone."
      return 1
    fi
  done
  sleep 1
}

start_mock() {
  if mock_healthy "$MOCK_PORT"; then
    say "• MT4 mock already healthy on 127.0.0.1:${MOCK_PORT} — reusing it (EA token stays valid)"
    return 0
  fi
  local target_port="$MOCK_PORT" sudo_cmd=()
  if [ "$MOCK_PORT" = "80" ] && [ "$(id -u)" -ne 0 ]; then
    if [ -n "$(port_listener_pid 80)" ]; then
      say "! Port 80 is used by another service; not touching it."
      say "  The webapp still starts, but the account strip needs the MT4 mock on port 80."
      return 1
    fi
    if sudo -n true 2>/dev/null; then
      sudo_cmd=(sudo -n)
    else
      say "! Port 80 needs root. Re-run as: sudo ./start.sh   (the MT4 EA requires the default HTTP port)"
      say "! Starting the mock on fallback port ${FALLBACK_MOCK_PORT} for the browser feed only."
      target_port="$FALLBACK_MOCK_PORT"
    fi
  fi
  local token
  token="$(ensure_token)"
  touch "$EVENTS_FILE"
  chmod 600 "$EVENTS_FILE"
  ${sudo_cmd[@]+"${sudo_cmd[@]}"} setsid nohup env NJ_MT4_TEST_PORT="$target_port" NJ_MT4_TEST_TOKEN="$token" NJ_MT4_TEST_LOG="$EVENTS_FILE" \
    python3 "$ROOT/mt4-integration/local_test_server.py" >"$MOCK_LOG" 2>&1 </dev/null &
  if wait_for "http://127.0.0.1:${target_port}/health" 10 >/dev/null; then
    MOCK_PORT="$target_port"
    say "• MT4 mock started on 127.0.0.1:${target_port} (log: .run/mock.log)"
  else
    say "! MT4 mock did not become healthy. Tail of .run/mock.log:"
    tail -n 20 "$MOCK_LOG" || true
    return 1
  fi
}

start_vite() {
  stop_vite || return 1
  NKJ_LOCAL_MT4_TARGET="http://127.0.0.1:${MOCK_PORT}" setsid nohup npm run dev:loopback >"$VITE_LOG" 2>&1 </dev/null &
  say "• Starting webapp on http://127.0.0.1:${VITE_PORT} (log: .run/vite.log)"
  if ! wait_for "http://127.0.0.1:${VITE_PORT}/" 30 >/dev/null; then
    say "! Webapp did not answer. Tail of .run/vite.log:"
    tail -n 25 "$VITE_LOG" || true
    return 1
  fi
}

snapshot_values() {
  curl -fsS -m 2 "http://127.0.0.1:${VITE_PORT}/__local_mt4/snapshot" 2>/dev/null | python3 -c '
import json, sys
try:
    data = json.load(sys.stdin).get("account_snapshot") or {}
except Exception:
    data = {}
def field(name):
    value = data.get(name)
    return "—" if value is None else str(value)
print(field("login"), field("server"), field("balance"), field("floating_pl"), field("equity"), field("currency"))
'
}

verify() {
  local health snapshot=""
  health="$(wait_for "http://127.0.0.1:${VITE_PORT}/__local_mt4/health" 15 || true)"
  if ! printf '%s' "$health" | grep -q 'nketiah-mt4-local-test'; then
    say "! MT4 bridge is not reachable through the webapp proxy."
    return 1
  fi
  say "✓ MT4 bridge reachable via http://127.0.0.1:${VITE_PORT}/__local_mt4"
  for _ in $(seq 1 12); do
    snapshot="$(snapshot_values || true)"
    case "$snapshot" in *"—"*) sleep 1 ;; *) break ;; esac
  done
  if [ -n "$snapshot" ] && ! printf '%s' "$snapshot" | grep -q '—'; then
    say "✓ Account snapshot live: $snapshot (login server balance floating_p/l equity currency)"
  else
    say "! No account snapshot yet. Start MetaTrader so the EA can publish one; the strip shows — until then."
  fi
  if curl -fsS -m 5 "http://127.0.0.1:${VITE_PORT}/" 2>/dev/null | grep -q 'app.js'; then
    say "✓ Webapp shell serving app.js"
  else
    say "! Webapp shell did not serve app.js"
    return 1
  fi
}

cmd="start"
open_browser=0
for arg in "$@"; do
  case "$arg" in
    start|stop|restart|status|test) cmd="$arg" ;;
    --open) open_browser=1 ;;
    -h|--help) usage; exit 0 ;;
    *) say "Unknown argument: $arg"; usage; exit 2 ;;
  esac
done

case "$cmd" in
  test)
    npm test
    npm run test:local
    ;;
  status)
    if mock_healthy "$MOCK_PORT"; then say "mock:   healthy on 127.0.0.1:${MOCK_PORT}"; else say "mock:   NOT healthy on 127.0.0.1:${MOCK_PORT}"; fi
    if curl -fsS -m 2 -o /dev/null "http://127.0.0.1:${VITE_PORT}/" 2>/dev/null; then
      say "webapp: up on http://127.0.0.1:${VITE_PORT}"
      say "url:    ${APP_URL}"
    else
      say "webapp: down"
    fi
    ;;
  stop)
    stop_vite || true
    say "• Webapp stopped. MT4 mock left running so the EA stays connected."
    ;;
  restart)
    stop_vite || true
    start_mock || true
    start_vite
    verify || true
    say ""
    say "Ready: ${APP_URL}"
    say "Sign in: nketiah / nketiah@123"
    ;;
  start)
    start_mock || true
    start_vite
    verify || true
    say ""
    say "Ready: ${APP_URL}"
    say "Sign in: nketiah / nketiah@123"
    ;;
esac

if [ "$open_browser" = "1" ] && [ "$cmd" != "stop" ] && [ "$cmd" != "status" ] && [ "$cmd" != "test" ]; then
  xdg-open "$APP_URL" >/dev/null 2>&1 || true
fi
