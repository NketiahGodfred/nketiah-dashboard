//+------------------------------------------------------------------+
//|                                        AccountHistoryCounter.mq4 |
//|                                  Copyright 2026, AI Assistant    |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026"
#property link      "https://www.mql5.com"
#property version   "1.10"
#property strict
#property show_inputs

//+------------------------------------------------------------------+
//| Script (not an EA): drag from Navigator > Scripts onto a chart.   |
//| Read-only: places, modifies, and closes nothing.                  |
//| Uses the whole loaded history: keep Account History = All History.|
//| Results: popup alert + CSV in MQL4/Files + Experts log.           |
//+------------------------------------------------------------------+
input string CsvFileName = "AccountHistory.csv"; // CSV file name (saved in MQL4\Files)

void OnStart()
{
   int totalHistory = OrdersHistoryTotal();

   double totalProfit = 0;
   double totalWin = 0;
   double totalLoss = 0;
   int wins = 0;
   int losses = 0;
   int closedTradesCount = 0;

   int handle = FileOpen(CsvFileName, FILE_WRITE | FILE_CSV | FILE_ANSI, ",");
   if(handle == INVALID_HANDLE)
   {
      Alert("Cannot create CSV file: ", CsvFileName, " error ", GetLastError());
      return;
   }
   FileWrite(handle, "Ticket", "Symbol", "Type", "Lots", "OpenTime", "CloseTime",
             "OpenPrice", "ClosePrice", "Profit", "Swap", "Commission", "NetProfit", "Comment");

   Print("=== STARTING ACCOUNT HISTORY SCAN ===");
   Print("Total items found in loaded history: ", totalHistory);

   for(int i = totalHistory - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_HISTORY))
      {
         int type = OrderType();

         if(type == OP_BUY || type == OP_SELL)
         {
            double profit     = OrderProfit();
            double swap       = OrderSwap();
            double commission = OrderCommission();
            double netProfit  = profit + swap + commission;

            totalProfit += netProfit;
            if(netProfit >= 0) { wins++;     totalWin  += netProfit; }
            else               { losses++;   totalLoss += netProfit; }
            closedTradesCount++;

            FileWrite(handle,
                      OrderTicket(),
                      OrderSymbol(),
                      (type == OP_BUY ? "BUY" : "SELL"),
                      DoubleToString(OrderLots(), 2),
                      TimeToString(OrderOpenTime(), TIME_DATE | TIME_SECONDS),
                      TimeToString(OrderCloseTime(), TIME_DATE | TIME_SECONDS),
                      DoubleToString(OrderOpenPrice(), Digits),
                      DoubleToString(OrderClosePrice(), Digits),
                      DoubleToString(profit, 2),
                      DoubleToString(swap, 2),
                      DoubleToString(commission, 2),
                      DoubleToString(netProfit, 2),
                      OrderComment());
         }
      }
      else
      {
         Print("Failed to select order at index: ", i, " Error: ", GetLastError());
      }
   }
   FileClose(handle);

   double winRate = (wins + losses) > 0 ? 100.0 * wins / (wins + losses) : 0;

   Print("=== ACCOUNT HISTORY SUMMARY ===");
   Print("Total Closed Trades Evaluated: ", closedTradesCount);
   Print("Wins: ", wins, " | Losses: ", losses, " | Win Rate: ", DoubleToString(winRate, 1), "%");
   PrintFormat("Accumulated Net Profit/Loss: %.2f %s", totalProfit, AccountCurrency());

   Alert("Account History Summary\n",
         "Closed trades: ", closedTradesCount, "\n",
         "Wins: ", wins, "  Losses: ", losses, "  Win rate: ", DoubleToString(winRate, 1), "%\n",
         "Total P/L: ", DoubleToString(totalProfit, 2), " ", AccountCurrency(), "\n",
         "CSV saved: MQL4\\Files\\", CsvFileName);
}
//+------------------------------------------------------------------+
