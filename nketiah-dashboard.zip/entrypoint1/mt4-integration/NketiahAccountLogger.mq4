#property strict
#property version   "1.0"
#property description "Read-only Nketiah Journal account event publisher. Never places or closes trades."

// Install on one chart in the MT4 terminal connected to the account to monitor.
// The EA observes all account orders, not only orders opened by this EA.
// It requires the HTTPS ingest host to be allowlisted in Tools > Options > Expert Advisors.

#define OP_BALANCE 6
#define OP_CREDIT 7

input string IngestEndpoint = "https://YOUR_PROJECT_REF.supabase.co/functions/v1/mt4-ingest";
input string DeviceToken = "SET_A_REVOCABLE_TOKEN_HERE";
input int PollSeconds = 5;
input int RequestTimeoutMs = 6000;
input int MaxEventsPerPoll = 10;
input bool LogOrderChanges = true;
input bool LogBalanceEvents = true;

int      g_login = 0;
string   g_server = "";
string   g_company = "";
string   g_account_name = "";
string   g_currency = "";
string   g_prefix = "";
datetime g_setup_time = 0;
int      g_events_this_poll = 0;
int      g_attempts_this_poll = 0;
bool     g_network_failed_this_poll = false;
int      g_poll_seconds = 5;
int      g_max_events_per_poll = 10;
string   g_status = "Starting";
datetime g_last_success = 0;

int HashString32(const string value)
{
   uint hash = 2166136261;
   for(int i=0; i<StringLen(value); i++)
   {
      hash = hash ^ (uint)StringGetCharacter(value, i);
      hash = hash * 16777619;
   }
   return (int)hash;
}

string GlobalPrefix()
{
   return "NKJ_" + IntegerToString(g_login) + "_" + IntegerToString(HashString32(g_server)) + "_";
}

string TimeText(const datetime value)
{
   if(value <= 0) return "";
   return TimeToString(value, TIME_DATE | TIME_SECONDS);
}

string JsonEscape(const string value)
{
   string out = "";
   for(int i=0; i<StringLen(value); i++)
   {
      int ch = StringGetCharacter(value, i);
      if(ch == 34) out += "\\\"";
      else if(ch == 92) out += "\\\\";
      else if(ch == 8) out += "\\b";
      else if(ch == 9) out += "\\t";
      else if(ch == 10) out += "\\n";
      else if(ch == 12) out += "\\f";
      else if(ch == 13) out += "\\r";
      else if(ch < 32) out += " ";
      else if(ch <= 126) out += CharToString((uchar)ch);
      else out += "?"; // Broker comments are normally ASCII; avoid malformed JSON on unusual encodings.
   }
   return out;
}

string JsonString(const string value)
{
   return "\"" + JsonEscape(value) + "\"";
}

string JsonNumber(const double value, const int digits=8)
{
   if(!MathIsValidNumber(value)) return "null";
   return DoubleToString(value, digits);
}

string OrderTypeName(const int orderType)
{
   if(orderType == OP_BUY) return "BUY";
   if(orderType == OP_SELL) return "SELL";
   if(orderType == OP_BUYLIMIT) return "BUY_LIMIT";
   if(orderType == OP_SELLLIMIT) return "SELL_LIMIT";
   if(orderType == OP_BUYSTOP) return "BUY_STOP";
   if(orderType == OP_SELLSTOP) return "SELL_STOP";
   if(orderType == OP_BALANCE) return "BALANCE";
   if(orderType == OP_CREDIT) return "CREDIT";
   return "UNKNOWN";
}

bool IsPendingType(const int orderType)
{
   return (orderType == OP_BUYLIMIT || orderType == OP_SELLLIMIT || orderType == OP_BUYSTOP || orderType == OP_SELLSTOP);
}

bool IsMarketType(const int orderType)
{
   return (orderType == OP_BUY || orderType == OP_SELL);
}

string MakeEventId(const string kind, const int ticket, const datetime eventTime, const double lots, const string extra="")
{
   string material = g_server + "|" + IntegerToString(g_login) + "|" + kind + "|" + IntegerToString(ticket) + "|" +
                     DoubleToString((double)eventTime, 0) + "|" + DoubleToString(lots, 4) + "|" + extra;
   return "nkj_" + IntegerToString(HashString32(g_server)) + "_" + IntegerToString(g_login) + "_" + kind + "_" +
          IntegerToString(ticket) + "_" + DoubleToString((double)eventTime, 0) + "_" + IntegerToString(HashString32(material));
}

string SentFlagKey(const string eventId)
{
   return g_prefix + "sent_" + IntegerToString(HashString32(eventId));
}

bool AlreadySent(const string eventId)
{
   return GlobalVariableCheck(SentFlagKey(eventId));
}

void MarkSent(const string eventId)
{
   GlobalVariableSet(SentFlagKey(eventId), (double)TimeCurrent());
}

bool ContainsCommentToken(const string source, const string token)
{
   string normalized = source;
   StringReplace(normalized, "[", " ");
   StringReplace(normalized, "]", " ");
   StringReplace(normalized, ":", " ");
   StringReplace(normalized, "/", " ");
   StringReplace(normalized, "-", " ");
   StringReplace(normalized, ",", " ");
   StringReplace(normalized, ".", " ");
   StringReplace(normalized, ";", " ");
   StringReplace(normalized, "(", " ");
   StringReplace(normalized, ")", " ");
   StringReplace(normalized, "|", " ");
   StringReplace(normalized, "#", " ");
   StringReplace(normalized, "=", " ");
   StringReplace(normalized, "!", " ");
   StringReplace(normalized, "?", " ");
   string padded = " " + normalized + " ";
   return StringFind(padded, " " + token + " ") >= 0;
}

string ExplicitCloseReason()
{
   // MT4 history has no guaranteed close-reason property. Count TP/SL only when
   // the terminal/broker comment carries an explicit token. If both appear,
   // classify the close as unknown rather than guessing.
   string brokerComment = OrderComment();
   StringToLower(brokerComment);
   StringTrimLeft(brokerComment);
   StringTrimRight(brokerComment);
   bool startsWithTP = brokerComment == "tp" || brokerComment == "[tp]" ||
                       StringFind(brokerComment, "[tp] ") == 0 || StringFind(brokerComment, "[tp]:") == 0 ||
                       brokerComment == "take profit" || StringFind(brokerComment, "tp ") == 0 ||
                       StringFind(brokerComment, "tp:") == 0 || StringFind(brokerComment, "take profit ") == 0 ||
                       StringFind(brokerComment, "take profit:") == 0 || StringFind(brokerComment, "take-profit") == 0;
   bool startsWithSL = brokerComment == "sl" || brokerComment == "[sl]" ||
                       StringFind(brokerComment, "[sl] ") == 0 || StringFind(brokerComment, "[sl]:") == 0 ||
                       brokerComment == "stop loss" || StringFind(brokerComment, "sl ") == 0 ||
                       StringFind(brokerComment, "sl:") == 0 || StringFind(brokerComment, "stop loss ") == 0 ||
                       StringFind(brokerComment, "stop loss:") == 0 || StringFind(brokerComment, "stop-loss") == 0;
   bool mentionsTP = ContainsCommentToken(brokerComment, "tp") ||
                     StringFind(brokerComment, "take profit") >= 0 || StringFind(brokerComment, "take-profit") >= 0;
   bool mentionsSL = ContainsCommentToken(brokerComment, "sl") ||
                     StringFind(brokerComment, "stop loss") >= 0 || StringFind(brokerComment, "stop-loss") >= 0;
   if(mentionsTP && mentionsSL) return "unknown";
   if(startsWithTP) return "tp";
   if(startsWithSL) return "sl";
   return "unknown";
}

double FloatingProfit()
{
   double total = 0.0;
   for(int i=OrdersTotal()-1; i>=0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(!IsMarketType(OrderType())) continue;
      total += OrderProfit() + OrderSwap() + OrderCommission();
   }
   return total;
}

string MakeAccountSnapshotJson(const string eventId, const double floating)
{
   string now = TimeText(TimeCurrent());
   return "{\"event_id\":" + JsonString(eventId) +
          ",\"event_type\":\"account_snapshot\"" +
          ",\"broker_time\":" + JsonString(now) +
          ",\"observed_time\":" + JsonString(now) +
          ",\"account\":{\"login\":" + JsonString(IntegerToString(g_login)) +
          ",\"server\":" + JsonString(g_server) +
          ",\"company\":" + JsonString(g_company) +
          ",\"name\":" + JsonString(g_account_name) +
          ",\"currency\":" + JsonString(g_currency) +
          ",\"balance\":" + JsonNumber(AccountBalance(), 2) +
          ",\"equity\":" + JsonNumber(AccountEquity(), 2) +
          ",\"floating_pl\":" + JsonNumber(floating, 2) +
          ",\"margin\":" + JsonNumber(AccountMargin(), 2) +
          ",\"free_margin\":" + JsonNumber(AccountFreeMargin(), 2) +
          ",\"leverage\":" + IntegerToString(AccountLeverage()) + "}}";
}

bool PostAccountSnapshot()
{
   double floating = FloatingProfit();
   string extra = DoubleToString(AccountBalance(), 2) + "|" + DoubleToString(AccountEquity(), 2) + "|" + DoubleToString(floating, 2);
   // TimeLocal keeps snapshots distinct even if the broker's TimeCurrent has not advanced between timer events.
   string eventId = MakeEventId("snapshot", 0, TimeLocal(), 0.0, extra);
   if(AlreadySent(eventId)) return true;
   return PostJson(MakeAccountSnapshotJson(eventId, floating), eventId);
}

string MakeEventJson(const string eventId, const string eventType, const string brokerTime,
                     const bool hasOrder, const double balanceAmount=0.0)
{
   string json = "{\"event_id\":" + JsonString(eventId) +
                 ",\"event_type\":" + JsonString(eventType) +
                 ",\"broker_time\":" + JsonString(brokerTime) +
                 ",\"observed_time\":" + JsonString(TimeText(TimeCurrent())) +
                 ",\"account\":{\"login\":" + JsonString(IntegerToString(g_login)) +
                 ",\"server\":" + JsonString(g_server) +
                 ",\"company\":" + JsonString(g_company) +
                 ",\"name\":" + JsonString(g_account_name) +
                 ",\"currency\":" + JsonString(g_currency) + "}";

   if(!hasOrder)
   {
      json += ",\"order\":{\"ticket\":0,\"type\":\"SYSTEM\",\"symbol\":\"\",\"side\":\"\",\"lots\":0,\"open_time\":\"\",\"close_time\":\"\",\"open_price\":0,\"close_price\":0,\"stop_loss\":0,\"take_profit\":0,\"profit\":0,\"swap\":0,\"commission\":0,\"net_profit\":0,\"balance_amount\":0,\"magic\":0,\"comment\":\"\",\"expiration\":\"\"}}";
      return json;
   }

   int orderType = OrderType();
   string side = orderType == OP_BUY ? "BUY" : (orderType == OP_SELL ? "SELL" : "");
   datetime brokerTimeValue = OrderCloseTime() > 0 ? OrderCloseTime() : OrderOpenTime();
   string typeName = OrderTypeName(orderType);
   double profit = OrderProfit();
   double swap = OrderSwap();
   double commission = OrderCommission();
   double netProfit = profit + swap + commission;
   string openTime = TimeText(OrderOpenTime());
   string closeTime = TimeText(OrderCloseTime());
   string commentText = OrderComment();
   string closeReason = eventType == "trade_closed" ? ExplicitCloseReason() : "unknown";

   json += ",\"order\":{\"ticket\":" + IntegerToString(OrderTicket()) +
           ",\"type\":" + JsonString(typeName) +
           ",\"symbol\":" + JsonString(OrderSymbol()) +
           ",\"side\":" + JsonString(side) +
           ",\"lots\":" + JsonNumber(OrderLots(), 4) +
           ",\"open_time\":" + JsonString(openTime) +
           ",\"close_time\":" + JsonString(closeTime) +
           ",\"open_price\":" + JsonNumber(OrderOpenPrice(), 8) +
           ",\"close_price\":" + JsonNumber(OrderClosePrice(), 8) +
           ",\"stop_loss\":" + JsonNumber(OrderStopLoss(), 8) +
           ",\"take_profit\":" + JsonNumber(OrderTakeProfit(), 8) +
           ",\"profit\":" + JsonNumber(profit, 2) +
           ",\"swap\":" + JsonNumber(swap, 2) +
           ",\"commission\":" + JsonNumber(commission, 2) +
           ",\"net_profit\":" + JsonNumber(netProfit, 2) +
           ",\"balance_amount\":" + JsonNumber(balanceAmount, 2) +
           ",\"magic\":" + IntegerToString(OrderMagicNumber()) +
           ",\"comment\":" + JsonString(commentText) +
           ",\"close_reason\":" + JsonString(closeReason) +
           ",\"expiration\":" + JsonString(TimeText(OrderExpiration())) + "}}";
   return json;
}

bool PostJson(const string body, const string eventId)
{
   g_attempts_this_poll++;
   if(StringFind(IngestEndpoint, "YOUR_PROJECT_REF") >= 0 || StringLen(DeviceToken) < 24 || DeviceToken == "SET_A_REVOCABLE_TOKEN_HERE")
   {
      g_status = "Set endpoint/token";
      g_network_failed_this_poll = true;
      return false;
   }

   char postData[];
   int copied = StringToCharArray(body, postData, 0, WHOLE_ARRAY, CP_UTF8);
   if(copied <= 1)
   {
      g_status = "Could not encode request";
      return false;
   }
   ArrayResize(postData, copied - 1); // omit the terminal NUL byte

   char response[];
   string responseHeaders = "";
   string headers = "Content-Type: application/json\r\nX-MT4-Token: " + DeviceToken + "\r\n";
   ResetLastError();
   int httpStatus = WebRequest("POST", IngestEndpoint, headers, RequestTimeoutMs, postData, response, responseHeaders);
   int terminalError = GetLastError();
   if(httpStatus < 200 || httpStatus >= 300)
   {
      if(httpStatus == -1) g_status = "WebRequest error " + IntegerToString(terminalError) + " — check URL allowlist/network";
      else g_status = "HTTP " + IntegerToString(httpStatus) + " — check token/service";
      Print("Nketiah MT4 logger: upload failed for ", eventId, "; ", g_status);
      g_network_failed_this_poll = true;
      return false;
   }

   g_last_success = TimeCurrent();
   g_status = "Connected";
   g_events_this_poll++;
   MarkSent(eventId);
   return true;
}

bool PostSelected(const string eventType, const string eventId, const datetime when, const double balanceAmount=0.0)
{
   if(AlreadySent(eventId)) return true;
   string body = MakeEventJson(eventId, eventType, TimeText(when), true, balanceAmount);
   return PostJson(body, eventId);
}

bool PostSystemEvent(const string eventType, const string eventId)
{
   if(AlreadySent(eventId)) return true;
   string body = MakeEventJson(eventId, eventType, TimeText(TimeCurrent()), false, 0.0);
   return PostJson(body, eventId);
}

string StateSignature()
{
   return IntegerToString(OrderType()) + "|" + DoubleToString(OrderLots(), 4) + "|" +
          DoubleToString(OrderOpenPrice(), 8) + "|" + DoubleToString(OrderStopLoss(), 8) + "|" +
          DoubleToString(OrderTakeProfit(), 8) + "|" + DoubleToString((double)OrderExpiration(), 0) + "|" +
          OrderComment();
}

void SaveOrderState(const int ticket, const string signature, const int orderType)
{
   string base = g_prefix + "o_" + IntegerToString(ticket) + "_";
   GlobalVariableSet(base + "sig", (double)HashString32(signature));
   GlobalVariableSet(base + "typ", (double)orderType);
}

void ScanOpenOrders()
{
   for(int i=OrdersTotal()-1; i>=0 && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int type = OrderType();
      if(!IsMarketType(type) && !IsPendingType(type)) continue;

      int ticket = OrderTicket();
      datetime opened = OrderOpenTime();
      string signature = StateSignature();
      int signatureHash = HashString32(signature);
      string stateKey = g_prefix + "o_" + IntegerToString(ticket) + "_sig";
      string typeKey = g_prefix + "o_" + IntegerToString(ticket) + "_typ";
      bool known = GlobalVariableCheck(stateKey);

      if(!known)
      {
         string eventType;
         string idKind;
         if(opened < g_setup_time) { eventType = "order_baseline"; idKind = "base"; }
         else if(IsPendingType(type)) { eventType = "pending_order_placed"; idKind = "pend"; }
         else { eventType = "order_opened"; idKind = "open"; }
         string eventId = MakeEventId(idKind, ticket, opened, OrderLots(), "");
         if(PostSelected(eventType, eventId, opened)) SaveOrderState(ticket, signature, type);
      }
      else
      {
         double oldHash = GlobalVariableGet(stateKey);
         int oldType = GlobalVariableCheck(typeKey) ? (int)GlobalVariableGet(typeKey) : type;
         if((int)oldHash != signatureHash && LogOrderChanges)
         {
            string eventType = (IsPendingType(oldType) && IsMarketType(type)) ? "pending_order_activated" : "order_modified";
            string eventId = MakeEventId("mod", ticket, TimeCurrent(), OrderLots(), IntegerToString(signatureHash));
            if(PostSelected(eventType, eventId, TimeCurrent())) SaveOrderState(ticket, signature, type);
         }
      }
   }
}

void ScanHistory()
{
   int total = OrdersHistoryTotal();
   for(int i=total-1; i>=0 && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int type = OrderType();
      datetime closed = OrderCloseTime();
      datetime opened = OrderOpenTime();

      if(IsMarketType(type) && closed > 0 && closed >= g_setup_time)
      {
         int ticket = OrderTicket();
         double lots = OrderLots();
         if(opened >= g_setup_time && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll)
         {
            string openId = MakeEventId("open", ticket, opened, lots, "");
            if(!AlreadySent(openId)) PostSelected("order_opened", openId, opened);
         }
         if(!g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll)
         {
            string closeId = MakeEventId("close", ticket, closed, lots, DoubleToString(OrderClosePrice(), 8));
            if(!AlreadySent(closeId)) PostSelected("trade_closed", closeId, closed);
         }
      }
      else if(IsPendingType(type) && closed > 0 && closed >= g_setup_time && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll)
      {
         int ticket = OrderTicket();
         string cancelId = MakeEventId("cancel", ticket, closed, OrderLots(), IntegerToString(type));
         if(!AlreadySent(cancelId)) PostSelected("pending_order_cancelled", cancelId, closed);
      }
      else if((type == OP_BALANCE || type == OP_CREDIT) && LogBalanceEvents && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll)
      {
         datetime eventTime = closed > 0 ? closed : opened;
         if(eventTime >= g_setup_time)
         {
            int ticket = OrderTicket();
            double amount = OrderProfit();
            string balanceId = MakeEventId("balance", ticket, eventTime, 0.0, DoubleToString(amount, 2));
            if(!AlreadySent(balanceId)) PostSelected("balance_adjustment", balanceId, eventTime, amount);
         }
      }
   }
}

void UpdateChartStatus()
{
   string last = g_last_success > 0 ? TimeText(g_last_success) : "not yet";
   Comment("Nketiah Journal MT4 logger\n",
           "READ-ONLY · account-wide\n",
           "Status: ", g_status, "\n",
           "Account: ", g_login, " · ", g_server, " · ", g_currency, "\n",
           "Open orders: ", OrdersTotal(), " · History rows loaded: ", OrdersHistoryTotal(), "\n",
           "Last successful upload: ", last, "\n",
           "Setup start (broker time): ", TimeText(g_setup_time));
}

int OnInit()
{
   g_login = AccountNumber();
   g_server = AccountServer();
   g_currency = AccountCurrency();
   g_company = AccountCompany();
   g_account_name = AccountName();
   if(g_login <= 0 || g_server == "" || TimeCurrent() <= 0)
   {
      Print("Nketiah MT4 logger: connect the terminal to the intended account before attaching the EA.");
      return INIT_FAILED;
   }

   g_prefix = GlobalPrefix();
   string setupKey = g_prefix + "setup";
   if(GlobalVariableCheck(setupKey)) g_setup_time = (datetime)GlobalVariableGet(setupKey);
   else
   {
      g_setup_time = TimeCurrent();
      GlobalVariableSet(setupKey, (double)g_setup_time);
   }

   g_poll_seconds = PollSeconds < 5 ? 5 : PollSeconds;
   g_max_events_per_poll = MaxEventsPerPoll < 1 ? 1 : MaxEventsPerPoll;
   if(StringLen(DeviceToken) < 24 || StringFind(IngestEndpoint, "YOUR_PROJECT_REF") >= 0)
   {
      g_status = "Endpoint/token not configured";
      Print("Nketiah MT4 logger: set IngestEndpoint and a revocable DeviceToken in the EA inputs.");
   }

   g_network_failed_this_poll = false;
   if(!EventSetTimer(g_poll_seconds))
   {
      Print("Nketiah MT4 logger: EventSetTimer failed: ", GetLastError());
      return INIT_FAILED;
   }

   string onlineId = MakeEventId("online", 0, TimeCurrent(), 0.0, "startup");
   PostSystemEvent("terminal_online", onlineId);
   PostAccountSnapshot();
   ScanOpenOrders();
   ScanHistory();
   UpdateChartStatus();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   Comment("");
}

void OnTimer()
{
   if(AccountNumber() != g_login || AccountServer() != g_server)
   {
      g_status = "Account changed — remove and reattach EA";
      UpdateChartStatus();
      return;
   }
   g_events_this_poll = 0;
   g_attempts_this_poll = 0;
   g_network_failed_this_poll = false;
   PostAccountSnapshot();
   ScanOpenOrders();
   ScanHistory();
   UpdateChartStatus();
}

void OnTick()
{
   // Deliberately empty: no trade actions, network calls, or per-tick polling.
}
