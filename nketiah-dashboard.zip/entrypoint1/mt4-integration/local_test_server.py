#!/usr/bin/env python3
"""Loopback-only mock of the Nketiah MT4/MT5 ingest endpoint for Wine terminal testing.

This server never connects to Supabase. It accepts one event per POST (MT4 or MT5),
validates its shape and a temporary local token, deduplicates event IDs per account,
tracks dashboard snapshots per (platform, login, server), and writes JSONL to a local
file so the EA's HTTP/JSON behavior can be verified before cloud deployment.
"""
from __future__ import annotations

import hmac
import json
import math
import os
import re
import secrets
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse

MAX_BODY_BYTES = 32 * 1024
PLATFORMS = ('mt4', 'mt5')
EVENT_TYPES = {
    'terminal_online', 'order_baseline', 'order_opened', 'pending_order_placed',
    'pending_order_activated', 'order_modified', 'pending_order_cancelled',
    'trade_closed', 'balance_adjustment', 'account_snapshot'
}
EVENT_ID_RE = re.compile(r'^[A-Za-z0-9_.:-]{8,200}$')
LOGIN_RE = re.compile(r'^[0-9]{1,32}$')
CURRENCY_RE = re.compile(r'^[A-Z]{3}$')


def account_key(platform, login, server):
    return f'{platform}:{login}@{server}'


def normalize_platform(value):
    platform = _text(value, 8).lower()
    if platform and platform not in PLATFORMS:
        raise ValueError('Unsupported platform; expected mt4 or mt5.')
    return platform or 'mt4'


def empty_account_stats():
    return {
        'event_count': 0,
        'trade_close_count': 0,
        'long_close_count': 0,
        'short_close_count': 0,
        'take_profit_count': 0,
        'stop_loss_count': 0,
        'unclassified_close_count': 0
    }


def _text(value, limit=240):
    return value.strip()[:limit] if isinstance(value, str) else ''


def _number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return None
    return float(value)


def explicit_close_reason(raw_reason, comment):
    reason = _text(raw_reason, 20).lower()
    normalized_comment = _text(comment, 120).lower()
    mentions_tp = re.search(r'(?:^|[^a-z0-9])(?:\[tp\]|tp|take[ -]+profit)(?=$|[^a-z0-9])', normalized_comment)
    mentions_sl = re.search(r'(?:^|[^a-z0-9])(?:\[sl\]|sl|stop[ -]+loss)(?=$|[^a-z0-9])', normalized_comment)
    if (mentions_tp and mentions_sl) or (reason == 'tp' and mentions_sl) or (reason == 'sl' and mentions_tp):
        return 'unknown'
    if reason in ('tp', 'sl'):
        return reason
    if re.match(r'^(?:\[tp\]|tp|take[ -]+profit)(?:[\s:]|$)', normalized_comment):
        return 'tp'
    if re.match(r'^(?:\[sl\]|sl|stop[ -]+loss)(?:[\s:]|$)', normalized_comment):
        return 'sl'
    return 'unknown'


def normalize_event(raw):
    if not isinstance(raw, dict):
        raise ValueError('Event must be a JSON object.')
    event_id = _text(raw.get('event_id'), 200)
    if not EVENT_ID_RE.fullmatch(event_id):
        raise ValueError('Invalid event_id.')
    event_type = _text(raw.get('event_type'), 40)
    if event_type not in EVENT_TYPES:
        raise ValueError('Unsupported event_type.')

    account_raw = raw.get('account') if isinstance(raw.get('account'), dict) else {}
    platform = normalize_platform(raw.get('platform') or account_raw.get('platform'))
    account = {
        'platform': platform,
        'login': _text(account_raw.get('login'), 32),
        'server': _text(account_raw.get('server'), 120),
        'company': _text(account_raw.get('company'), 120),
        'name': _text(account_raw.get('name'), 120),
        'currency': _text(account_raw.get('currency'), 3).upper(),
        'balance': _number(account_raw.get('balance')),
        'equity': _number(account_raw.get('equity')),
        'floating_pl': _number(account_raw.get('floating_pl')),
        'margin': _number(account_raw.get('margin')),
        'free_margin': _number(account_raw.get('free_margin')),
        'leverage': account_raw.get('leverage') if isinstance(account_raw.get('leverage'), int) and not isinstance(account_raw.get('leverage'), bool) and account_raw.get('leverage') >= 0 else None
    }
    if not LOGIN_RE.fullmatch(account['login']):
        raise ValueError('Invalid account login.')
    if not account['server']:
        raise ValueError('Account server is required.')
    if not CURRENCY_RE.fullmatch(account['currency']):
        raise ValueError('Invalid account currency.')

    order_raw = raw.get('order') if isinstance(raw.get('order'), dict) else {}
    ticket_raw = order_raw.get('ticket')
    ticket = ticket_raw if isinstance(ticket_raw, int) and not isinstance(ticket_raw, bool) and ticket_raw >= 0 else None
    order = {
        'ticket': ticket,
        'type': _text(order_raw.get('type'), 24).upper(),
        'symbol': _text(order_raw.get('symbol'), 30).upper(),
        'side': _text(order_raw.get('side'), 8).upper(),
        'lots': _number(order_raw.get('lots')),
        'open_time': _text(order_raw.get('open_time'), 40),
        'close_time': _text(order_raw.get('close_time'), 40),
        'open_price': _number(order_raw.get('open_price')),
        'close_price': _number(order_raw.get('close_price')),
        'stop_loss': _number(order_raw.get('stop_loss')),
        'take_profit': _number(order_raw.get('take_profit')),
        'profit': _number(order_raw.get('profit')),
        'swap': _number(order_raw.get('swap')),
        'commission': _number(order_raw.get('commission')),
        'net_profit': _number(order_raw.get('net_profit')),
        'balance_amount': _number(order_raw.get('balance_amount')),
        'magic': order_raw.get('magic') if isinstance(order_raw.get('magic'), int) and not isinstance(order_raw.get('magic'), bool) else None,
        'comment': _text(order_raw.get('comment'), 120),
        'close_reason': explicit_close_reason(order_raw.get('close_reason'), order_raw.get('comment')) if event_type == 'trade_closed' else 'unknown',
        'expiration': _text(order_raw.get('expiration'), 40)
    }
    if event_type not in ('terminal_online', 'account_snapshot') and ticket is None:
        raise ValueError('A non-zero order ticket is required.')
    if order['lots'] is not None and order['lots'] < 0:
        raise ValueError('lots must be non-negative.')
    if event_type == 'trade_closed':
        if not order['symbol'] or order['side'] not in ('BUY', 'SELL'):
            raise ValueError('Closed trade requires symbol and BUY/SELL side.')
        if not order['open_time'] or not order['close_time']:
            raise ValueError('Closed trade requires open_time and close_time.')
        if order['lots'] is None or order['lots'] <= 0 or order['open_price'] is None or order['close_price'] is None or order['net_profit'] is None:
            raise ValueError('Closed trade requires lots, open/close prices, and net_profit.')
    if event_type == 'balance_adjustment' and order['balance_amount'] is None:
        raise ValueError('Balance adjustment requires balance_amount.')
    if event_type == 'account_snapshot' and any(account[key] is None for key in ('balance', 'equity', 'floating_pl')):
        raise ValueError('Account snapshot requires balance, equity, and floating_pl.')

    broker_time = _text(raw.get('broker_time'), 40)
    if not broker_time:
        raise ValueError('broker_time is required.')
    return {
        'event_id': event_id,
        'event_type': event_type,
        'platform': platform,
        'broker_time': broker_time,
        'observed_time': _text(raw.get('observed_time'), 40),
        'account': account,
        'order': order
    }


def build_trade_record(event):
    if event['event_type'] != 'trade_closed':
        return None
    order = event['order']
    platform = event.get('platform') or event['account'].get('platform') or 'mt4'
    close_date = order['close_time'][:10].replace('.', '-')
    safe_id = re.sub(r'[^A-Za-z0-9_-]', '_', event['event_id'])[:176]
    now = datetime.now(timezone.utc).isoformat()
    return {
        'id': platform + '_' + safe_id,
        'createdAt': now,
        'updatedAt': now,
        'closedAt': close_date,
        'openedAt': order['open_time'],
        'brokerCloseTime': order['close_time'],
        'brokerOpenTime': order['open_time'],
        'symbol': order['symbol'],
        'side': order['side'].lower(),
        'pnlUsd': round(order['net_profit'], 2),
        'accountCurrency': event['account']['currency'],
        'lots': order['lots'],
        'entryPrice': order['open_price'],
        'exitPrice': order['close_price'],
        'stopLoss': order['stop_loss'],
        'takeProfit': order['take_profit'],
        'exitReason': order.get('close_reason', 'unknown'),
        'commission': order['commission'],
        'swap': order['swap'],
        'brokerProfit': order['profit'],
        'mt4Ticket': str(order['ticket']),
        'mt4Server': event['account']['server'],
        'mt4Login': event['account']['login'],
        'platform': platform,
        'source': platform,
        'sourceEventId': event['event_id'],
        'followedSop': '',
        'snrTf': '',
        'confirmTf': '',
        'targetPips': None,
        'collectedPips': None,
        'setupId': '',
        'planId': '',
        'notes': '',
        'stages': {'before': [], 'during': [], 'after': []},
        'isDemo': False
    }


class EventStore:
    def __init__(self, path: Path):
        self.path = path
        self.snapshot_path = path.with_name(path.name + '.snapshot.json')
        self.lock = threading.RLock()
        self.events = []
        self.event_ids = set()
        self.trades = []
        self.long_close_count = 0
        self.short_close_count = 0
        self.take_profit_count = 0
        self.stop_loss_count = 0
        self.unclassified_close_count = 0
        self.account_snapshots = {}   # account_key -> latest snapshot payload.
        self.snapshot_event_ids = {}  # account_key -> last snapshot event_id.
        self.account_rows = {}        # account_key -> {platform, login, server, currency}.
        self.account_stats = {}       # account_key -> per-account counters.
        if path.exists():
            for line in path.read_text(encoding='utf-8').splitlines():
                try:
                    event = json.loads(line)
                    self._record_loaded(event)
                except (ValueError, TypeError, json.JSONDecodeError):
                    continue
        self._load_persisted_snapshots()

    def _key_for(self, platform, login, server):
        return account_key(platform or 'mt4', login or '', server or '')

    def _identity_from_event(self, event):
        account = event.get('account') or {}
        platform = event.get('platform') or account.get('platform') or 'mt4'
        login = str(account.get('login') or '')
        server = str(account.get('server') or '')
        return self._key_for(platform, login, server), {
            'platform': platform,
            'login': login,
            'server': server,
            'currency': str(account.get('currency') or '')
        }

    def _stats_for(self, key):
        if key not in self.account_stats:
            self.account_stats[key] = empty_account_stats()
        return self.account_stats[key]

    def _load_persisted_snapshots(self):
        try:
            data = json.loads(self.snapshot_path.read_text(encoding='utf-8'))
        except (OSError, ValueError, TypeError):
            return
        if not isinstance(data, dict):
            return
        if 'balance' in data:
            # Legacy single-account snapshot file → one MT4 account row.
            data = {self._key_for('mt4', str(data.get('login') or ''), str(data.get('server') or '')): data}
        for key, snap in data.items():
            if not isinstance(snap, dict):
                continue
            if snap.get('balance') is None or snap.get('equity') is None or snap.get('floating_pl') is None:
                continue
            self.account_snapshots[str(key)] = snap
            self.snapshot_event_ids[str(key)] = snap.get('event_id') or None

    def _persist_snapshot(self):
        if not self.account_snapshots:
            return
        try:
            temporary = self.snapshot_path.with_name(self.snapshot_path.name + '.tmp')
            temporary.write_text(json.dumps(self.account_snapshots, ensure_ascii=False), encoding='utf-8')
            os.replace(temporary, self.snapshot_path)
        except OSError:
            return

    def _record_loaded(self, event):
        if not isinstance(event, dict) or not event.get('event_id') or event['event_id'] in self.event_ids:
            return
        self.event_ids.add(event['event_id'])
        self.events.append(event)
        key, identity = self._identity_from_event(event)
        self.account_rows.setdefault(key, identity)
        if identity['currency']:
            self.account_rows[key]['currency'] = identity['currency']
        per_account = self._stats_for(key)
        per_account['event_count'] += 1
        trade = build_trade_record(event)
        if trade:
            self.trades.append(trade)
            per_account['trade_close_count'] += 1
            if trade['side'] == 'buy':
                self.long_close_count += 1
                per_account['long_close_count'] += 1
            elif trade['side'] == 'sell':
                self.short_close_count += 1
                per_account['short_close_count'] += 1
            if trade.get('exitReason') == 'tp':
                self.take_profit_count += 1
                per_account['take_profit_count'] += 1
            elif trade.get('exitReason') == 'sl':
                self.stop_loss_count += 1
                per_account['stop_loss_count'] += 1
            else:
                self.unclassified_close_count += 1
                per_account['unclassified_close_count'] += 1

    def append(self, event):
        with self.lock:
            key, identity = self._identity_from_event(event)
            self.account_rows.setdefault(key, identity)
            if identity['currency']:
                self.account_rows[key]['currency'] = identity['currency']
            if event['event_type'] == 'account_snapshot':
                if event['event_id'] == self.snapshot_event_ids.get(key):
                    return {'accepted': True, 'duplicate': True, 'event_id': event['event_id']}
                self.snapshot_event_ids[key] = event['event_id']
                self.account_snapshots[key] = {
                    **event['account'],
                    'platform': identity['platform'],
                    'observed_at': event['observed_time'] or event['broker_time'],
                    'received_at': datetime.now(timezone.utc).isoformat(),
                    'event_id': event['event_id']
                }
                self._persist_snapshot()
                return {'accepted': True, 'duplicate': False, 'event_id': event['event_id'], 'snapshot_only': True}
            if event['event_id'] in self.event_ids:
                return {'accepted': True, 'duplicate': True, 'event_id': event['event_id']}
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open('a', encoding='utf-8') as file:
                file.write(json.dumps(event, separators=(',', ':'), ensure_ascii=False) + '\n')
                file.flush()
                os.fsync(file.fileno())
            self._record_loaded(event)
            return {'accepted': True, 'duplicate': False, 'event_id': event['event_id']}

    def _dashboard_rows(self):
        """One dashboard row per known account, in deterministic key order."""
        rows = []
        for key in sorted(set(self.account_rows) | set(self.account_snapshots)):
            platform, _, remainder = str(key).partition(':')
            login, _, server = remainder.rpartition('@')
            identity = self.account_rows.get(key, {})
            stats = self.account_stats.get(key, empty_account_stats())
            row = {
                'platform': platform or 'mt4',
                'login': login or identity.get('login', ''),
                'server': server or identity.get('server', ''),
                'account_login': login or identity.get('login', ''),
                'account_server': server or identity.get('server', ''),
                'currency': identity.get('currency', ''),
                **stats
            }
            snap = self.account_snapshots.get(key)
            if isinstance(snap, dict):
                for field in ('balance', 'equity', 'floating_pl', 'margin', 'free_margin', 'leverage', 'observed_at', 'received_at', 'event_id'):
                    if field in snap:
                        row[field] = snap[field]
                if snap.get('currency'):
                    row['currency'] = snap['currency']
            rows.append(row)
        return rows

    def snapshot(self):
        with self.lock:
            rows = self._dashboard_rows()
            return {
                'event_count': len(self.events),
                'trade_close_count': len(self.trades),
                'long_close_count': self.long_close_count,
                'short_close_count': self.short_close_count,
                'take_profit_count': self.take_profit_count,
                'stop_loss_count': self.stop_loss_count,
                'unclassified_close_count': self.unclassified_close_count,
                'account_snapshots': rows,
                'account_snapshot': dict(rows[0]) if rows else None,
                'events': list(reversed(self.events[-500:])),
                'trades': list(reversed(self.trades[-500:]))
            }

    def light_snapshot(self):
        """Payload-only snapshot for the fast account-strip poll (no events/trades arrays)."""
        with self.lock:
            rows = self._dashboard_rows()
            return {
                'account_snapshots': rows,
                'account_snapshot': dict(rows[0]) if rows else None,
                'event_count': len(self.events),
                'trade_close_count': len(self.trades),
                'long_close_count': self.long_close_count,
                'short_close_count': self.short_close_count,
                'take_profit_count': self.take_profit_count,
                'stop_loss_count': self.stop_loss_count,
                'unclassified_close_count': self.unclassified_close_count
            }


class RequestHandler(BaseHTTPRequestHandler):
    server_version = 'NketiahMT4LocalTest/1.0'

    def _send_json(self, body, status=200):
        raw = json.dumps(body, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/health':
            return self._send_json({'service': 'nketiah-mt4-local-test', 'status': 'ready'})
        if path == '/events':
            return self._send_json(self.server.event_store.snapshot())
        if path == '/snapshot':
            return self._send_json(self.server.event_store.light_snapshot())
        return self._send_json({'error': 'Not found.'}, 404)

    def do_POST(self):
        if urlparse(self.path).path != '/functions/v1/mt4-ingest':
            return self._send_json({'error': 'Not found.'}, 404)
        supplied = self.headers.get('X-MT4-Token', '')
        if not hmac.compare_digest(supplied, self.server.test_token):
            return self._send_json({'error': 'Unauthorized terminal.'}, 401)
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            return self._send_json({'error': 'Invalid Content-Length.'}, 400)
        if length <= 0 or length > MAX_BODY_BYTES:
            return self._send_json({'error': 'Request is too large or empty.'}, 413)
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                return self._send_json({'error': 'Incomplete request body.'}, 400)
            event = normalize_event(json.loads(raw.decode('utf-8')))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            return self._send_json({'error': str(error) or 'Invalid JSON.'}, 400)
        result = self.server.event_store.append(event)
        return self._send_json({'ok': True, 'result': result})

    def log_message(self, fmt, *args):
        # Do not log headers or request bodies; the temporary token never enters logs.
        print('[local MT4 test]', fmt % args)


def main():
    host = '127.0.0.1'
    # MT4 WebRequest uses the protocol's default port (HTTP 80 / HTTPS 443).
    # Keep port overrides only for mock-server tests, never for the MT4 EA URL.
    port = int(os.environ.get('NJ_MT4_TEST_PORT', '80'))
    token = os.environ.get('NJ_MT4_TEST_TOKEN') or secrets.token_hex(32)
    data_path = Path(os.environ.get('NJ_MT4_TEST_LOG', str(Path(__file__).with_name('local-test-events.jsonl')))).expanduser()
    server = HTTPServer((host, port), RequestHandler)
    server.test_token = token
    server.event_store = EventStore(data_path)
    print('Nketiah Journal local MT4 test server (no cloud connection)')
    print(f'Listening only on http://{host}:{port}')
    print(f'Ingest URL: http://{host}:{port}/functions/v1/mt4-ingest')
    print(f'Health: http://{host}:{port}/health')
    print(f'Local event viewer: http://{host}:{port}/events')
    print('Temporary local DeviceToken (copy into the EA; do not reuse in cloud):')
    print(token)
    print(f'Demo-only events are saved to: {data_path}')
    print('Press Ctrl+C to stop. This server is loopback-only and never connects to Supabase.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopping local MT4 test server.')
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
