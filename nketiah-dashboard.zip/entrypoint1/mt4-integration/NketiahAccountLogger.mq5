#property version   "1.0"
#property description "Read-only Nketiah Journal account event publisher. Never places or closes trades."

// MQL5 (MetaTrader 5) port of NketiahAccountLogger.mq4.
// Install on one chart in the MT5 terminal connected to the account to monitor.
// The EA observes all account positions and orders, not only ones opened by this EA.
// It requires the HTTPS ingest host to be allowlisted in Tools > Options > Expert Advisors.
// Events are published with platform "mt5" so each account keeps its own journal server-side.

input string IngestEndpoint = "https://YOUR_PROJECT_REF.supabase.co/functions/v1/mt4-ingest";
input string DeviceToken = "SET_A_REVOCABLE_TOKEN_HERE";
input int PollSeconds = 5;
input int RequestTimeoutMs = 6000;
input int MaxEventsPerPoll = 10;
input bool LogOrderChanges = true;
input bool LogBalanceEvents = true;

long     g_login = 0;
string   g_server = "";
string   g_company = "";
string   g_account_name = "";
string   g_currency = "";
string   g_prefix = "";
datetime g_setup_time = 0;
int      g_events_this_poll = 0;
int      g_attempts_this_poll = 0;
bool     g_network_failed_this_poll = false;
int      g_poll_seconds = 5;
int      g_max_events_per_poll = 10;
string   g_status = "Starting";
datetime g_last_success = 0;

int HashString32(const string value)
{
   uint hash = 2166136261;
   for(int i=0; i<StringLen(value); i++)
   {
      hash = hash ^ (uint)StringGetCharacter(value, i);
      hash = hash * 16777619;
   }
   return (int)hash;
}

string GlobalPrefix()
{
   return "NKJ5_" + IntegerToString(g_login) + "_" + IntegerToString(HashString32(g_server)) + "_";
}

string TimeText(const datetime value)
{
   if(value <= 0) return "";
   return TimeToString(value, TIME_DATE | TIME_SECONDS);
}

string JsonEscape(const string value)
{
   string out = "";
   for(int i=0; i<StringLen(value); i++)
   {
      int ch = (int)StringGetCharacter(value, i);
      if(ch == 34) out += "\\\"";
      else if(ch == 92) out += "\\\\";
      else if(ch == 8) out += "\\b";
      else if(ch == 9) out += "\\t";
      else if(ch == 10) out += "\\n";
      else if(ch == 12) out += "\\f";
      else if(ch == 13) out += "\\r";
      else if(ch < 32) out += " ";
      else if(ch <= 126) out += CharToString((uchar)ch);
      else out += "?"; // Broker comments are normally ASCII; avoid malformed JSON on unusual encodings.
   }
   return out;
}

string JsonString(const string value)
{
   return "\"" + JsonEscape(value) + "\"";
}

string JsonNumber(const double value, const int digits=8)
{
   if(!MathIsValidNumber(value)) return "null";
   return DoubleToString(value, digits);
}

bool IsPendingOrderType(const long orderType)
{
   return (orderType == ORDER_TYPE_BUY_LIMIT || orderType == ORDER_TYPE_SELL_LIMIT ||
           orderType == ORDER_TYPE_BUY_STOP || orderType == ORDER_TYPE_SELL_STOP);
}

string MakeEventId(const string kind, const long ticket, const datetime eventTime, const double lots, const string extra="")
{
   string material = g_server + "|" + IntegerToString(g_login) + "|" + kind + "|" + IntegerToString(ticket) + "|" +
                     DoubleToString((double)eventTime, 0) + "|" + DoubleToString(lots, 4) + "|" + extra;
   return "nkj5_" + IntegerToString(HashString32(g_server)) + "_" + IntegerToString(g_login) + "_" + kind + "_" +
          IntegerToString(ticket) + "_" + DoubleToString((double)eventTime, 0) + "_" + IntegerToString(HashString32(material));
}

string SentFlagKey(const string eventId)
{
   return g_prefix + "sent_" + IntegerToString(HashString32(eventId));
}

bool AlreadySent(const string eventId)
{
   return GlobalVariableCheck(SentFlagKey(eventId));
}

void MarkSent(const string eventId)
{
   GlobalVariableSet(SentFlagKey(eventId), (double)TimeCurrent());
}

bool ContainsCommentToken(const string source, const string token)
{
   string normalized = source;
   StringReplace(normalized, "[", " ");
   StringReplace(normalized, "]", " ");
   StringReplace(normalized, ":", " ");
   StringReplace(normalized, "/", " ");
   StringReplace(normalized, "-", " ");
   StringReplace(normalized, ",", " ");
   StringReplace(normalized, ".", " ");
   StringReplace(normalized, ";", " ");
   StringReplace(normalized, "(", " ");
   StringReplace(normalized, ")", " ");
   StringReplace(normalized, "|", " ");
   StringReplace(normalized, "#", " ");
   StringReplace(normalized, "=", " ");
   StringReplace(normalized, "!", " ");
   StringReplace(normalized, "?", " ");
   string padded = " " + normalized + " ";
   return StringFind(padded, " " + token + " ") >= 0;
}

string ExplicitCloseReason(const string rawComment)
{
   // MT5 deals expose no guaranteed close-reason property either. Count TP/SL only when
   // the terminal/broker comment carries an explicit token. If both appear,
   // classify the close as unknown rather than guessing.
   string brokerComment = rawComment;
   StringToLower(brokerComment);
   StringTrimLeft(brokerComment);
   StringTrimRight(brokerComment);
   bool startsWithTP = brokerComment == "tp" || brokerComment == "[tp]" ||
                       StringFind(brokerComment, "[tp] ") == 0 || StringFind(brokerComment, "[tp]:") == 0 ||
                       brokerComment == "take profit" || StringFind(brokerComment, "tp ") == 0 ||
                       StringFind(brokerComment, "tp:") == 0 || StringFind(brokerComment, "take profit ") == 0 ||
                       StringFind(brokerComment, "take profit:") == 0 || StringFind(brokerComment, "take-profit") == 0;
   bool startsWithSL = brokerComment == "sl" || brokerComment == "[sl]" ||
                       StringFind(brokerComment, "[sl] ") == 0 || StringFind(brokerComment, "[sl]:") == 0 ||
                       brokerComment == "stop loss" || StringFind(brokerComment, "sl ") == 0 ||
                       StringFind(brokerComment, "sl:") == 0 || StringFind(brokerComment, "stop loss ") == 0 ||
                       StringFind(brokerComment, "stop loss:") == 0 || StringFind(brokerComment, "stop-loss") == 0;
   bool mentionsTP = ContainsCommentToken(brokerComment, "tp") ||
                     StringFind(brokerComment, "take profit") >= 0 || StringFind(brokerComment, "take-profit") >= 0;
   bool mentionsSL = ContainsCommentToken(brokerComment, "sl") ||
                     StringFind(brokerComment, "stop loss") >= 0 || StringFind(brokerComment, "stop-loss") >= 0;
   if(mentionsTP && mentionsSL) return "unknown";
   if(startsWithTP) return "tp";
   if(startsWithSL) return "sl";
   return "unknown";
}

double FloatingProfit()
{
   double total = 0.0;
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      long type = PositionGetInteger(POSITION_TYPE);
      if(type != POSITION_TYPE_BUY && type != POSITION_TYPE_SELL) continue;
      total += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
   }
   return total;
}

string AccountObjectJson()
{
   return "\"login\":" + JsonString(IntegerToString(g_login)) +
          ",\"platform\":\"mt5\"" +
          ",\"server\":" + JsonString(g_server) +
          ",\"company\":" + JsonString(g_company) +
          ",\"name\":" + JsonString(g_account_name) +
          ",\"currency\":" + JsonString(g_currency);
}

string MakeAccountSnapshotJson(const string eventId, const double floating)
{
   string now = TimeText(TimeCurrent());
   return "{\"event_id\":" + JsonString(eventId) +
          ",\"event_type\":\"account_snapshot\"" +
          ",\"platform\":\"mt5\"" +
          ",\"broker_time\":" + JsonString(now) +
          ",\"observed_time\":" + JsonString(now) +
          ",\"account\":{" + AccountObjectJson() +
          ",\"balance\":" + JsonNumber(AccountInfoDouble(ACCOUNT_BALANCE), 2) +
          ",\"equity\":" + JsonNumber(AccountInfoDouble(ACCOUNT_EQUITY), 2) +
          ",\"floating_pl\":" + JsonNumber(floating, 2) +
          ",\"margin\":" + JsonNumber(AccountInfoDouble(ACCOUNT_MARGIN), 2) +
          ",\"free_margin\":" + JsonNumber(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) +
          ",\"leverage\":" + IntegerToString((int)AccountInfoInteger(ACCOUNT_LEVERAGE)) + "}}";
}

bool PostAccountSnapshot()
{
   double floating = FloatingProfit();
   string extra = DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2) + "|" +
                  DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + "|" + DoubleToString(floating, 2);
   // TimeLocal keeps snapshots distinct even if the broker's TimeCurrent has not advanced between timer events.
   string eventId = MakeEventId("snapshot", 0, TimeLocal(), 0.0, extra);
   if(AlreadySent(eventId)) return true;
   return PostJson(MakeAccountSnapshotJson(eventId, floating), eventId);
}

bool PostJson(const string body, const string eventId)
{
   g_attempts_this_poll++;
   if(StringFind(IngestEndpoint, "YOUR_PROJECT_REF") >= 0 || StringLen(DeviceToken) < 24 || DeviceToken == "SET_A_REVOCABLE_TOKEN_HERE")
   {
      g_status = "Set endpoint/token";
      g_network_failed_this_poll = true;
      return false;
   }

   char postData[];
   int copied = StringToCharArray(body, postData, 0, WHOLE_ARRAY, CP_UTF8);
   if(copied <= 1)
   {
      g_status = "Could not encode request";
      return false;
   }
   ArrayResize(postData, copied - 1); // omit the terminal NUL byte

   char response[];
   string responseHeaders = "";
   string headers = "Content-Type: application/json\r\nX-MT4-Token: " + DeviceToken + "\r\n";
   ResetLastError();
   int httpStatus = WebRequest("POST", IngestEndpoint, headers, RequestTimeoutMs, postData, response, responseHeaders);
   int terminalError = GetLastError();
   if(httpStatus < 200 || httpStatus >= 300)
   {
      if(httpStatus == -1) g_status = "WebRequest error " + IntegerToString(terminalError) + " — check URL allowlist/network";
      else g_status = "HTTP " + IntegerToString(httpStatus) + " — check token/service";
      Print("Nketiah MT5 logger: upload failed for ", eventId, "; ", g_status);
      g_network_failed_this_poll = true;
      return false;
   }

   g_last_success = TimeCurrent();
   g_status = "Connected";
   g_events_this_poll++;
   MarkSent(eventId);
   return true;
}

string MakeEventJson(const string eventId, const string eventType, const string brokerTime,
                     const bool hasPosition, const long ticket=0, const string typeName="SYSTEM",
                     const string symbol="", const string side="", const double lots=0.0,
                     const datetime openTime=0, const datetime closeTime=0,
                     const double openPrice=0.0, const double closePrice=0.0,
                     const double stopLoss=0.0, const double takeProfit=0.0,
                     const double profit=0.0, const double swap=0.0, const double commission=0.0,
                     const double netProfit=0.0, const double balanceAmount=0.0,
                     const long magic=0, const string comment="", const string closeReason="unknown",
                     const datetime expiration=0)
{
   string json = "{\"event_id\":" + JsonString(eventId) +
                 ",\"event_type\":" + JsonString(eventType) +
                 ",\"platform\":\"mt5\"" +
                 ",\"broker_time\":" + JsonString(brokerTime) +
                 ",\"observed_time\":" + JsonString(TimeText(TimeCurrent())) +
                 ",\"account\":{" + AccountObjectJson() + "}";

   if(!hasPosition)
   {
      json += ",\"order\":{\"ticket\":0,\"type\":\"SYSTEM\",\"symbol\":\"\",\"side\":\"\",\"lots\":0,\"open_time\":\"\",\"close_time\":\"\",\"open_price\":0,\"close_price\":0,\"stop_loss\":0,\"take_profit\":0,\"profit\":0,\"swap\":0,\"commission\":0,\"net_profit\":0,\"balance_amount\":0,\"magic\":0,\"comment\":\"\",\"close_reason\":\"unknown\",\"expiration\":\"\"}}";
      return json;
   }

   json += ",\"order\":{\"ticket\":" + IntegerToString(ticket) +
           ",\"type\":" + JsonString(typeName) +
           ",\"symbol\":" + JsonString(symbol) +
           ",\"side\":" + JsonString(side) +
           ",\"lots\":" + JsonNumber(lots, 4) +
           ",\"open_time\":" + JsonString(TimeText(openTime)) +
           ",\"close_time\":" + JsonString(TimeText(closeTime)) +
           ",\"open_price\":" + JsonNumber(openPrice, 8) +
           ",\"close_price\":" + JsonNumber(closePrice, 8) +
           ",\"stop_loss\":" + JsonNumber(stopLoss, 8) +
           ",\"take_profit\":" + JsonNumber(takeProfit, 8) +
           ",\"profit\":" + JsonNumber(profit, 2) +
           ",\"swap\":" + JsonNumber(swap, 2) +
           ",\"commission\":" + JsonNumber(commission, 2) +
           ",\"net_profit\":" + JsonNumber(netProfit, 2) +
           ",\"balance_amount\":" + JsonNumber(balanceAmount, 2) +
           ",\"magic\":" + IntegerToString(magic) +
           ",\"comment\":" + JsonString(comment) +
           ",\"close_reason\":" + JsonString(closeReason) +
           ",\"expiration\":" + JsonString(TimeText(expiration)) + "}}";
   return json;
}

bool PostPositionEvent(const string eventType, const string eventId, const datetime when)
{
   if(AlreadySent(eventId)) return true;
   long type = PositionGetInteger(POSITION_TYPE);
   string side = type == POSITION_TYPE_BUY ? "BUY" : "SELL";
   double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
   datetime opened = (datetime)PositionGetInteger(POSITION_TIME);
   string body = MakeEventJson(eventId, eventType, TimeText(when), true,
                               PositionGetInteger(POSITION_TICKET),
                               side, PositionGetString(POSITION_SYMBOL), side,
                               PositionGetDouble(POSITION_VOLUME),
                               opened, 0, openPrice, 0.0,
                               PositionGetDouble(POSITION_SL), PositionGetDouble(POSITION_TP),
                               PositionGetDouble(POSITION_PROFIT), PositionGetDouble(POSITION_SWAP), 0.0,
                               PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP), 0.0,
                               PositionGetInteger(POSITION_MAGIC), PositionGetString(POSITION_COMMENT),
                               "unknown", 0);
   return PostJson(body, eventId);
}

bool PostPendingOrderEvent(const string eventType, const string eventId, const datetime when)
{
   if(AlreadySent(eventId)) return true;
   long type = OrderGetInteger(ORDER_TYPE);
   string side = (type == ORDER_TYPE_BUY_LIMIT || type == ORDER_TYPE_BUY_STOP) ? "BUY" : "SELL";
   string typeName = type == ORDER_TYPE_BUY_LIMIT ? "BUY_LIMIT" : type == ORDER_TYPE_SELL_LIMIT ? "SELL_LIMIT" :
                     type == ORDER_TYPE_BUY_STOP ? "BUY_STOP" : type == ORDER_TYPE_SELL_STOP ? "SELL_STOP" : "UNKNOWN";
   datetime setup = (datetime)OrderGetInteger(ORDER_TIME_SETUP);
   datetime expiration = (datetime)OrderGetInteger(ORDER_TIME_EXPIRATION);
   string body = MakeEventJson(eventId, eventType, TimeText(when), true,
                               OrderGetInteger(ORDER_TICKET), typeName,
                               OrderGetString(ORDER_SYMBOL), side,
                               OrderGetDouble(ORDER_VOLUME_CURRENT),
                               setup, 0,
                               OrderGetDouble(ORDER_PRICE_OPEN), 0.0,
                               OrderGetDouble(ORDER_SL), OrderGetDouble(ORDER_TP),
                               0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                               OrderGetInteger(ORDER_MAGIC), OrderGetString(ORDER_COMMENT),
                               "unknown", expiration);
   return PostJson(body, eventId);
}

bool PostHistoryDeal(const string eventType, const string eventId, const datetime when)
{
   if(AlreadySent(eventId)) return true;
   long entry = DealGetInteger(DEAL_ENTRY);
   long dealType = DealGetInteger(DEAL_TYPE);
   bool isBalance = (dealType == DEAL_TYPE_BALANCE || dealType == DEAL_TYPE_CREDIT);
   double profit = DealGetDouble(DEAL_PROFIT);
   double swap = DealGetDouble(DEAL_SWAP);
   double commission = DealGetDouble(DEAL_COMMISSION);
   double netProfit = profit + swap + commission;
   string comment = DealGetString(DEAL_COMMENT);
   string closeReason = eventType == "trade_closed" ? ExplicitCloseReason(comment) : "unknown";
   // MT5 reports closing deals in the opposite direction of the position, while MT4
   // history kept the original order direction. Invert out-deals so journal long/short
   // counts match the direction the position was actually opened with.
   string side;
   if(isBalance) side = "";
   else if(entry == DEAL_ENTRY_IN) side = dealType == DEAL_TYPE_BUY ? "BUY" : "SELL";
   else side = dealType == DEAL_TYPE_BUY ? "SELL" : "BUY";
   string typeName = isBalance ? (dealType == DEAL_TYPE_CREDIT ? "CREDIT" : "BALANCE") : side;
   string symbol = DealGetString(DEAL_SYMBOL);
   double lots = DealGetDouble(DEAL_VOLUME);
   datetime dealTime = (datetime)DealGetInteger(DEAL_TIME);
   long magic = DealGetInteger(DEAL_MAGIC);
   double price = DealGetDouble(DEAL_PRICE);

   long linkedOrder = DealGetInteger(DEAL_ORDER);
   datetime openTime = dealTime;
   double openPrice = 0.0;
   if(HistoryOrderSelect(linkedOrder))
   {
      openTime = (datetime)HistoryOrderGetInteger(linkedOrder, ORDER_TIME_DONE);
      openPrice = HistoryOrderGetDouble(linkedOrder, ORDER_PRICE_OPEN);
   }

   string body = MakeEventJson(eventId, eventType, TimeText(when), true,
                               DealGetInteger(DEAL_TICKET), typeName, symbol, side, lots,
                               openTime, eventType == "trade_closed" ? dealTime : 0,
                               openPrice, price,
                               0.0, 0.0,
                               profit, swap, commission, netProfit,
                               eventType == "balance_adjustment" ? profit : 0.0,
                               magic, comment, closeReason, 0);
   return PostJson(body, eventId);
}

bool PostSystemEvent(const string eventType, const string eventId)
{
   if(AlreadySent(eventId)) return true;
   string body = MakeEventJson(eventId, eventType, TimeText(TimeCurrent()), false);
   return PostJson(body, eventId);
}

string PositionStateSignature()
{
   return IntegerToString(PositionGetInteger(POSITION_TYPE)) + "|" + DoubleToString(PositionGetDouble(POSITION_VOLUME), 4) + "|" +
          DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), 8) + "|" + DoubleToString(PositionGetDouble(POSITION_SL), 8) + "|" +
          DoubleToString(PositionGetDouble(POSITION_TP), 8);
}

void SavePositionState(const long ticket, const string signature)
{
   string base = g_prefix + "p_" + IntegerToString(ticket) + "_";
   GlobalVariableSet(base + "sig", (double)HashString32(signature));
}

void ScanOpenPositions()
{
   for(int i=PositionsTotal()-1; i>=0 && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      long type = PositionGetInteger(POSITION_TYPE);
      if(type != POSITION_TYPE_BUY && type != POSITION_TYPE_SELL) continue;

      datetime opened = (datetime)PositionGetInteger(POSITION_TIME);
      string signature = PositionStateSignature();
      int signatureHash = HashString32(signature);
      string stateKey = g_prefix + "p_" + IntegerToString((long)ticket) + "_sig";
      bool known = GlobalVariableCheck(stateKey);

      if(!known)
      {
         string eventType = opened < g_setup_time ? "order_baseline" : "order_opened";
         string idKind = opened < g_setup_time ? "base" : "open";
         string eventId = MakeEventId(idKind, (long)ticket, opened, PositionGetDouble(POSITION_VOLUME), "");
         if(PostPositionEvent(eventType, eventId, opened)) SavePositionState((long)ticket, signature);
      }
      else if(LogOrderChanges)
      {
         double oldHash = GlobalVariableGet(stateKey);
         if((int)oldHash != signatureHash)
         {
            string eventId = MakeEventId("mod", (long)ticket, TimeCurrent(), PositionGetDouble(POSITION_VOLUME), IntegerToString(signatureHash));
            if(PostPositionEvent("order_modified", eventId, TimeCurrent())) SavePositionState((long)ticket, signature);
         }
      }
   }
}

void ScanPendingOrders()
{
   for(int i=OrdersTotal()-1; i>=0 && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll; i--)
   {
      ulong ticket = OrdersGetTicket(i);
      if(ticket == 0) continue;
      if(!OrderSelect(ticket)) continue;
      long type = OrderGetInteger(ORDER_TYPE);
      if(!IsPendingOrderType(type)) continue;

      datetime setup = (datetime)OrderGetInteger(ORDER_TIME_SETUP);
      string base = g_prefix + "o_" + IntegerToString((long)ticket) + "_";
      string sigKey = base + "sig";
      string typeKey = base + "typ";
      string signature = IntegerToString(type) + "|" + DoubleToString(OrderGetDouble(ORDER_VOLUME_CURRENT), 4) + "|" +
                         DoubleToString(OrderGetDouble(ORDER_PRICE_OPEN), 8) + "|" + DoubleToString(OrderGetDouble(ORDER_SL), 8) + "|" +
                         DoubleToString(OrderGetDouble(ORDER_TP), 8);
      int signatureHash = HashString32(signature);
      bool known = GlobalVariableCheck(sigKey);

      if(!known)
      {
         string idKind = setup < g_setup_time ? "base" : "pend";
         string eventId = MakeEventId(idKind, (long)ticket, setup, OrderGetDouble(ORDER_VOLUME_CURRENT), "");
         if(PostPendingOrderEvent(setup < g_setup_time ? "order_baseline" : "pending_order_placed", eventId, setup))
         {
            GlobalVariableSet(sigKey, (double)signatureHash);
            GlobalVariableSet(typeKey, (double)type);
         }
      }
      else if(LogOrderChanges)
      {
         double oldHash = GlobalVariableGet(sigKey);
         int oldType = GlobalVariableCheck(typeKey) ? (int)GlobalVariableGet(typeKey) : (int)type;
         if((int)oldHash != signatureHash)
         {
            string eventId = MakeEventId("mod", (long)ticket, TimeCurrent(), OrderGetDouble(ORDER_VOLUME_CURRENT), IntegerToString(signatureHash));
            string eventType = oldType != type && IsPendingOrderType(oldType) ? "pending_order_activated" : "order_modified";
            if(PostPendingOrderEvent(eventType, eventId, TimeCurrent()))
            {
               GlobalVariableSet(sigKey, (double)signatureHash);
               GlobalVariableSet(typeKey, (double)type);
            }
         }
      }
   }
}

void ScanHistory()
{
   if(!HistorySelect(0, TimeCurrent())) return;
   int dealTotal = HistoryDealsTotal();
   for(int i=dealTotal-1; i>=0 && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll; i--)
   {
      ulong dealTicket = HistoryDealGetTicket(i);
      if(dealTicket == 0) continue;
      long entry = DealGetInteger(DEAL_ENTRY);
      long dealType = DealGetInteger(DEAL_TYPE);
      datetime dealTime = (datetime)DealGetInteger(DEAL_TIME);
      if(dealTime < g_setup_time) continue;

      if(dealType == DEAL_TYPE_BALANCE || dealType == DEAL_TYPE_CREDIT)
      {
         if(!LogBalanceEvents) continue;
         double amount = DealGetDouble(DEAL_PROFIT);
         string balanceId = MakeEventId("balance", (long)dealTicket, dealTime, 0.0, DoubleToString(amount, 2));
         if(!AlreadySent(balanceId)) PostHistoryDeal("balance_adjustment", balanceId, dealTime);
      }
      else if(entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_INOUT || entry == DEAL_ENTRY_OUT_BY)
      {
         double lots = DealGetDouble(DEAL_VOLUME);
         string closeId = MakeEventId("close", (long)dealTicket, dealTime, lots, DoubleToString(DealGetDouble(DEAL_PRICE), 8));
         if(!AlreadySent(closeId)) PostHistoryDeal("trade_closed", closeId, dealTime);
      }
      else if(entry == DEAL_ENTRY_IN && dealTime >= g_setup_time)
      {
         long linkedOrder = DealGetInteger(DEAL_ORDER);
         bool fromPending = HistoryOrderSelect(linkedOrder) && IsPendingOrderType(HistoryOrderGetInteger(linkedOrder, ORDER_TYPE));
         string idKind = fromPending ? "act" : "open";
         string eventId = MakeEventId(idKind, (long)dealTicket, dealTime, DealGetDouble(DEAL_VOLUME), "");
         if(!AlreadySent(eventId)) PostHistoryDeal(fromPending ? "pending_order_activated" : "order_opened", eventId, dealTime);
      }
   }

   int orderTotal = HistoryOrdersTotal();
   for(int i=orderTotal-1; i>=0 && !g_network_failed_this_poll && g_attempts_this_poll<g_max_events_per_poll; i--)
   {
      ulong orderTicket = HistoryOrderGetTicket(i);
      if(orderTicket == 0) continue;
      if(!HistoryOrderSelect(orderTicket)) continue;
      long type = HistoryOrderGetInteger(ORDER_TYPE);
      if(!IsPendingOrderType(type)) continue;
      long state = HistoryOrderGetInteger(ORDER_STATE);
      if(state != ORDER_STATE_CANCELED && state != ORDER_STATE_EXPIRED && state != ORDER_STATE_REJECTED) continue;
      datetime done = (datetime)HistoryOrderGetInteger(ORDER_TIME_DONE);
      if(done < g_setup_time) continue;
      string cancelId = MakeEventId("cancel", (long)orderTicket, done, HistoryOrderGetDouble(ORDER_VOLUME_CURRENT), IntegerToString(type));
      if(AlreadySent(cancelId)) continue;
      {
         string side = (type == ORDER_TYPE_BUY_LIMIT || type == ORDER_TYPE_BUY_STOP) ? "BUY" : "SELL";
         string typeName = type == ORDER_TYPE_BUY_LIMIT ? "BUY_LIMIT" : type == ORDER_TYPE_SELL_LIMIT ? "SELL_LIMIT" :
                           type == ORDER_TYPE_BUY_STOP ? "BUY_STOP" : type == ORDER_TYPE_SELL_STOP ? "SELL_STOP" : "UNKNOWN";
         datetime setup = (datetime)HistoryOrderGetInteger(ORDER_TIME_SETUP);
         string body = MakeEventJson(cancelId, "pending_order_cancelled", TimeText(done), true,
                                     HistoryOrderGetInteger(ORDER_TICKET), typeName,
                                     HistoryOrderGetString(ORDER_SYMBOL), side,
                                     HistoryOrderGetDouble(ORDER_VOLUME_CURRENT),
                                     setup, done,
                                     HistoryOrderGetDouble(ORDER_PRICE_OPEN), HistoryOrderGetDouble(ORDER_PRICE_CURRENT),
                                     HistoryOrderGetDouble(ORDER_SL), HistoryOrderGetDouble(ORDER_TP),
                                     0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                     HistoryOrderGetInteger(ORDER_MAGIC), HistoryOrderGetString(ORDER_COMMENT),
                                     "unknown", (datetime)HistoryOrderGetInteger(ORDER_TIME_EXPIRATION));
         PostJson(body, cancelId);
      }
   }
}

void UpdateChartStatus()
{
   string last = g_last_success > 0 ? TimeText(g_last_success) : "not yet";
   Comment("Nketiah Journal MT5 logger\n",
           "READ-ONLY · account-wide · platform mt5\n",
           "Status: ", g_status, "\n",
           "Account: ", g_login, " · ", g_server, " · ", g_currency, "\n",
           "Open positions: ", PositionsTotal(), " · Pending orders: ", OrdersTotal(),
           " · History deals loaded: ", HistoryDealsTotal(), "\n",
           "Last successful upload: ", last, "\n",
           "Setup start (broker time): ", TimeText(g_setup_time));
}

int OnInit()
{
   g_login = AccountInfoInteger(ACCOUNT_LOGIN);
   g_server = AccountInfoString(ACCOUNT_SERVER);
   g_currency = AccountInfoString(ACCOUNT_CURRENCY);
   g_company = AccountInfoString(ACCOUNT_COMPANY);
   g_account_name = AccountInfoString(ACCOUNT_NAME);
   if(g_login <= 0 || g_server == "" || TimeCurrent() <= 0)
   {
      Print("Nketiah MT5 logger: connect the terminal to the intended account before attaching the EA.");
      return INIT_FAILED;
   }

   g_prefix = GlobalPrefix();
   string setupKey = g_prefix + "setup";
   if(GlobalVariableCheck(setupKey)) g_setup_time = (datetime)GlobalVariableGet(setupKey);
   else
   {
      g_setup_time = TimeCurrent();
      GlobalVariableSet(setupKey, (double)g_setup_time);
   }

   g_poll_seconds = PollSeconds < 5 ? 5 : PollSeconds;
   g_max_events_per_poll = MaxEventsPerPoll < 1 ? 1 : MaxEventsPerPoll;
   if(StringLen(DeviceToken) < 24 || StringFind(IngestEndpoint, "YOUR_PROJECT_REF") >= 0)
   {
      g_status = "Endpoint/token not configured";
      Print("Nketiah MT5 logger: set IngestEndpoint and a revocable DeviceToken in the EA inputs.");
   }

   g_network_failed_this_poll = false;
   if(!EventSetTimer(g_poll_seconds))
   {
      Print("Nketiah MT5 logger: EventSetTimer failed: ", GetLastError());
      return INIT_FAILED;
   }

   HistorySelect(0, TimeCurrent());
   string onlineId = MakeEventId("online", 0, TimeCurrent(), 0.0, "startup");
   PostSystemEvent("terminal_online", onlineId);
   PostAccountSnapshot();
   ScanOpenPositions();
   ScanPendingOrders();
   ScanHistory();
   UpdateChartStatus();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   Comment("");
}

void OnTimer()
{
   if(AccountInfoInteger(ACCOUNT_LOGIN) != g_login || AccountInfoString(ACCOUNT_SERVER) != g_server)
   {
      g_status = "Account changed — remove and reattach EA";
      UpdateChartStatus();
      return;
   }
   g_events_this_poll = 0;
   g_attempts_this_poll = 0;
   g_network_failed_this_poll = false;
   PostAccountSnapshot();
   ScanOpenPositions();
   ScanPendingOrders();
   ScanHistory();
   UpdateChartStatus();
}

void OnTick()
{
   // Deliberately empty: no trade actions, network calls, or per-tick polling.
}
