# MT4 integration test status

## Passed in the workspace

- `npm test`: **17 tests passed**. Coverage includes MT4 event validation, closed-trade mapping, separate partial-close records, balance-event separation, missing/invalid device tokens, malformed/oversized requests, generic server errors, owner-only/RLS migration policy text, the observer-only EA, and static checks for local one-second polling, hidden ticket/cancellation rows, trade-direction counts, and the feed-status indicator.
- `npm run test:local`: **3 tests passed** against the loopback mock server. It accepted a valid token, rejected a bad token, deduplicated a replay across a simulated restart, mapped close records, counted BUY/SELL close records separately, and kept balance events outside trade totals.
- Local Journal UI bridge smoke test: the loopback-only Vite preview served the opt-in journal page and proxied a mock closed BUY event to the UI API, which reported 1 total close / 1 long / 0 short. This verifies the route/proxy and summary data, not a real browser click-through or MetaTrader runtime.
- Direct CLI smoke test on a temporary loopback port: the actual server process started, `/health` returned 200, a token-authenticated ingest returned 200, and `/events` returned one event/one mapped close. This exercised the Python HTTP harness only—not MT4; a nonstandard port such as 8787 is not usable by MQL4 `WebRequest`. The documented MT4 local test now binds to HTTP port 80, with an elevated local-only server process.
- `node --check`: app shell, production bootstrap, event contract, handler, and test modules passed syntax checking.
- `npm run build`: production Vite build passed. The build excludes the demo `index.html`, the demo credential string, and the EA token placeholder.
- Edge Function source: esbuild transpilation and Node syntax check passed.
- Migration: PostgreSQL parser accepted the outer SQL DDL/function declaration syntax.

## User-side demo evidence (partial)

- The owner shared a local `/events` screenshot showing **14 events and 3 close records**, including a pending-order-cancel event. The same MT4 screenshot still displayed WebRequest error 4060 at that moment; confirm a fresh server-side POST 200 and compare the three trade rows against Account History before treating local connectivity/data mapping as fully accepted.

## Not yet passed (requires the owner's live environment)

- Deno/Supabase Edge Function type-check and deployment.
- Running the PL/pgSQL body against the actual Supabase schema and owner allowlist.
- Compiling `NketiahAccountLogger.mq4` in the user's MetaEditor under Linux/Wine.
- HTTPS POST from that MT4 build through Wine to the deployed Edge Function.
- Actual broker-demo order history, partial-close ticket behavior, pending orders, balance rows, offline catch-up, and owner-isolation tests.

These are not workspace-test failures; the sandbox has no connected Supabase project, Supabase CLI/Deno, MetaEditor, or broker account. Do not treat the feature as production-ready until the remaining demo acceptance cases in [`README.md`](./README.md) pass.
