import test from 'node:test';
import assert from 'node:assert/strict';
import { buildJournalTrade, normalizeMt4Event } from '../../supabase/functions/mt4-ingest/contract.mjs';

const base = {
  event_id: 'nkj_demo_12345_close_67890',
  event_type: 'trade_closed',
  broker_time: '2026.10.13 10:20:30',
  observed_time: '2026.10.13 10:20:35',
  account: { login: '1234567', server: 'Broker-Demo', currency: 'USD' },
  order: {
    ticket: 67890, type: 'BUY', symbol: 'EURUSD', side: 'BUY', lots: 0.1,
    open_time: '2026.10.13 09:00:00', close_time: '2026.10.13 10:20:30',
    open_price: 1.16, close_price: 1.162, stop_loss: 1.155, take_profit: 1.17,
    profit: 20, swap: -0.2, commission: -0.7, net_profit: 19.1,
    balance_amount: 0, magic: 0, comment: 'manual close', expiration: ''
  }
};

test('only explicit terminal close labels count as TP or SL; ambiguous comments stay unknown', () => {
  const tp = normalizeMt4Event({ ...base, order: { ...base.order, close_reason: 'TP' } });
  const sl = normalizeMt4Event({ ...base, event_id: 'nkj_demo_12345_close_67891', order: { ...base.order, close_reason: 'sl', comment: '[SL] 1.155' } });
  const legacyComment = normalizeMt4Event({ ...base, event_id: 'nkj_demo_12345_close_67892', order: { ...base.order, comment: 'TP: 1.170' } });
  const nonPrefixComment = normalizeMt4Event({ ...base, event_id: 'nkj_demo_12345_close_67893', order: { ...base.order, comment: 'manual TP discussion' } });
  const ambiguous = normalizeMt4Event({ ...base, event_id: 'nkj_demo_12345_close_67894', order: { ...base.order, close_reason: 'tp', comment: 'TP 1.170 / SL 1.155' } });
  const conflict = normalizeMt4Event({ ...base, event_id: 'nkj_demo_12345_close_67895', order: { ...base.order, close_reason: 'sl', comment: 'TP 1.170' } });
  assert.equal(tp.order.close_reason, 'tp');
  assert.equal(sl.order.close_reason, 'sl');
  assert.equal(legacyComment.order.close_reason, 'tp');
  assert.equal(nonPrefixComment.order.close_reason, 'unknown');
  assert.equal(ambiguous.order.close_reason, 'unknown');
  assert.equal(conflict.order.close_reason, 'unknown');
});

test('separate partial-close events remain separate journal records with their own reason and currency', () => {
  const first = normalizeMt4Event(base);
  const second = normalizeMt4Event({
    ...base,
    event_id: 'nkj_demo_12345_close_67890_partial_2',
    broker_time: '2026.10.13 10:22:30',
    order: { ...base.order, lots: 0.05, close_time: '2026.10.13 10:22:30', close_price: 1.163, net_profit: 9.4, close_reason: 'unknown' }
  });
  const firstTrade = buildJournalTrade(first, '2026-10-13T10:21:00.000Z');
  const secondTrade = buildJournalTrade(second, '2026-10-13T10:23:00.000Z');
  assert.notEqual(firstTrade.id, secondTrade.id);
  assert.equal(firstTrade.mt4Ticket, secondTrade.mt4Ticket);
  assert.equal(firstTrade.exitReason, 'unknown');
  assert.equal(secondTrade.lots, 0.05);
  assert.equal(secondTrade.pnlUsd, 9.4);
  assert.equal(secondTrade.accountCurrency, 'USD');
});

test('platform defaults to mt4, validates mt5, and flows into the journal trade', () => {
  const mt4 = normalizeMt4Event(base);
  assert.equal(mt4.platform, 'mt4');
  assert.equal(mt4.account.platform, 'mt4');
  const mt5 = normalizeMt4Event({
    ...base,
    event_id: 'nkj_demo_7654321_close_100',
    platform: 'mt5',
    account: { login: '7654321', server: 'Broker-MT5', currency: 'EUR' }
  });
  assert.equal(mt5.platform, 'mt5');
  assert.equal(mt5.account.platform, 'mt5');
  const trade = buildJournalTrade(mt5, '2026-10-13T11:00:00.000Z');
  assert.equal(trade.source, 'mt5');
  assert.equal(trade.platform, 'mt5');
  assert.equal(trade.mt4Login, '7654321');
  assert.equal(trade.accountCurrency, 'EUR');
  assert.throws(() => normalizeMt4Event({ ...base, platform: 'ctrader' }), /Unsupported platform/);
});

test('account snapshots require live account values but permit valid negative equity or floating P/L', () => {
  const snapshot = normalizeMt4Event({
    event_id: 'nkj_demo_12345_snapshot_100',
    event_type: 'account_snapshot',
    broker_time: '2026.10.13 10:20:30',
    account: { login: '1234567', server: 'Broker-Demo', currency: 'USD', balance: 1000, equity: 980, floating_pl: -20 }
  });
  assert.equal(snapshot.account.balance, 1000);
  assert.equal(snapshot.account.equity, 980);
  assert.equal(snapshot.account.floating_pl, -20);
  assert.throws(() => normalizeMt4Event({
    ...snapshot,
    event_id: 'nkj_demo_12345_snapshot_101',
    account: { login: '1234567', server: 'Broker-Demo', currency: 'USD', balance: null, equity: 980, floating_pl: -20 }
  }), /requires balance, equity, and floating_pl/);
});
