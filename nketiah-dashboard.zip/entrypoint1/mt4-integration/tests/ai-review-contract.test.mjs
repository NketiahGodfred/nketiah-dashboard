import test from 'node:test';
import assert from 'node:assert/strict';
import { sanitizeAiTrade, sanitizeAppCalculatedMetrics, sanitizeSelectedWindow } from '../../supabase/functions/ai-review/contract.mjs';

test('cloud AI contract preserves MT4/account-currency evidence and only accepts explicit TP/SL reason codes', () => {
  const mt4 = sanitizeAiTrade({
    tradeId: 'trade-1', source: 'mt4', symbol: 'eurusd', side: 'long', accountCurrency: 'GHS',
    netPnl: 50, lots: 0.2, entryPrice: 1.1, exitPrice: 1.2, stopLoss: 1.05, takeProfit: 1.2,
    exitReason: 'TP', brokerOpenTime: '2026.10.13 09:00:00', brokerCloseTime: '2026.10.13 10:00:00',
    commission: -1, swap: 0.5, followedSop: 'yes', notes: 'review context'
  });
  assert.equal(mt4.source, 'mt4');
  assert.equal(mt4.side, 'long');
  assert.equal(mt4.accountCurrency, 'GHS');
  assert.equal(mt4.netPnl, 50);
  assert.equal(mt4.exitReason, 'tp');
  assert.equal(mt4.commission, -1);
  assert.equal(mt4.notes, 'review context');
});

test('cloud AI cannot turn manual or unknown close metadata into TP/SL', () => {
  const manual = sanitizeAiTrade({ tradeId: 'manual-1', source: 'manual', symbol: 'EURUSD', closedAt: '2026-10-13', exitReason: 'tp' });
  const unknown = sanitizeAiTrade({ tradeId: 'mt4-2', source: 'mt4', symbol: 'EURUSD', closedAt: '2026-10-13', exitReason: 'close-near-target' });
  assert.equal(manual.exitReason, 'unknown');
  assert.equal(unknown.exitReason, 'unknown');
  assert.equal(sanitizeAiTrade(null), null);
});

test('cloud AI accepts explicit TP/SL from MT5 broker records but rejects unknown sources', () => {
  const mt5 = sanitizeAiTrade({ tradeId: 'trade-2', source: 'mt5', symbol: 'XAUUSD', side: 'short', accountCurrency: 'USD', netPnl: -12.5, exitReason: 'SL' });
  assert.equal(mt5.source, 'mt5');
  assert.equal(mt5.exitReason, 'sl');
  const unsupported = sanitizeAiTrade({ tradeId: 'trade-3', source: 'ctrader', symbol: 'EURUSD', exitReason: 'tp' });
  assert.equal(unsupported.source, 'manual');
  assert.equal(unsupported.exitReason, 'unknown');
});

test('metrics and selected-window sanitizers cap the cloud prompt payload', () => {
  const metrics = sanitizeAppCalculatedMetrics({
    netPnlAmount: 20, mixedCurrencies: false, accountCurrencies: 'GHS', bad_key: { secret: true },
    ['x'.repeat(61)]: 'too long', listValue: ['not', 'allowed']
  });
  assert.deepEqual(metrics, { netPnlAmount: 20, mixedCurrencies: false, accountCurrencies: 'GHS' });
  const window = sanitizeSelectedWindow({ start: '2026-10-12', end: '2026-10-16', rule: 'x'.repeat(600), extra: 'ignored' });
  assert.equal(window.start, '2026-10-12');
  assert.equal(window.rule.length, 400);
  assert.equal('extra' in window, false);
});
