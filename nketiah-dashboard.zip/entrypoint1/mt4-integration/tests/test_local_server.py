import contextlib
import io
import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from http.server import HTTPServer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_test_server import EventStore, RequestHandler, normalize_event


BASE_EVENT = {
    'event_id': 'nkj_demo_12345_close_67890',
    'event_type': 'trade_closed',
    'broker_time': '2026.10.13 10:20:30',
    'observed_time': '2026.10.13 10:20:35',
    'account': {'login': '1234567', 'server': 'Broker-Demo', 'currency': 'USD'},
    'order': {
        'ticket': 67890, 'type': 'BUY', 'symbol': 'EURUSD', 'side': 'BUY', 'lots': 0.1,
        'open_time': '2026.10.13 09:00:00', 'close_time': '2026.10.13 10:20:30',
        'open_price': 1.16, 'close_price': 1.162, 'stop_loss': 1.155,
        'take_profit': 1.17, 'profit': 20, 'swap': -0.2, 'commission': -0.7,
        'net_profit': 19.1, 'balance_amount': 0, 'magic': 0,
        'comment': 'TP 1.17000', 'close_reason': 'tp', 'expiration': ''
    }
}


class LocalServerTests(unittest.TestCase):
    def test_trade_close_maps_to_local_journal_preview(self):
        event = normalize_event(BASE_EVENT)
        with tempfile.TemporaryDirectory() as directory:
            store = EventStore(Path(directory) / 'events.jsonl')
            result = store.append(event)
            view = store.snapshot()
        self.assertFalse(result['duplicate'])
        self.assertEqual(view['event_count'], 1)
        self.assertEqual(view['trade_close_count'], 1)
        self.assertEqual(view['long_close_count'], 1)
        self.assertEqual(view['short_close_count'], 0)
        self.assertEqual(view['take_profit_count'], 1)
        self.assertEqual(view['stop_loss_count'], 0)
        self.assertEqual(view['unclassified_close_count'], 0)
        self.assertEqual(view['trades'][0]['exitReason'], 'tp')
        self.assertEqual(view['trades'][0]['openedAt'], '2026.10.13 09:00:00')
        self.assertEqual(view['trades'][0]['closedAt'], '2026-10-13')
        self.assertEqual(view['trades'][0]['pnlUsd'], 19.1)
        self.assertEqual(view['trades'][0]['accountCurrency'], 'USD')
        self.assertEqual(view['trades'][0]['mt4Login'], '1234567')
        self.assertEqual(view['trades'][0]['sourceEventId'], BASE_EVENT['event_id'])

    def test_ambiguous_or_nonterminal_comments_are_not_classified_by_local_mock(self):
        ambiguous = normalize_event({
            **BASE_EVENT,
            'order': {**BASE_EVENT['order'], 'close_reason': 'tp', 'comment': 'TP 1.170 / SL 1.155'}
        })
        legacy_explicit = normalize_event({
            **BASE_EVENT,
            'event_id': 'nkj_demo_12345_legacy_tp_67890',
            'order': {**BASE_EVENT['order'], 'close_reason': None, 'comment': '[TP] 1.170'}
        })
        free_text = normalize_event({
            **BASE_EVENT,
            'event_id': 'nkj_demo_12345_free_text_67890',
            'order': {**BASE_EVENT['order'], 'close_reason': 'unknown', 'comment': 'manual note about TP'}
        })
        self.assertEqual(ambiguous['order']['close_reason'], 'unknown')
        self.assertEqual(legacy_explicit['order']['close_reason'], 'tp')
        self.assertEqual(free_text['order']['close_reason'], 'unknown')

    def test_replay_is_idempotent_and_balance_event_does_not_become_trade(self):
        with tempfile.TemporaryDirectory() as directory:
            store = EventStore(Path(directory) / 'events.jsonl')
            first = normalize_event(BASE_EVENT)
            self.assertFalse(store.append(first)['duplicate'])
            self.assertTrue(store.append(first)['duplicate'])
            store = EventStore(Path(directory) / 'events.jsonl')  # Simulate server restart.
            self.assertTrue(store.append(first)['duplicate'])
            short_close = {
                **BASE_EVENT,
                'event_id': 'nkj_demo_12345_short_67891',
                'order': {**BASE_EVENT['order'], 'ticket': 67891, 'type': 'SELL', 'side': 'SELL', 'net_profit': -4.25, 'close_reason': 'sl', 'comment': 'SL 1.15500'}
            }
            store.append(normalize_event(short_close))
            balance = {
                **BASE_EVENT,
                'event_id': 'nkj_demo_12345_balance_45',
                'event_type': 'balance_adjustment',
                'order': {**BASE_EVENT['order'], 'ticket': 45, 'type': 'BALANCE', 'balance_amount': 100, 'comment': 'demo credit'}
            }
            store.append(normalize_event(balance))
            view = store.snapshot()
        self.assertEqual(view['event_count'], 3)
        self.assertEqual(view['trade_close_count'], 2)
        self.assertEqual(view['long_close_count'], 1)
        self.assertEqual(view['short_close_count'], 1)
        self.assertEqual(view['take_profit_count'], 1)
        self.assertEqual(view['stop_loss_count'], 1)
        self.assertEqual(view['unclassified_close_count'], 0)

    def test_account_snapshot_updates_latest_dashboard_without_entering_activity_ledger(self):
        snapshot = normalize_event({
            'event_id': 'nkj_demo_12345_snapshot_101',
            'event_type': 'account_snapshot',
            'broker_time': '2026.10.13 10:20:30',
            'observed_time': '2026.10.13 10:20:30',
            'account': {'login': '1234567', 'server': 'Broker-Demo', 'currency': 'USD', 'balance': 1000, 'equity': 1012.5, 'floating_pl': 12.5, 'margin': 100, 'free_margin': 912.5, 'leverage': 100}
        })
        with tempfile.TemporaryDirectory() as directory:
            store = EventStore(Path(directory) / 'events.jsonl')
            result = store.append(snapshot)
            duplicate = store.append(snapshot)
            view = store.snapshot()
        self.assertFalse(result['duplicate'])
        self.assertTrue(duplicate['duplicate'])
        self.assertEqual(view['event_count'], 0)
        self.assertEqual(view['account_snapshot']['balance'], 1000)
        self.assertEqual(view['account_snapshot']['equity'], 1012.5)
        self.assertEqual(view['account_snapshot']['floating_pl'], 12.5)

    def test_loopback_http_endpoint_checks_token_and_records_event(self):
        with tempfile.TemporaryDirectory() as directory:
            server = HTTPServer(('127.0.0.1', 0), RequestHandler)
            server.test_token = 'local-test-token-' + 'x' * 32
            server.event_store = EventStore(Path(directory) / 'events.jsonl')
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            base_url = f'http://127.0.0.1:{server.server_port}'
            try:
                payload = json.dumps(BASE_EVENT).encode('utf-8')
                wrong = Request(base_url + '/functions/v1/mt4-ingest', data=payload, headers={'Content-Type': 'application/json', 'X-MT4-Token': 'wrong'}, method='POST')
                with self.assertRaises(HTTPError) as error:
                    urlopen(wrong, timeout=3)
                self.assertEqual(error.exception.code, 401)

                good = Request(base_url + '/functions/v1/mt4-ingest', data=payload, headers={'Content-Type': 'application/json', 'X-MT4-Token': server.test_token}, method='POST')
                with contextlib.redirect_stdout(io.StringIO()):
                    response = urlopen(good, timeout=3)
                    body = json.loads(response.read().decode('utf-8'))
                self.assertEqual(response.status, 200)
                self.assertTrue(body['ok'])
                self.assertEqual(server.event_store.snapshot()['trade_close_count'], 1)
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=3)


    def test_mt5_platform_is_normalized_and_rejected_when_invalid(self):
        mt5_close = {
            **BASE_EVENT,
            'event_id': 'nkj_demo_7654321_close_111',
            'platform': 'mt5',
            'account': {'login': '7654321', 'server': 'Broker-MT5', 'currency': 'USD'}
        }
        event = normalize_event(mt5_close)
        self.assertEqual(event['platform'], 'mt5')
        self.assertEqual(event['account']['platform'], 'mt5')
        with tempfile.TemporaryDirectory() as directory:
            store = EventStore(Path(directory) / 'events.jsonl')
            store.append(event)
            view = store.snapshot()
        trade = view['trades'][0]
        self.assertEqual(trade['source'], 'mt5')
        self.assertEqual(trade['platform'], 'mt5')
        self.assertTrue(trade['id'].startswith('mt5_'))
        with self.assertRaises(ValueError):
            normalize_event({**mt5_close, 'platform': 'mt4android'})

    def test_each_account_keeps_its_own_dashboard_row_and_close_counts(self):
        with tempfile.TemporaryDirectory() as directory:
            store = EventStore(Path(directory) / 'events.jsonl')
            store.append(normalize_event(BASE_EVENT))
            store.append(normalize_event({
                **BASE_EVENT,
                'event_id': 'nkj_demo_7654321_close_222',
                'platform': 'mt5',
                'account': {'login': '7654321', 'server': 'Broker-MT5', 'currency': 'EUR'},
                'order': {**BASE_EVENT['order'], 'ticket': 7654321, 'side': 'SELL', 'net_profit': -4.25, 'close_reason': 'sl', 'comment': 'SL 1.15500'}
            }))
            store.append(normalize_event({
                'event_id': 'nkj_demo_7654321_snapshot_9',
                'event_type': 'account_snapshot',
                'platform': 'mt5',
                'broker_time': '2026.10.13 11:00:00',
                'observed_time': '2026.10.13 11:00:00',
                'account': {'login': '7654321', 'server': 'Broker-MT5', 'currency': 'EUR', 'balance': 500, 'equity': 495.75, 'floating_pl': -4.25}
            }))
            view = store.snapshot()
            persisted = json.loads((Path(directory) / 'events.jsonl.snapshot.json').read_text(encoding='utf-8'))
            reloaded = EventStore(Path(directory) / 'events.jsonl')
        rows = view['account_snapshots']
        self.assertEqual(len(rows), 2)
        by_key = {f"{row['platform']}:{row['login']}@{row['server']}": row for row in rows}
        mt4_row = by_key['mt4:1234567@Broker-Demo']
        mt5_row = by_key['mt5:7654321@Broker-MT5']
        self.assertEqual(mt4_row['trade_close_count'], 1)
        self.assertEqual(mt4_row['long_close_count'], 1)
        self.assertEqual(mt4_row['short_close_count'], 0)
        self.assertEqual(mt5_row['trade_close_count'], 1)
        self.assertEqual(mt5_row['long_close_count'], 0)
        self.assertEqual(mt5_row['short_close_count'], 1)
        self.assertEqual(mt5_row['stop_loss_count'], 1)
        self.assertEqual(mt5_row['take_profit_count'], 0)
        self.assertEqual(mt5_row['balance'], 500)
        self.assertEqual(mt5_row['currency'], 'EUR')
        self.assertNotIn('balance', mt4_row)
        # Legacy single-account field stays populated for older clients.
        self.assertEqual(view['account_snapshot']['login'], '1234567')
        self.assertEqual(sorted(persisted), ['mt5:7654321@Broker-MT5'])
        self.assertEqual(list(reloaded.account_snapshots), ['mt5:7654321@Broker-MT5'])
        self.assertEqual(len(reloaded.snapshot()['account_snapshots']), 2)
        self.assertEqual(reloaded.snapshot()['trade_close_count'], 2)


if __name__ == '__main__':
    unittest.main()
