import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const appSource = await readFile(new URL('../../app.js', import.meta.url), 'utf8');

test('authenticated local preview renders live account strip and MT4 activity without stale references', async () => {
  const elements = new Map();
  const listeners = new Map();
  const storage = new Map();
  const appRoot = {
    innerHTML: '',
    addEventListener(type, callback) { listeners.set(`app:${type}`, callback); },
    querySelectorAll() { return []; }
  };
  const modalRoot = {
    innerHTML: '',
    addEventListener(type, callback) { listeners.set(`modal:${type}`, callback); },
    querySelectorAll() { return []; }
  };
  const toastRoot = { innerHTML: '', appendChild() {} };
  elements.set('app', appRoot);
  elements.set('modal-root', modalRoot);
  elements.set('toast-root', toastRoot);
  const document = {
    body: { style: {} },
    visibilityState: 'visible',
    activeElement: null,
    getElementById(id) { return elements.get(id) || null; },
    querySelector(selector) {
      if (selector === '[data-mt4-account-strip]') return { outerHTML: '', set outerHTML(value) { this.value = value; } };
      if (selector === '[data-local-mt4-refresh-status]') return { dataset: {}, textContent: '' };
      return null;
    },
    querySelectorAll() { return []; },
    createElement() { return { style: {}, classList: { add() {}, remove() {} }, appendChild() {}, remove() {}, click() {} }; },
    addEventListener() {}
  };
  const now = new Date().toISOString();
  const accountEvent = {
    event_id: 'nkj_demo_12345_close_67890', event_type: 'trade_closed',
    broker_time: '2026.10.13 10:20:30', observed_time: now,
    account: { login: '1234567', server: 'Broker-Demo', currency: 'USD' },
    order: { ticket: 67890, symbol: 'EURUSD', side: 'BUY', lots: 0.1, open_price: 1.16, close_price: 1.162, stop_loss: 1.155, take_profit: 1.17, net_profit: 19.1, close_reason: 'tp', open_time: '2026.10.13 09:00:00', close_time: '2026.10.13 10:20:30' }
  };
  const feed = {
    event_count: 1, trade_close_count: 1, long_close_count: 1, short_close_count: 0,
    take_profit_count: 1, stop_loss_count: 0, unclassified_close_count: 0,
    account_snapshot: { login: '1234567', server: 'Broker-Demo', currency: 'USD', balance: 1000, equity: 1019.1, floating_pl: 19.1, received_at: now },
    events: [accountEvent],
    trades: [{ id: 'mt4_demo-close', sourceEventId: accountEvent.event_id, source: 'mt4', closedAt: '2026-10-13', symbol: 'EURUSD', side: 'buy', pnlUsd: 19.1, accountCurrency: 'USD', exitReason: 'tp', stages: { before: [], during: [], after: [] } }]
  };
  const context = {
    document,
    window: {
      location: { search: '?mt4Local=1', origin: 'http://127.0.0.1', pathname: '/' },
      NketiahProductionBuild: false,
      NketiahDemoAuth: { username: 'demo', password: 'demo' },
      setInterval() { return 1; }, clearInterval() {}, setTimeout() { return 1; }, clearTimeout() {},
      confirm() { return true; }
    },
    localStorage: { getItem(key) { return storage.has(key) ? storage.get(key) : null; }, setItem(key, value) { storage.set(key, String(value)); }, removeItem(key) { storage.delete(key); } },
    sessionStorage: { getItem(key) { return key === 'nketiah-journal-preview-auth' ? 'active' : null; }, setItem() {}, removeItem() {} },
    fetch: async () => ({ ok: true, status: 200, json: async () => feed }),
    console,
    URL,
    URLSearchParams,
    Intl,
    Date,
    Math,
    setTimeout() { return 1; }, clearTimeout() {},
    setInterval() { return 1; }, clearInterval() {}
  };
  vm.runInNewContext(appSource, vm.createContext(context), { filename: 'app.js' });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(appRoot.innerHTML, /MT4 LIVE ACCOUNT/);

  const click = listeners.get('app:click');
  assert.equal(typeof click, 'function');

  // Connect tab: lists the connected account and the how-to-connect steps.
  click({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'connect' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(appRoot.innerHTML, /Connect another account/);
  assert.match(appRoot.innerHTML, /MT4 · 1234567/);
  assert.match(appRoot.innerHTML, /Broker-Demo/);
  assert.match(appRoot.innerHTML, /NketiahAccountLogger\.mq4/);
  assert.match(appRoot.innerHTML, /127\.0\.0\.1\/functions\/v1\/mt4-ingest/);
  assert.doesNotMatch(appRoot.innerHTML, /Manual journal/);

  // The manual journal (empty, inactive) is hidden from the selector; forcing a
  // switch to it recreates it, but it must never show another account's live
  // balance/equity strip, and switching back restores the account identity.
  click({ target: { closest: () => ({ dataset: { action: 'switch-journal', accountKey: 'manual' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(appRoot.innerHTML, /value="manual" selected/);
  assert.doesNotMatch(appRoot.innerHTML, /MT4 LIVE ACCOUNT/);
  click({ target: { closest: () => ({ dataset: { action: 'switch-journal', accountKey: 'mt4:1234567@Broker-Demo' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(appRoot.innerHTML, /MT4 LIVE ACCOUNT/);

  click({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'mt4-activity' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(appRoot.innerHTML, /Trade and account activity/);
  assert.match(appRoot.innerHTML, /\$1,000\.00/);
  assert.doesNotMatch(appRoot.innerHTML, /TAKE PROFIT/);
  assert.doesNotMatch(appRoot.innerHTML, /STOP LOSS/);
  assert.doesNotMatch(appRoot.innerHTML, /UNCLASSIFIED EXITS/);
  assert.match(appRoot.innerHTML, /TP · broker-confirmed/);
  assert.match(appRoot.innerHTML, /FLOATING P\/L/);
  assert.match(appRoot.innerHTML, /EQUITY/);

  click({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'ai' } }) } });
  assert.match(appRoot.innerHTML, /Evidence first/);
  click({ target: { closest: () => ({ dataset: { action: 'run-ai-review', mode: 'trade' } }) } });
  assert.match(appRoot.innerHTML, /Offline evidence engine · deterministic rules/);
  assert.match(appRoot.innerHTML, /TP · explicitly reported/);
  assert.match(appRoot.innerHTML, /price proximity/);

  click({ target: { closest: () => ({ dataset: { action: 'ai-mode', mode: 'week' } }) } });
  click({ target: { closest: () => ({ dataset: { action: 'run-ai-review', mode: 'week' } }) } });
  assert.match(appRoot.innerHTML, /Broker closes · TP \/ SL \/ unclassified/);
  assert.match(appRoot.innerHTML, /1 \/ 0 \/ 0/);
});

test('legacy manual-journal EA imports migrate into the account journal and the manual journal is removed', async () => {
  const elements = new Map();
  const listeners = new Map();
  const storage = new Map();
  const appRoot = {
    innerHTML: '',
    addEventListener(type, callback) { listeners.set(`app:${type}`, callback); },
    querySelectorAll() { return []; }
  };
  const modalRoot = {
    innerHTML: '',
    addEventListener(type, callback) { listeners.set(`modal:${type}`, callback); },
    querySelectorAll() { return []; }
  };
  const toastRoot = { innerHTML: '', appendChild() {} };
  elements.set('app', appRoot);
  elements.set('modal-root', modalRoot);
  elements.set('toast-root', toastRoot);
  const document = {
    body: { style: {} },
    visibilityState: 'visible',
    activeElement: null,
    getElementById(id) { return elements.get(id) || null; },
    querySelector(selector) {
      if (selector === '[data-mt4-account-strip]') return { outerHTML: '', set outerHTML(value) { this.value = value; } };
      if (selector === '[data-local-mt4-refresh-status]') return { dataset: {}, textContent: '' };
      return null;
    },
    querySelectorAll() { return []; },
    createElement() { return { style: {}, classList: { add() {}, remove() {} }, appendChild() {}, remove() {}, click() {} }; },
    addEventListener() {}
  };
  // Pre-multi-account storage: both EA closes were imported into the legacy
  // manual journal before per-account keying existed.
  storage.set('nketiah-journal-v1', JSON.stringify({
    version: 2,
    activeAccountKey: 'manual',
    journals: {
      manual: {
        version: 1,
        trades: [
          { id: 't1', sourceEventId: 'evt-legacy-1', source: 'mt4', mt4Login: '1234567', mt4Server: 'Broker-Demo', closedAt: '2026-10-10', symbol: 'EURUSD', side: 'buy', pnlUsd: 12, stages: { before: [], during: [], after: [] } },
          { id: 't2', sourceEventId: 'evt-legacy-2', source: 'mt4', mt4Login: '1234567', mt4Server: 'Broker-Demo', closedAt: '2026-10-11', symbol: 'GBPUSD', side: 'sell', pnlUsd: -4, stages: { before: [], during: [], after: [] } }
        ],
        setups: [], plans: [], aiReviews: [],
        settings: { startingBalance: 500, accountCurrency: 'USD', dailyLossLimit: '', maxDailyTrades: '', weeklyGoal: '', riskHaltAcknowledgedDate: '', timezone: 'UTC' },
        goalCoach: { weekKey: '', messages: [] },
        sampleWorkspace: false
      }
    }
  }));
  const now = new Date().toISOString();
  const accountEvent = {
    event_id: 'nkj_demo_12345_close_67890', event_type: 'trade_closed',
    broker_time: '2026.10.13 10:20:30', observed_time: now,
    account: { login: '1234567', server: 'Broker-Demo', currency: 'USD' },
    order: { ticket: 67890, symbol: 'EURUSD', side: 'BUY', lots: 0.1, open_price: 1.16, close_price: 1.162, stop_loss: 1.155, take_profit: 1.17, net_profit: 19.1, close_reason: 'tp', open_time: '2026.10.13 09:00:00', close_time: '2026.10.13 10:20:30' }
  };
  const feed = {
    event_count: 1, trade_close_count: 1, long_close_count: 1, short_close_count: 0,
    take_profit_count: 1, stop_loss_count: 0, unclassified_close_count: 0,
    account_snapshot: { login: '1234567', server: 'Broker-Demo', currency: 'USD', balance: 1000, equity: 1019.1, floating_pl: 19.1, received_at: now },
    events: [accountEvent],
    trades: [{ id: 'mt4_demo-close', sourceEventId: accountEvent.event_id, source: 'mt4', closedAt: '2026-10-13', symbol: 'EURUSD', side: 'buy', pnlUsd: 19.1, accountCurrency: 'USD', exitReason: 'tp', stages: { before: [], during: [], after: [] } }]
  };
  const context = {
    document,
    window: {
      location: { search: '?mt4Local=1', origin: 'http://127.0.0.1', pathname: '/' },
      NketiahProductionBuild: false,
      NketiahDemoAuth: { username: 'demo', password: 'demo' },
      setInterval() { return 1; }, clearInterval() {}, setTimeout() { return 1; }, clearTimeout() {},
      confirm() { return true; }
    },
    localStorage: { getItem(key) { return storage.has(key) ? storage.get(key) : null; }, setItem(key, value) { storage.set(key, String(value)); }, removeItem(key) { storage.delete(key); } },
    sessionStorage: { getItem(key) { return key === 'nketiah-journal-preview-auth' ? 'active' : null; }, setItem() {}, removeItem() {} },
    fetch: async () => ({ ok: true, status: 200, json: async () => feed }),
    console,
    URL,
    URLSearchParams,
    Intl,
    Date,
    Math,
    setTimeout() { return 1; }, clearTimeout() {},
    setInterval() { return 1; }, clearInterval() {}
  };
  vm.runInNewContext(appSource, vm.createContext(context), { filename: 'app.js' });
  await new Promise(resolve => setTimeout(resolve, 0));

  // The account journal is active immediately and owns the migrated trades.
  const saved = JSON.parse(storage.get('nketiah-journal-v1'));
  assert.equal(saved.activeAccountKey, 'mt4:1234567@Broker-Demo');
  assert.ok(!Object.prototype.hasOwnProperty.call(saved.journals, 'manual'), 'empty manual journal must be deleted');
  const accountJournal = saved.journals['mt4:1234567@Broker-Demo'];
  const migratedIds = (accountJournal.trades || []).map(trade => String(trade.sourceEventId || ''));
  assert.ok(migratedIds.includes('evt-legacy-1') && migratedIds.includes('evt-legacy-2'), 'EA closes move into the account journal');
  assert.equal(accountJournal.settings.startingBalance, 500, 'journal settings carry over');
  assert.equal(accountJournal.settings.accountCurrency, 'USD');

  // A re-render (the harness never runs the refresh loop) picks up the snapshot:
  // the account identity strip is live, migrated trades render, and the manual
  // journal stays hidden everywhere.
  listeners.get('app:click')({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'journal' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(appRoot.innerHTML, /MT4 LIVE ACCOUNT/);
  assert.match(appRoot.innerHTML, /GBPUSD/);
  listeners.get('app:click')({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'connect' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.doesNotMatch(appRoot.innerHTML, /Manual journal/);
});

test('production uses one-second cross-view snapshot refresh and loads raw events only on the MT4 activity view', async () => {
  const elements = new Map();
  const listeners = new Map();
  const intervals = [];
  const appRoot = { innerHTML: '', addEventListener(type, callback) { listeners.set(`app:${type}`, callback); }, querySelectorAll() { return []; } };
  const modalRoot = { innerHTML: '', addEventListener(type, callback) { listeners.set(`modal:${type}`, callback); }, querySelectorAll() { return []; } };
  const toastRoot = { innerHTML: '', appendChild() {} };
  elements.set('app', appRoot); elements.set('modal-root', modalRoot); elements.set('toast-root', toastRoot);
  const document = {
    body: { style: {} }, visibilityState: 'visible', activeElement: null,
    getElementById(id) { return elements.get(id) || null; },
    querySelector() { return null; }, querySelectorAll() { return []; }, addEventListener() {},
    createElement() { return { style: {}, classList: { add() {}, remove() {} }, appendChild() {}, remove() {}, click() {} }; }
  };
  let authCallback = null;
  let snapshotReads = 0;
  let dashboardReads = 0;
  let eventReads = 0;
  const cloud = {
    isConfigured: true, ownerEmail: 'owner@example.com', projectUrl: 'https://demo.supabase.co',
    onAuthStateChange(callback) { authCallback = callback; return () => {}; },
    async loadSnapshot() {
      snapshotReads++;
      return { revision: 1, payload: { version: 1, trades: [], setups: [], plans: [], aiReviews: [], settings: { accountCurrency: 'GHS' } } };
    },
    async loadMt4AccountDashboard() {
      dashboardReads++;
      return { account_login: '1234567', account_server: 'Broker-Live', account_currency: 'GHS', balance: 2000, equity: 2015, floating_pl: 15, updated_at: new Date().toISOString(), trade_close_count: 0, long_close_count: 0, short_close_count: 0, take_profit_count: 0, stop_loss_count: 0, unclassified_close_count: 0 };
    },
    async loadMt4Events() { eventReads++; return []; },
    async signOut() {}
  };
  const storage = new Map();
  const context = {
    document,
    window: {
      location: { search: '', origin: 'https://journal.example.com', pathname: '/production.html' },
      NketiahProductionBuild: true, NketiahCloud: cloud,
      setInterval(callback, delay) { intervals.push({ callback, delay }); return intervals.length; }, clearInterval() {},
      setTimeout() { return 1; }, clearTimeout() {}, confirm() { return false; }
    },
    localStorage: { getItem(key) { return storage.has(key) ? storage.get(key) : null; }, setItem(key, value) { storage.set(key, String(value)); }, removeItem(key) { storage.delete(key); } },
    sessionStorage: { getItem() { return null; }, setItem() {}, removeItem() {} },
    console, URL, URLSearchParams, Intl, Date, Math,
    setTimeout, clearTimeout, setInterval, clearInterval
  };
  vm.runInNewContext(appSource, vm.createContext(context), { filename: 'app.js' });
  assert.equal(typeof authCallback, 'function');
  await authCallback({ id: 'owner-id', email: 'owner@example.com' });
  assert.match(appRoot.innerHTML, /MT4 LIVE ACCOUNT/);
  assert.match(appRoot.innerHTML, /GHS/);
  const poller = intervals.find(item => item.delay === 1000);
  assert.ok(poller, 'cloud refresh interval must be one second');
  const initialEvents = eventReads;
  listeners.get('app:click')({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'journal' } }) } });
  await poller.callback();
  assert.equal(eventReads, initialEvents, 'activity rows should not be fetched on other views');
  assert.ok(dashboardReads >= 2, 'MT4 account snapshot should refresh on the journal view');
  assert.ok(snapshotReads >= 2, 'journal revision should refresh on the journal view');
  listeners.get('app:click')({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'mt4-activity' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.ok(eventReads > initialEvents, 'raw activity rows should load when the activity view opens');
  listeners.get('app:click')({ target: { closest: () => ({ dataset: { action: 'navigate', view: 'connect' } }) } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.match(appRoot.innerHTML, /Connect another account/);
  assert.match(appRoot.innerHTML, /https:\/\/demo\.supabase\.co\/functions\/v1\/mt4-ingest/);
});
