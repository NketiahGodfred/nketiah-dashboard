import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const root = new URL('../../', import.meta.url);

test('database migration enforces owner-only reads and server-only ingestion', async () => {
  const sql = await readFile(new URL('supabase/migrations/202610130001_mt4_account_ingest.sql', root), 'utf8');
  assert.match(sql, /alter table public\.mt4_account_events enable row level security/i);
  assert.match(sql, /alter table public\.mt4_account_events force row level security/i);
  assert.match(sql, /grant select on public\.mt4_account_events to authenticated/i);
  assert.match(sql, /MT4 activity is visible only to the journal owner[\s\S]*public\.is_journal_owner\(\)/i);
  assert.match(sql, /unique \(owner_id, event_id\)/i);
  assert.match(sql, /revoke all on function public\.ingest_mt4_event\(jsonb\) from public, anon, authenticated/i);
  assert.match(sql, /grant execute on function public\.ingest_mt4_event\(jsonb\) to service_role/i);
  assert.match(sql, /for update/i);
  assert.match(sql, /revision = snapshot\.revision \+ 1/i);
  const dashboard = await readFile(new URL('supabase/migrations/202610130002_mt4_dashboard.sql', root), 'utf8');
  const ea = await readFile(new URL('mt4-integration/NketiahAccountLogger.mq4', root), 'utf8');
  assert.match(ea, /if\(mentionsTP && mentionsSL\) return "unknown"/);
  assert.match(ea, /AccountEquity\(\)/);
  assert.match(ea, /close_reason/);
  assert.match(dashboard, /alter table public\.mt4_account_snapshots enable row level security/i);
  assert.match(dashboard, /grant execute on function public\.ingest_mt4_account_snapshot\(jsonb\) to service_role/i);
  assert.match(dashboard, /mentions_tp and mentions_sl[\s\S]*as ambiguous/i);
  assert.match(dashboard, /evidence\.ambiguous or evidence\.says_tp = evidence\.says_sl/i);
  assert.match(dashboard, /if \(v_comment ~[\s\S]*v_tp := false;[\s\S]*v_sl := false;/i);
});

test('MT5 EA is read-only, publishes platform mt5, and never guesses close reasons', async () => {
  const ea5 = await readFile(new URL('mt4-integration/NketiahAccountLogger.mq5', root), 'utf8');
  assert.match(ea5, /Never places or closes trades/);
  assert.match(ea5, /if\(mentionsTP && mentionsSL\) return "unknown"/);
  assert.match(ea5, /AccountInfoDouble\(ACCOUNT_EQUITY\)/);
  assert.match(ea5, /"platform\\":\\"mt5\\""|\"platform\":\"mt5\"/);
  assert.match(ea5, /DEAL_ENTRY_OUT/);
  assert.match(ea5, /X-MT4-Token/);
  assert.doesNotMatch(ea5, /OrderSend|PositionClose|ORDER_TYPE_BALANCE/);
  assert.doesNotMatch(ea5, /SELECT_BY_POS|MODE_TRADES|AccountNumber\(/);
});

test('Edge Function uses a separate token and server-side Supabase secret', async () => {
  const edge = await readFile(new URL('supabase/functions/mt4-ingest/index.ts', root), 'utf8');
  const handler = await readFile(new URL('supabase/functions/mt4-ingest/handler.mjs', root), 'utf8');
  assert.match(edge, /MT4_INGEST_TOKEN/);
  assert.match(edge, /SUPABASE_SERVICE_ROLE_KEY/);
  assert.match(handler, /x-mt4-token/i);
  assert.match(edge, /ingest_mt4_event/);
  assert.match(edge, /createMt4Handler/);
  assert.doesNotMatch(`${edge}\n${handler}`, /Access-Control-Allow-Origin.*\*/);
});

test('local MT4 mock binds to loopback and contains no cloud credentials', async () => {
  const localServer = await readFile(new URL('mt4-integration/local_test_server.py', root), 'utf8');
  assert.match(localServer, /host\s*=\s*['"]127\.0\.0\.1['"]/);
  assert.match(localServer, /HTTPServer\(\(host, port\), RequestHandler\)/);
  assert.match(localServer, /NJ_MT4_TEST_PORT', '80'/);
  assert.doesNotMatch(localServer, /SUPABASE_SERVICE_ROLE_KEY|SUPABASE_URL|MT4_INGEST_TOKEN/);
  assert.match(localServer, /never connects to Supabase/i);
});

test('opt-in local journal mode reads only the loopback bridge and deduplicates imported closes', async () => {
  const app = await readFile(new URL('app.js', root), 'utf8');
  const localVite = await readFile(new URL('vite.local-mt4.config.js', root), 'utf8');
  const pkg = JSON.parse(await readFile(new URL('package.json', root), 'utf8'));
  assert.match(app, /!productionMode && new URLSearchParams\(window\.location\.search\)\.get\('mt4Local'\) === '1'/);
  assert.match(app, /fetch\('\/__local_mt4\/events'/);
  assert.match(app, /LOCAL_MT4_IMPORTED_KEY/);
  assert.match(app, /sourceEventId/);
  assert.match(app, /trades:\s*\[\.\.\.\(state\.trades \|\| \[\]\), \.\.\.additions\]/);
  assert.match(localVite, /host:\s*'127\.0\.0\.1'/);
  assert.match(localVite, /\['127\.0\.0\.1', 'localhost'\]\.includes\(localTarget\.hostname\)/);
  assert.match(localVite, /target:\s*localTarget\.origin/);
  assert.equal(pkg.scripts['dev:mt4-local'], 'vite --config vite.local-mt4.config.js --host 127.0.0.1');
});

test('local journal auto-refreshes, hides open/canceled tickets, and shows trade-direction counts', async () => {
  const app = await readFile(new URL('app.js', root), 'utf8');
  const styles = await readFile(new URL('styles.css', root), 'utf8');
  const localServer = await readFile(new URL('mt4-integration/local_test_server.py', root), 'utf8');
  assert.match(app, /window\.setInterval\(\(\) => \{/);
  assert.match(app, /\}, 1000\);/);
  assert.match(app, /data-local-mt4-refresh-status/);
  assert.match(app, /localMt4RefreshStatusText\(\)/);
  assert.match(styles, /\.mt4-feed-status\[data-state='online'\]/);
  assert.match(app, /'order_baseline', 'order_opened', 'pending_order_placed', 'pending_order_activated', 'pending_order_cancelled'/);
  assert.match(app, /mt4AccountEvents\.filter\(event => !hiddenMt4ActivityTypes\.has\(event\.event_type\)\)/);
  assert.match(app, /CLOSED TRADE RECORDS/);
  assert.match(app, /mt4AccountStats\.longCloseCount/);
  assert.match(app, /mt4AccountStats\.shortCloseCount/);
  assert.match(app, /data-mt4-account-strip/);
  assert.match(app, /}, 1000\);/);
  assert.match(localServer, /'long_close_count': self\.long_close_count/);
  assert.match(localServer, /'short_close_count': self\.short_close_count/);
});

test('optional cloud AI keeps consent, owner auth, explicit exit semantics, and bounded review inputs', async () => {
  const edge = await readFile(new URL('supabase/functions/ai-review/index.ts', root), 'utf8');
  const contract = await readFile(new URL('supabase/functions/ai-review/contract.mjs', root), 'utf8');
  assert.match(edge, /body\.consent !== true/);
  assert.match(edge, /user\.id !== ownerId/);
  assert.match(edge, /Never infer TP\/SL from close-price proximity/);
  assert.match(edge, /selectedImages\.length > MAX_SELECTED_IMAGES/);
  assert.match(contract, /source !== 'manual' && \['tp', 'sl'\]\.includes\(rawReason\)/);
  assert.match(contract, /netPnl: numeric\(raw\.netPnl\)/);
});

test('MT4 function is the only unauthenticated-at-gateway function and has app support', async () => {
  const config = await readFile(new URL('supabase/config.toml', root), 'utf8');
  const app = await readFile(new URL('app.js', root), 'utf8');
  const bootstrap = await readFile(new URL('prod/bootstrap.js', root), 'utf8');
  assert.match(config, /\[functions\.mt4-ingest\]\s+verify_jwt = false/);
  assert.match(config, /\[functions\.ai-review\]\s+verify_jwt = true/);
  assert.match(app, /'mt4-activity': \['MetaTrader account activity'/);
  assert.match(app, /cloud\.loadMt4Events\(200,/);
  assert.match(app, /cloud\.loadMt4AccountDashboard\(\)/);
  assert.match(app, /loadMt4AccountEvents\(\{ renderAfter: false, includeEvents: ui\.view === 'mt4-activity' \}\)/);
  assert.match(bootstrap, /from\('mt4_account_events'\)/);
});
