import test from 'node:test';
import assert from 'node:assert/strict';
import { createMt4Handler } from '../../supabase/functions/mt4-ingest/handler.mjs';

const token = 'a'.repeat(64);
const event = {
  event_id: 'nkj_demo_12345_close_67890',
  event_type: 'trade_closed',
  broker_time: '2026.10.13 10:20:30',
  observed_time: '2026.10.13 10:20:35',
  account: { login: '1234567', server: 'Broker-Demo', currency: 'USD' },
  order: {
    ticket: 67890, type: 'BUY', symbol: 'EURUSD', side: 'BUY', lots: 0.1,
    open_time: '2026.10.13 09:00:00', close_time: '2026.10.13 10:20:30',
    open_price: 1.16, close_price: 1.162, stop_loss: 1.155, take_profit: 1.17,
    profit: 20, swap: -0.2, commission: -0.7, net_profit: 19.1,
    balance_amount: 0, magic: 0, comment: 'TP 1.17000', close_reason: 'tp', expiration: ''
  }
};
const post = (body, suppliedToken = token) => new Request('https://journal.invalid/functions/v1/mt4-ingest', {
  method: 'POST',
  headers: { 'content-type': 'application/json', 'x-mt4-token': suppliedToken },
  body: typeof body === 'string' ? body : JSON.stringify(body)
});

test('GET health check does not disclose secrets', async () => {
  const handler = createMt4Handler({ expectedToken: token, ingest: async () => ({}) });
  const response = await handler(new Request('https://journal.invalid/functions/v1/mt4-ingest'));
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { service: 'nketiah-mt4-ingest', status: 'ready' });
});

test('rejects wrong/missing device token without calling storage', async () => {
  let called = false;
  const handler = createMt4Handler({ expectedToken: token, ingest: async () => { called = true; } });
  const wrong = await handler(post(event, 'wrong-token'));
  const missing = await handler(new Request('https://journal.invalid/functions/v1/mt4-ingest', { method: 'POST', body: JSON.stringify(event) }));
  assert.equal(wrong.status, 401);
  assert.equal(missing.status, 401);
  assert.equal(called, false);
});

test('valid authorized event is normalized and passed to the idempotent RPC adapter', async () => {
  let received;
  const handler = createMt4Handler({ expectedToken: token, ingest: async value => { received = value; return { accepted: true, duplicate: false }; } });
  const response = await handler(post(event));
  assert.equal(response.status, 200);
  assert.equal(received.event_type, 'trade_closed');
  assert.equal(received.order.symbol, 'EURUSD');
  assert.deepEqual(await response.json(), { ok: true, result: { accepted: true, duplicate: false } });
});

test('routes account snapshots to the bounded snapshot upsert adapter, not the event ledger', async () => {
  let eventLedgerCalled = false;
  let snapshotReceived = null;
  const handler = createMt4Handler({
    expectedToken: token,
    ingest: async () => { eventLedgerCalled = true; return {}; },
    ingestSnapshot: async value => { snapshotReceived = value; return { accepted: true, snapshot_only: true }; }
  });
  const snapshot = {
    event_id: 'nkj_demo_12345_snapshot_100',
    event_type: 'account_snapshot',
    broker_time: '2026.10.13 10:20:30',
    observed_time: '2026.10.13 10:20:30',
    account: { login: '1234567', server: 'Broker-Demo', currency: 'USD', balance: 1000, equity: 1012.5, floating_pl: 12.5, margin: 100, free_margin: 912.5, leverage: 100 }
  };
  const response = await handler(post(snapshot));
  assert.equal(response.status, 200);
  assert.equal(eventLedgerCalled, false);
  assert.equal(snapshotReceived.event_type, 'account_snapshot');
  assert.equal(snapshotReceived.account.floating_pl, 12.5);
});

test('rejects malformed, unsupported, oversized, and multi-event payloads', async () => {
  const handler = createMt4Handler({ expectedToken: token, ingest: async () => ({}) });
  assert.equal((await handler(post('{'))).status, 400);
  assert.equal((await handler(post({ ...event, event_type: 'unknown' }))).status, 400);
  assert.equal((await handler(post([event, event]))).status, 400);
  assert.equal((await handler(post('x'.repeat(33 * 1024)))).status, 413);
  const wrongMethod = await handler(new Request('https://journal.invalid/functions/v1/mt4-ingest', { method: 'PUT' }));
  assert.equal(wrongMethod.status, 405);
});

test('maps storage errors to a generic server error and never echoes token', async () => {
  const handler = createMt4Handler({ expectedToken: token, ingest: async () => { throw new Error('private SQL detail'); } });
  const originalError = console.error;
  console.error = () => {};
  try {
    const response = await handler(post(event));
    const body = await response.text();
    assert.equal(response.status, 500);
    assert.equal(body, '{"error":"Event could not be saved."}');
    assert.equal(body.includes(token), false);
    assert.equal(body.includes('private SQL detail'), false);
  } finally {
    console.error = originalError;
  }
});
