import { defineConfig } from 'vite';

// Explicit loopback-only development mode for viewing the local MT4 mock feed.
// Vite proxies browser requests to the Python test server on HTTP port 80.
// A loopback-only target override is useful for exercising the proxy in tests.
const localTarget = new URL(process.env.NKJ_LOCAL_MT4_TARGET || 'http://127.0.0.1');
if (localTarget.protocol !== 'http:' || !['127.0.0.1', 'localhost'].includes(localTarget.hostname)) {
  throw new Error('The local MT4 proxy target must be an HTTP loopback address.');
}

export default defineConfig({
  server: {
    host: '127.0.0.1',
    allowedHosts: ['127.0.0.1', 'localhost'],
    proxy: {
      '/__local_mt4': {
        target: localTarget.origin,
        changeOrigin: false,
        rewrite: (path) => path.replace(/^\/__local_mt4/, '')
      }
    }
  }
});
