/* Nketiah Journal — shared app shell for the browser-only demo and production build.
   Demo data is local; production mode delegates auth, snapshots, images, and AI to NketiahCloud.
   Production services require the Supabase project setup documented in PRODUCTION_SETUP.md. */
(() => {
  'use strict';

  const STORE_KEY = 'nketiah-journal-v1';
  const DB_NAME = 'nketiah-journal-images-v1';
  const DB_STORE = 'images';
  const appRoot = document.getElementById('app');
  const modalRoot = document.getElementById('modal-root');
  const toastRoot = document.getElementById('toast-root');
  const imageUrlCache = new Map();
  const cloudImagePathCache = new Map();
  const imageUrlExpiry = new Map();

  const iconPaths = {
    performance: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    journal: '<path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H20v18H7.5A2.5 2.5 0 0 0 5 22z"/><path d="M5 4.5v15A2.5 2.5 0 0 1 7.5 17H20M9 7h7M9 11h7"/>',
    playbook: '<path d="M12 3.5 14.3 8l5 .7-3.6 3.5.9 5-4.6-2.4-4.5 2.4.8-5-3.6-3.5 5-.7z"/><path d="M19.5 17.5 20.5 20l2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z" transform="translate(-1 -3)"/>',
    plans: '<path d="M8 4h11a2 2 0 0 1 2 2v14H7a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z"/><path d="M4 17a3 3 0 0 1 3-3h14M9 8h7M9 11h5"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 17h.01M12 17h.01"/>',
    analytics: '<path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 6-7"/><path d="M16 6h4v4"/>',
    tools: '<path d="M14.7 6.3a5 5 0 0 0-6.6 6.6L3 18l3 3 5.1-5.1a5 5 0 0 0 6.6-6.6L15 12l-3-3z"/><path d="m17 3 4 4"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-1.7 2.9-.2-.1a1.7 1.7 0 0 0-1.9.3l-.1.1h-3.4l-.1-.2a1.7 1.7 0 0 0-1.4-1.2 1.7 1.7 0 0 0-1.4.6l-.1.1-3-1.7.1-.2a1.7 1.7 0 0 0-.3-1.9l-.1-.1v-3.4l.2-.1a1.7 1.7 0 0 0 1.2-1.4 1.7 1.7 0 0 0-.6-1.4l-.1-.1 1.7-3 .2.1a1.7 1.7 0 0 0 1.9-.3l.1-.1h3.4l.1.2a1.7 1.7 0 0 0 1.4 1.2 1.7 1.7 0 0 0 1.4-.6l.1-.1 3 1.7-.1.2a1.7 1.7 0 0 0 .3 1.9l.1.1v3.4z" transform="translate(-1 -1) scale(1.08)"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.5 4.5"/>',
    filter: '<path d="M4 5h16M7 12h10m-7 7h4"/><circle cx="8" cy="5" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>',
    chevronLeft: '<path d="m15 18-6-6 6-6"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    close: '<path d="m18 6-12 12M6 6l12 12"/>',
    trend: '<path d="M4 16 10 10l4 4 6-8"/><path d="M15 6h5v5"/>',
    dollar: '<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    list: '<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6h.01M4 12h.01M4 18h.01"/>',
    download: '<path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 17v3h16v-3"/>',
    upload: '<path d="M12 16V4m0 0L8 8m4-4 4 4"/><path d="M4 17v3h16v-3"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2m3 0-.9 14H5.9L5 6m4 4v6m6-6v6"/>',
    edit: '<path d="m4 16.5-.8 4.3 4.3-.8L20 7.5 16.5 4z"/><path d="m14.5 6 3.5 3.5"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    shield: '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"/><path d="m9 12 2 2 4-4"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22z"/><path d="M4 5.5V19a3 3 0 0 1 3-3h13M8 7h8M8 11h7"/>',
    calculator: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8v3H8zM8 14h2m4 0h2m-8 3h2m4 0h2"/>',
    trendDown: '<path d="M4 8 10 14l4-4 6 8"/><path d="M15 18h5v-5"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    bolt: '<path d="m13 2-3 8h7l-6 12 2-9H6z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/>',
    cloud: '<path d="M20 16.2A4.8 4.8 0 0 0 18.5 7H17a6 6 0 0 0-11.6 1.8A4.5 4.5 0 0 0 6 17.5h12"/><path d="M12 12v7m0 0-3-3m3 3 3-3"/>',
    calendarCheck: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18m3 5 2 2 4-4"/>',
    arrowUpRight: '<path d="M7 17 17 7M7 7h10v10"/>',
    send: '<path d="M22 2 11 13"/><path d="M22 2 15 22 11 13 2 9 22 2z"/>',
    chat: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
    logout: '<path d="M10 17l5-5-5-5m5 5H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/>',
    sparkle: '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
    plug: '<path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0z"/><path d="M12 17v5"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9a2.5 2.5 0 1 1 4.6 1.3c-.7 1-2.2 1.4-2.2 3M12 17h.01"/>'
  };
  function icon(name, size = 18) {
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths.sparkle}</svg>`;
  }

  let today = localDateString(new Date());
  let goalRingAnimated = false;
  const currentYear = new Date().getFullYear();
  const AUTH_KEY = 'nketiah-journal-preview-auth';
  const CLOUD_BACKUP_KEY = 'nketiah-journal-pre-cloud-backup';
  const REMOTE_DELETE_KEY = 'nketiah-journal-pending-image-deletes';
  const MANUAL_JOURNAL_KEY = 'manual';
  const ACCOUNT_AUTO_ACTIVATE_KEY = 'nketiah-journal-account-auto-activated-v1';
  const cloud = window.NketiahCloud || null;
  const productionMode = Boolean(window.NketiahProductionBuild);
  // Explicit, opt-in loopback test mode. It is unavailable in production builds.
  const localMt4UrlOptIn = !productionMode && new URLSearchParams(window.location.search).get('mt4Local') === '1';
  let localMt4Mode = localMt4UrlOptIn;
  const LOCAL_MT4_IMPORTED_KEY = 'nketiah-journal-local-mt4-imported-event-ids-v1';
  const demoAuth = window.NketiahDemoAuth || null;
  function readAuthSession() { try { return typeof sessionStorage !== 'undefined' && sessionStorage.getItem(AUTH_KEY) === 'active'; } catch (_) { return false; } }
  let isAuthenticated = productionMode ? false : readAuthSession();
  let cloudUser = null;
  let cloudRevisions = {};
  let cloudReady = false;
  let cloudSyncStatus = productionMode ? 'offline' : 'local';
  let cloudSyncError = '';
  let cloudSyncTimer = null;
  let cloudSyncBusy = false;
  let cloudSyncPending = false;
  let cloudPollTimer = null;
  let cloudPollBusy = false;
  let cloudConflict = false;
  const initialJournalStore = readJournalStore();
  let activeAccountKey = initialJournalStore.activeAccountKey;
  let journals = initialJournalStore.journals;
  let state = journals[activeAccountKey] || defaultState();
  journals[activeAccountKey] = state;
  migrateManualBrokerTrades();
  let ui = {
    view: 'performance',
    period: 'weekly',
    year: String(currentYear),
    symbol: 'all',
    search: '',
    calendarMonth: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
    calendarSymbol: 'all',
    moreOpen: false,
    modal: null,
    pendingPhotos: { before: [], during: [], after: [] },
    pendingPhotoUrls: new Map(),
    removedPhotoIds: new Set(),
    loginUsername: 'nketiah',
    loginError: '',
    showPassword: false,
    aiMode: 'trade',
    aiTradeId: '',
    aiWeek: '',
    aiStages: { before: true, during: true, after: true },
    aiOutput: null,
    aiCloudConsent: false,
    aiRequesting: false,
    goalEquity: false,
    goalDay: '',
    coachTyping: false,
    agentOpen: false,
    chipsOpen: false,
    mt4ActivityAccount: 'active'
  };
  let dbPromise = null;
  let mt4AccountEvents = [];
  let mt4EventsError = '';
  let mt4DashboardError = '';
  let mt4EventsLoading = false;
  let mt4Accounts = [];
  let mt4AccountSnapshot = null;
  let mt4AccountStats = { eventCount: 0, tradeCloseCount: 0, longCloseCount: 0, shortCloseCount: 0, takeProfitCount: 0, stopLossCount: 0, unclassifiedCloseCount: 0 };
  let localMt4FeedSignature = '';
  let mt4RefreshTimer = null;
  let mt4SnapshotChainActive = false;
  let localMt4LastSuccessAt = 0;
  let localMt4FeedConnected = false;
  let pendingMt4Render = false;
  let riskClockTimer = null;

  function localDateString(date) {
    const d = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
    return d.toISOString().slice(0, 10);
  }
  function uid(prefix = 'id') { return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`; }
  function defaultState() {
    return {
      version: 1,
      trades: [],
      setups: [],
      plans: [],
      aiReviews: [],
      settings: { startingBalance: '', dailyLossLimit: '', maxDailyTrades: '', accountCurrency: '', weeklyGoal: '', riskHaltAcknowledgedDate: '', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC' },
      goalCoach: { weekKey: '', messages: [] },
      sampleWorkspace: false
    };
  }
  // Every connected account owns its own journal. Storage shape:
  //   v2 → { version: 2, activeAccountKey, journals: { [accountKey]: journalState } }
  //   v1 → a bare journal object (legacy single-account browser storage).
  // Journal keys: 'manual' or '<platform>:<login>@<server>' (e.g. mt4:1234567@Broker-Demo).
  function accountJournalKey(platform, login, server) {
    const p = String(platform || 'mt4').toLowerCase() === 'mt5' ? 'mt5' : 'mt4';
    return `${p}:${String(login || '')}@${String(server || '')}`;
  }
  function journalKeyParts(key) {
    const raw = String(key || '');
    if (!raw || raw === MANUAL_JOURNAL_KEY) return null;
    const sep = raw.indexOf(':');
    const at = raw.lastIndexOf('@');
    if (sep < 1 || at < sep + 1) return null;
    const platform = raw.slice(0, sep).toLowerCase() === 'mt5' ? 'mt5' : 'mt4';
    const login = raw.slice(sep + 1, at);
    const server = raw.slice(at + 1);
    if (!login || !server) return null;
    return { platform, login, server };
  }
  function isBrokerSource(source) {
    const value = String(source || '').toLowerCase();
    return value === 'mt4' || value === 'mt5';
  }
  function tradePlatform(trade) {
    const platform = String(trade?.platform || '').toLowerCase();
    if (platform === 'mt4' || platform === 'mt5') return platform;
    return isBrokerSource(trade?.source) ? String(trade.source).toLowerCase() : '';
  }
  function brokerLabel(platform) {
    const value = String(platform || '').toLowerCase();
    return value === 'mt5' ? 'MT5' : value === 'mt4' ? 'MT4' : 'MetaTrader';
  }
  function readJournalStore() {
    const fallback = () => ({ activeAccountKey: MANUAL_JOURNAL_KEY, journals: { [MANUAL_JOURNAL_KEY]: defaultState() } });
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return fallback();
      const parsed = JSON.parse(raw);
      if (parsed && parsed.version === 2 && parsed.journals && typeof parsed.journals === 'object' && !Array.isArray(parsed.journals)) {
        const nextJournals = {};
        for (const [key, value] of Object.entries(parsed.journals)) {
          if (!value || typeof value !== 'object' || Array.isArray(value)) continue;
          nextJournals[String(key)] = normalizeStatePayload(value);
        }
        if (!Object.keys(nextJournals).length) return fallback();
        const active = Object.prototype.hasOwnProperty.call(nextJournals, String(parsed.activeAccountKey))
          ? String(parsed.activeAccountKey) : MANUAL_JOURNAL_KEY;
        return { activeAccountKey: active, journals: nextJournals };
      }
      // Legacy single-journal blob → manual journal.
      return { activeAccountKey: MANUAL_JOURNAL_KEY, journals: { [MANUAL_JOURNAL_KEY]: normalizeStatePayload(parsed) } };
    } catch (err) {
      console.warn('Could not read local journal storage.', err);
      return fallback();
    }
  }
  function saveJournalStore() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ version: 2, activeAccountKey, journals }));
      return true;
    } catch (err) {
      console.warn('Could not save journal state.', err);
      toast('Browser storage is full. Export a backup or remove large attachments.', 'error');
      return false;
    }
  }
  function loadState() {
    const store = readJournalStore();
    return store.journals[store.activeAccountKey] || defaultState();
  }
  function currentCloudRevision() {
    return Number(cloudRevisions[activeAccountKey] || 0);
  }
  function setCloudRevision(key, value) {
    cloudRevisions[String(key || MANUAL_JOURNAL_KEY)] = Number(value) || 0;
  }
  function persistState() {
    try {
      journals[activeAccountKey] = state;
      if (!saveJournalStore()) return false;
      if(productionMode&&!ui.aiRequesting)ui.aiCloudConsent=false;
      if (productionMode && isAuthenticated && cloudReady && !cloudConflict) scheduleCloudSync();
      return true;
    } catch (err) {
      console.warn('Could not save journal state.', err);
      toast('Browser storage is full. Export a backup or remove large attachments.', 'error');
      return false;
    }
  }
  function normalizeStatePayload(parsed) {
    const base = defaultState();
    const source = parsed && typeof parsed === 'object' ? parsed : {};
    return { ...base, ...source, settings: { ...base.settings, ...(source.settings || {}) }, trades: Array.isArray(source.trades) ? source.trades : [], setups: Array.isArray(source.setups) ? source.setups : [], plans: Array.isArray(source.plans) ? source.plans : [], aiReviews: Array.isArray(source.aiReviews) ? source.aiReviews : [] };
  }
  function hasLocalJournalData(value = state) {
    return Boolean(value && ((value.trades||[]).length || (value.setups||[]).length || (value.plans||[]).length || (value.aiReviews||[]).length || value.settings?.startingBalance || value.settings?.dailyLossLimit || value.settings?.maxDailyTrades));
  }
  // EA closes imported before per-account keying all landed in the legacy manual
  // journal. Attribute any broker-sourced trades to their account journal (by
  // login/server, or the sole connected account) and drop the manual journal
  // once it no longer holds hand-entered data.
  function migrateManualBrokerTrades() {
    const manual = journals[MANUAL_JOURNAL_KEY];
    if (!manual || !(manual.trades || []).length) return false;
    const accountKeys = Object.keys(journals).filter(key => key !== MANUAL_JOURNAL_KEY && journalKeyParts(key));
    const soleKey = accountKeys.length === 1 ? accountKeys[0] : '';
    const remaining = [];
    const moves = new Map();
    for (const trade of manual.trades) {
      const platform = tradePlatform(trade) || 'mt4';
      const login = String(trade.mt4Login || '');
      const server = String(trade.mt4Server || '');
      let key = '';
      if (login && server) key = accountJournalKey(platform, login, server);
      else if (isBrokerSource(tradePlatform(trade)) && soleKey && journalKeyParts(soleKey)?.platform === platform) key = soleKey;
      if (!key) { remaining.push(trade); continue; }
      if (!moves.has(key)) moves.set(key, []);
      moves.get(key).push(trade);
    }
    if (!moves.size) return false;
    for (const [key, rows] of moves) {
      if (!journals[key]) journals[key] = defaultState();
      const target = journals[key];
      const targetCurrency = String(target.settings?.accountCurrency || '').trim().toUpperCase();
      const rowCurrencies = new Set(rows.map(row => String(row.accountCurrency || '').trim().toUpperCase()).filter(Boolean));
      if (rowCurrencies.size > 1 || (targetCurrency && [...rowCurrencies][0] && targetCurrency !== [...rowCurrencies][0])) {
        for (const row of rows) remaining.push(row);
        continue;
      }
      const importCurrency = [...rowCurrencies][0] || '';
      if (!targetCurrency && importCurrency) target.settings.accountCurrency = importCurrency;
      const known = new Set((target.trades || []).map(row => String(row.sourceEventId || row.id || '')).filter(Boolean));
      const additions = [];
      for (const row of rows) {
        const id = String(row.sourceEventId || row.id || '');
        if (id && known.has(id)) continue;
        if (id) known.add(id);
        additions.push(row);
      }
      if (additions.length) target.trades = [...(target.trades || []), ...additions];
    }
    manual.trades = remaining;
    const manualHasContent = (manual.trades || []).length || (manual.setups || []).length || (manual.plans || []).length || (manual.aiReviews || []).length;
    if (!manualHasContent) {
      const primary = moves.keys().next().value;
      const target = journals[primary];
      if (target?.settings && manual.settings) {
        for (const field of ['startingBalance', 'dailyLossLimit', 'maxDailyTrades', 'weeklyGoal']) {
          if (manual.settings[field] && !target.settings[field]) target.settings[field] = manual.settings[field];
        }
      }
      delete journals[MANUAL_JOURNAL_KEY];
      if (activeAccountKey === MANUAL_JOURNAL_KEY && journals[primary]) {
        activeAccountKey = primary;
        state = journals[primary];
      }
    }
    try { saveJournalStore(); } catch (_) {}
    return true;
  }
  function backupLocalJournal() {
    try { localStorage.setItem(CLOUD_BACKUP_KEY, JSON.stringify(state)); } catch (_) {}
  }
  function remotePathFromId(id) { return String(id||'').startsWith('remote:') ? String(id).slice(7) : ''; }
  function updateCloudStatusDisplay() {
    const node = document.querySelector('[data-cloud-status]');
    if (!node) return;
    const labels = { local:'Local preview', offline:'Cloud offline', loading:'Loading cloud…', pending:'Sync queued', syncing:'Syncing…', synced:'Cloud synced', conflict:'Sync conflict', error:'Sync error' };
    node.textContent = labels[cloudSyncStatus] || 'Cloud status';
    node.className = `local-pill cloud-status-${cloudSyncStatus}`;
    node.title = cloudSyncError || (productionMode ? 'Private Supabase journal sync' : 'This prototype saves data in this browser.');
  }
  function scheduleCloudSync() {
    if (!productionMode || !cloud || !cloudReady || !isAuthenticated || cloudConflict) return;
    cloudSyncStatus = 'pending'; cloudSyncError = ''; updateCloudStatusDisplay();
    if (cloudSyncTimer) clearTimeout(cloudSyncTimer);
    cloudSyncTimer = window.setTimeout(() => syncStateToCloud(), 700);
  }
  async function normalizeImageBlobForCloud(blob) {
    const accepted = ['image/png','image/jpeg','image/webp'];
    if (accepted.includes(blob.type)) return blob;
    if (blob.type !== 'image/svg+xml') throw new Error('Cloud image sync supports PNG, JPG, and WebP only.');
    const objectUrl = URL.createObjectURL(blob);
    try {
      const image = new Image();
      image.src = objectUrl;
      await image.decode();
      const canvas = document.createElement('canvas');
      canvas.width = image.naturalWidth || image.width;
      canvas.height = image.naturalHeight || image.height;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('Could not convert the sample chart for cloud storage.');
      context.drawImage(image,0,0);
      const png = await new Promise((resolve,reject)=>canvas.toBlob(result=>result?resolve(result):reject(new Error('Image conversion failed.')),'image/png'));
      return png;
    } finally { URL.revokeObjectURL(objectUrl); }
  }
  function fileExtensionForMime(mime) { return mime==='image/png'?'png':mime==='image/webp'?'webp':'jpg'; }
  function readPendingRemoteDeletes() { try { return JSON.parse(localStorage.getItem(REMOTE_DELETE_KEY)||'[]').filter(x=>typeof x==='string'); } catch (_) { return []; } }
  function queueRemoteDelete(path) {
    if(!path)return;
    const paths=new Set(readPendingRemoteDeletes());paths.add(path);
    try { localStorage.setItem(REMOTE_DELETE_KEY,JSON.stringify([...paths])); } catch (_) {}
  }
  function referencedCloudImagePaths(value=state) {
    const referenced=new Set();
    for(const trade of value?.trades||[])for(const list of Object.values(getStageImages(trade)))for(const photo of list){const path=photo.cloudStoragePath||remotePathFromId(photo.id);if(path)referenced.add(path);}
    return referenced;
  }
  async function flushPendingRemoteDeletes() {
    if(!cloud||!isAuthenticated)return;
    const paths=readPendingRemoteDeletes();if(!paths.length)return;
    const referenced=referencedCloudImagePaths();const failed=[];
    for(const path of paths){if(referenced.has(path))continue;try{await cloud.deleteImage(path);}catch(_){failed.push(path);}}
    try { localStorage.setItem(REMOTE_DELETE_KEY,JSON.stringify(failed)); } catch (_) {}
  }
  async function buildCloudSnapshot(newlyUploaded=[]) {
    const copy = JSON.parse(JSON.stringify(state));
    for (let tradeIndex=0; tradeIndex<state.trades.length; tradeIndex++) {
      const sourceTrade=state.trades[tradeIndex];const copyTrade=copy.trades[tradeIndex];
      copyTrade.stages={before:[],during:[],after:[]};
      const stages=getStageImages(sourceTrade);
      for(const stage of ['before','during','after']){
        for(const photo of stages[stage]){
          let path=photo.cloudStoragePath||remotePathFromId(photo.id);
          let mime=photo.type||'image/jpeg';
          if(!path){
            const dataUrl=await getPhotoDataUrl(photo.id);
            if(!dataUrl)throw new Error(`Image “${photo.name||stage}” is not available to sync. Export a backup and reattach it.`);
            const blob=await normalizeImageBlobForCloud(dataUrlToBlob(dataUrl));
            if(blob.size>10*1024*1024)throw new Error(`Image “${photo.name||stage}” exceeds the 10 MB cloud limit.`);
            mime=blob.type||mime;
            const safeTrade=String(sourceTrade.id||uid('trade')).replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,100);
            path=`${cloudUser.id}/${safeTrade}/${stage}/${uid('img')}.${fileExtensionForMime(mime)}`;
            await cloud.uploadImage(path,blob,mime);
            newlyUploaded.push(path);photo.cloudStoragePath=path;
          }
          cloudImagePathCache.set(photo.id,path);
          copyTrade.stages[stage].push({id:`remote:${path}`,cloudStoragePath:path,name:photo.name||`${stage}.image`,type:mime});
        }
      }
    }
    return copy;
  }
  async function syncStateToCloud() {
    if(!productionMode||!cloud||!cloudReady||!isAuthenticated||cloudConflict)return;
    if(cloudSyncBusy){cloudSyncPending=true;return;}
    cloudSyncBusy=true;cloudSyncStatus='syncing';cloudSyncError='';updateCloudStatusDisplay();
    const newlyUploaded=[];
    const syncKey=activeAccountKey;
    try{
      const payload=await buildCloudSnapshot(newlyUploaded);
      const saved=await cloud.saveSnapshot(payload,currentCloudRevision(),syncKey);
      setCloudRevision(syncKey,saved.revision);cloudSyncStatus='synced';cloudSyncError='';
      try { saveJournalStore(); } catch (_) {}
      await flushPendingRemoteDeletes();
    }catch(error){
      for(const path of newlyUploaded){try{await cloud.deleteImage(path);}catch(_){queueRemoteDelete(path);}for(const trade of state.trades)for(const list of Object.values(getStageImages(trade)))for(const photo of list)if(photo.cloudStoragePath===path){delete photo.cloudStoragePath;cloudImagePathCache.delete(photo.id);}}
      const message=String(error?.message||error||'Cloud sync failed.');
      if(message.includes('JOURNAL_CONFLICT')||error?.code==='40001'){
        cloudConflict=true;cloudSyncStatus='conflict';cloudSyncError='Another device saved newer data. Reload the cloud snapshot before making more changes.';
      }else{
        cloudSyncStatus='error';cloudSyncError=message;
      }
      showToast(cloudSyncError,'error');
    }finally{
      cloudSyncBusy=false;updateCloudStatusDisplay();
      if(cloudSyncPending&&!cloudConflict){cloudSyncPending=false;scheduleCloudSync();}
    }
  }
  async function reloadCloudSnapshot() {
    if(!cloud||!isAuthenticated)return;
    cloudSyncStatus='loading';updateCloudStatusDisplay();
    try{
      const remote=await cloud.loadSnapshot(activeAccountKey);
      if(remote){backupLocalJournal();state=normalizeStatePayload(remote.payload);journals[activeAccountKey]=state;setCloudRevision(activeAccountKey,remote.revision);}
      else{state=defaultState();journals[activeAccountKey]=state;setCloudRevision(activeAccountKey,0);}
      cloudConflict=false;cloudReady=true;cloudSyncStatus=remote?'synced':'pending';
      try{saveJournalStore();}catch(_){}
      if(!remote)scheduleCloudSync();
      try { await loadMt4AccountEvents({ renderAfter: false }); } catch (_) { /* MT4 feed may not be configured yet. */ }
      render();toast(remote?'Cloud journal reloaded.':'Empty cloud journal started.');
    }catch(error){cloudSyncStatus='error';cloudSyncError=String(error?.message||error);updateCloudStatusDisplay();toast('Could not reload the cloud journal.','error');}
  }
  function stopCloudRefreshLoop() {
    if (cloudPollTimer) clearInterval(cloudPollTimer);
    cloudPollTimer = null;
    cloudPollBusy = false;
  }
  function startCloudRefreshLoop() {
    stopCloudRefreshLoop();
    if (!productionMode || !cloud || !cloud.loadSnapshot || !isAuthenticated) return;
    cloudPollTimer = window.setInterval(async () => {
      if (cloudPollBusy || document.visibilityState === 'hidden' || !cloudReady || !isAuthenticated || cloudConflict) return;
      cloudPollBusy = true;
      try {
        await loadMt4AccountEvents({ renderAfter: false, includeEvents: ui.view === 'mt4-activity' });
        const deferJournalRefresh = Boolean(ui.modal || ui.aiRequesting || ui.aiCloudConsent);
        if (!deferJournalRefresh && cloudSyncStatus === 'synced') {
          const remote = await cloud.loadSnapshot(activeAccountKey);
          if (remote && Number(remote.revision || 0) > currentCloudRevision()) {
            backupLocalJournal();
            state = normalizeStatePayload(remote.payload);
            journals[activeAccountKey] = state;
            setCloudRevision(activeAccountKey, Number(remote.revision || 0));
            try { saveJournalStore(); } catch (_) {}
            pendingMt4Render = true;
          }
        }
        if (pendingMt4Render && canRenderMt4Update()) {
          pendingMt4Render = false;
          render();
        }
      } catch (_) {
        // Best-effort background refresh; manual refresh and sync controls report errors.
      } finally {
        cloudPollBusy = false;
      }
    }, 1000);
  }

  function emptyMt4Stats() {
    return { eventCount: 0, tradeCloseCount: 0, longCloseCount: 0, shortCloseCount: 0, takeProfitCount: 0, stopLossCount: 0, unclassifiedCloseCount: 0 };
  }
  function mt4RowStats(row) {
    const count = value => Math.max(0, Number(value) || 0);
    if (!row) return emptyMt4Stats();
    return {
      eventCount: count(row.event_count),
      tradeCloseCount: count(row.trade_close_count),
      longCloseCount: count(row.long_close_count),
      shortCloseCount: count(row.short_close_count),
      takeProfitCount: count(row.take_profit_count),
      stopLossCount: count(row.stop_loss_count),
      unclassifiedCloseCount: count(row.unclassified_close_count)
    };
  }
  function mt4RowsStats(rows) {
    const total = emptyMt4Stats();
    for (const row of rows) {
      const stats = mt4RowStats(row);
      for (const key of Object.keys(total)) total[key] += stats[key] || 0;
    }
    return total;
  }
  function activeAccountSnapshotRow() {
    if (!mt4Accounts.length) return null;
    if (activeAccountKey !== MANUAL_JOURNAL_KEY) return mt4Accounts.find(row => row.account_key === activeAccountKey) || null;
    return mt4Accounts.length === 1 ? mt4Accounts[0] : null;
  }
  function mt4ActivityScopeRows() {
    if (ui.mt4ActivityAccount === 'all') return mt4Accounts;
    const key = ui.mt4ActivityAccount === 'active' ? activeAccountKey : ui.mt4ActivityAccount;
    if (key !== MANUAL_JOURNAL_KEY) {
      const row = mt4Accounts.find(item => item.account_key === key);
      if (row) return [row];
    }
    return mt4Accounts;
  }
  function mt4EventAccountKey(event) {
    const account = event?.account || {};
    return accountJournalKey(
      event?.platform || account.platform || 'mt4',
      event?.account_login || account.login || '',
      event?.account_server || account.server || ''
    );
  }
  function syncActiveAccountSnapshot() {
    mt4AccountSnapshot = activeAccountSnapshotRow();
    const eventCount = Number(mt4AccountStats.eventCount) || 0;
    mt4AccountStats = mt4RowsStats(mt4ActivityScopeRows());
    mt4AccountStats.eventCount = eventCount;
  }
  function journalEntries() {
    const entries = [];
    const seen = new Set();
    const manualState = journals[MANUAL_JOURNAL_KEY];
    if (manualState && (hasLocalJournalData(manualState) || activeAccountKey === MANUAL_JOURNAL_KEY)) {
      entries.push({
        key: MANUAL_JOURNAL_KEY,
        label: 'Manual journal',
        sub: 'Manual entries',
        platform: '',
        currency: manualState.settings?.accountCurrency || ''
      });
      seen.add(MANUAL_JOURNAL_KEY);
    }
    for (const row of mt4Accounts) {
      if (!row?.account_key || seen.has(row.account_key)) continue;
      seen.add(row.account_key);
      entries.push({
        key: row.account_key,
        label: `${brokerLabel(row.platform)} · ${row.account_login}`,
        sub: row.account_server || '',
        platform: row.platform,
        currency: row.account_currency || '',
        snapshot: row
      });
    }
    for (const key of Object.keys(journals)) {
      if (key === MANUAL_JOURNAL_KEY || seen.has(key)) continue;
      seen.add(key);
      const parts = journalKeyParts(key);
      entries.push({
        key,
        label: parts ? `${brokerLabel(parts.platform)} · ${parts.login}` : key,
        sub: parts?.server || 'Saved journal',
        platform: parts?.platform || '',
        currency: '',
        saved: true
      });
    }
    return entries;
  }
  async function switchJournal(key, { notify = true } = {}) {
    const targetKey = String(key || MANUAL_JOURNAL_KEY);
    if (targetKey === activeAccountKey) return false;
    if (cloudConflict) { toast('Resolve the sync conflict before switching journals.', 'error'); return false; }
    if (cloudSyncBusy) { toast('A cloud sync is still running. Try again in a moment.', 'error'); return false; }
    // Flush queued saves for the journal we are leaving before the active state changes.
    for (let flush = 0; flush < 2 && cloudSyncTimer; flush++) {
      clearTimeout(cloudSyncTimer); cloudSyncTimer = null;
      try { await syncStateToCloud(); } catch (_) {}
    }
    journals[activeAccountKey] = state;
    activeAccountKey = targetKey;
    if (!journals[targetKey] || typeof journals[targetKey] !== 'object') journals[targetKey] = defaultState();
    state = journals[targetKey];
    cloudConflict = false;
    ui.aiOutput = null; ui.aiTradeId = ''; ui.aiWeek = ''; ui.aiCloudConsent = false;
    ui.symbol = 'all'; ui.search = ''; ui.mt4ActivityAccount = 'active';
    mt4AccountEvents = []; mt4EventsError = '';
    if (productionMode && isAuthenticated && cloud && cloudReady) {
      cloudSyncStatus = 'loading'; updateCloudStatusDisplay();
      try {
        const remote = await cloud.loadSnapshot(targetKey);
        if (remote) {
          if (hasLocalJournalData(state)) backupLocalJournal();
          state = normalizeStatePayload(remote.payload);
          journals[targetKey] = state;
          setCloudRevision(targetKey, remote.revision);
          cloudSyncStatus = 'synced';
        } else {
          cloudSyncStatus = 'synced';
          if (currentCloudRevision() === 0 && hasLocalJournalData(state)) { cloudSyncStatus = 'pending'; scheduleCloudSync(); }
        }
        cloudConflict = false;
      } catch (error) {
        cloudSyncStatus = 'error'; cloudSyncError = String(error?.message || error || 'Cloud journal could not be loaded.');
      }
      updateCloudStatusDisplay();
    } else {
      cloudSyncStatus = productionMode ? (cloud ? 'offline' : 'error') : 'local';
    }
    try { saveJournalStore(); } catch (_) {}
    syncActiveAccountSnapshot();
    try { await loadMt4AccountEvents({ renderAfter: false }); } catch (_) { /* feed optional */ }
    render();
    if (notify) {
      const entry = journalEntries().find(item => item.key === targetKey);
      toast(`Switched to ${entry ? entry.label : targetKey}.`);
    }
    return true;
  }
  // First connection convenience: when the manual journal is still empty and exactly one
  // account is connected, activate that account's journal automatically so broker closes
  // are visible without a manual switch. Runs once per account key; returning to the
  // manual journal afterwards is never overridden.
  function maybeAutoActivateSingleAccountJournal() {
    if (activeAccountKey !== MANUAL_JOURNAL_KEY) return false;
    if (cloudConflict || cloudSyncBusy) return false;
    if (hasLocalJournalData(state)) return false;
    if (mt4Accounts.length !== 1) return false;
    const key = mt4Accounts[0]?.account_key;
    if (!key || key === MANUAL_JOURNAL_KEY || !journalKeyParts(key)) return false;
    const autoActivated = readAutoActivatedAccountKeys();
    if (autoActivated.has(key)) return false;
    autoActivated.add(key);
    try { localStorage.setItem(ACCOUNT_AUTO_ACTIVATE_KEY, JSON.stringify([...autoActivated].slice(-50))); } catch (_) {}
    const result = switchJournal(key, { notify: false });
    if (result && typeof result.catch === 'function') result.catch(() => {});
    return true;
  }
  function readAutoActivatedAccountKeys() {
    try {
      const parsed = JSON.parse(localStorage.getItem(ACCOUNT_AUTO_ACTIVATE_KEY) || '[]');
      return new Set(Array.isArray(parsed) ? parsed.map(String) : []);
    } catch (_) { return new Set(); }
  }
  function renderAccountSwitcher() {
    const entries = journalEntries();
    if (entries.length < 2) return '';
    return `<label class="account-selector"><span class="small-muted">Journal</span><div class="select-wrap"><select data-filter="account-journal" aria-label="Active account journal">${entries.map(entry => `<option value="${escapeAttr(entry.key)}" ${entry.key === activeAccountKey ? 'selected' : ''}>${escapeHtml(`${entry.label}${entry.sub ? ` · ${entry.sub}` : ''}`)}</option>`).join('')}</select></div></label>`;
  }
  function renderConnectedAccountsPanel() {
    const entries = journalEntries();
    return `<section class="surface-card settings-panel" id="settings-accounts" style="margin-top:15px"><h2>Connected accounts</h2><p>Each connected MT4 or MT5 account keeps its own journal — trades, setups, plans, settings, and sync revisions. Switch any time from the Journal selector in the top bar; only the active journal syncs to the cloud.</p>
      <div class="account-journal-list">${entries.map(entry => {
        const active = entry.key === activeAccountKey;
        const tradeCount = (journals[entry.key]?.trades || []).length;
        const detail = [entry.label, entry.sub, `${tradeCount} record${tradeCount === 1 ? '' : 's'}`].filter(Boolean).join(' · ');
        return `<div class="settings-row account-journal-row"><div><strong>${escapeHtml(entry.label)}</strong><span>${escapeHtml(detail)}</span></div>${active ? '<span class="pill mint">Active</span>' : `<button class="secondary-button small" data-action="switch-journal" data-account-key="${escapeAttr(entry.key)}">Switch journal</button>`}</div>`;
      }).join('')}</div>
    </section>`;
  }

  function connectRowState(row) {
    if (!row) return 'waiting';
    const updated = Date.parse(row.updated_at || row.observed_at || '');
    if (!Number.isFinite(updated)) return 'online';
    return Date.now() - updated <= 30000 ? 'online' : 'stale';
  }
  function renderConnectAccountCard(entry) {
    const isManual = entry.key === MANUAL_JOURNAL_KEY;
    const row = entry.snapshot || null;
    const active = entry.key === activeAccountKey;
    const currency = row?.account_currency || entry.currency || state.settings.accountCurrency || 'USD';
    const tradeCount = (journals[entry.key]?.trades || []).length;
    const stats = mt4RowStats(row);
    const stateLabel = connectRowState(row);
    const timestamp = row?.updated_at || row?.observed_at || '';
    const timeLabel = timestamp && Number.isFinite(Date.parse(timestamp))
      ? new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
    const statusText = isManual
      ? `${tradeCount} hand-entered or imported record${tradeCount === 1 ? '' : 's'} · not tied to a broker account`
      : row
        ? stateLabel === 'online' ? `Online · updated ${timeLabel || 'just now'}` : `Stale · last update ${timeLabel || 'unknown'}`
        : entry.saved ? 'Saved journal · not reporting right now' : 'Waiting for the first account snapshot';
    const statusPill = isManual ? '<span class="pill">Manual</span>'
      : row
        ? stateLabel === 'online' ? '<span class="pill mint">Online</span>' : '<span class="pill amber">Stale</span>'
        : '<span class="pill">Waiting</span>';
    const metrics = row ? `<div class="connect-metrics">
        <div class="metric-mini"><div class="label">Balance</div><div class="value">${escapeHtml(money(row.account_balance ?? null, false, currency))}</div></div>
        <div class="metric-mini"><div class="label">Equity</div><div class="value">${escapeHtml(money(row.account_equity ?? null, false, currency))}</div></div>
        <div class="metric-mini"><div class="label">Floating P/L</div><div class="value ${row.floating_pl != null ? pnlClass(row.floating_pl) : ''}">${row.floating_pl != null ? escapeHtml(money(row.floating_pl, false, currency)) : '—'}</div></div>
        <div class="metric-mini"><div class="label">Closed records</div><div class="value">${stats.tradeCloseCount}</div></div>
      </div>` : '';
    const eyebrow = isManual
      ? 'MANUAL ENTRIES · NOT A BROKER CONNECTION'
      : `${escapeHtml(entry.platform ? brokerLabel(entry.platform).toUpperCase() : '')} · ${escapeHtml(entry.sub || '')}`;
    return `<article class="surface-card connect-card${active ? ' active' : ''}">
      <div class="connect-card-head">
        <div>
          <div class="eyebrow">${eyebrow}</div>
          <h3>${escapeHtml(entry.label)}</h3>
          <p>${escapeHtml(statusText)}</p>
        </div>
        <div class="inline-row">${statusPill}${active ? '<span class="pill mint">Active</span>' : `<button class="secondary-button small" data-action="switch-journal" data-account-key="${escapeAttr(entry.key)}">Switch journal</button>`}</div>
      </div>
      ${metrics}
    </article>`;
  }
  function renderConnect() {
    const entries = journalEntries();
    const manualEntry = entries.find(entry => entry.key === MANUAL_JOURNAL_KEY);
    const accountEntries = entries.filter(entry => entry.key !== MANUAL_JOURNAL_KEY);
    const isLive = localMt4Mode || productionMode;
    const ingestHost = String((cloud && cloud.projectUrl) || 'YOUR_PROJECT.supabase.co').replace(/^https?:\/\//, '');
    const ingestEndpoint = localMt4Mode ? 'http://127.0.0.1/functions/v1/mt4-ingest' : `https://${ingestHost}/functions/v1/mt4-ingest`;
    const modeBanner = !isLive
      ? `<div class="warning-banner"><strong>Browser-only demo.</strong> Live broker connections run in the local preview bridge (<code>?mt4Local=1</code>) or the production app. Open one of those to connect an account.</div>`
      : localMt4Mode
        ? `<div class="info-banner local-mt4-notice"><strong>Local loopback test.</strong> The EA posts to the port-80 Python mock on this computer only; nothing is sent to Supabase. Re-run this check after attaching a new account's EA to see it appear.</div>`
        : `<div class="info-banner"><strong>Private cloud.</strong> Each EA posts to your Supabase project's <code>mt4-ingest</code> function with a write-only device token. Every connected account keeps its own journal; only the active journal syncs.</div>`;
    const accountCards = accountEntries.map(renderConnectAccountCard).join('');
    const emptyState = accountEntries.length ? '' : `<div class="surface-card connect-card"><div class="empty-state"><div class="empty-visual">${icon('plug',24)}</div><h3>${mt4EventsLoading ? 'Checking for accounts…' : 'No MetaTrader account connected yet'}</h3><p>${mt4EventsLoading ? 'Reading the account dashboard.' : 'Compile the EA below, attach it to a demo account chart, and its journal will appear here within seconds of the first snapshot.'}</p></div></div>`;
    const manualCard = manualEntry ? renderConnectAccountCard(manualEntry) : '';
    const refreshButton = isLive ? `<button class="secondary-button small" data-action="mt4-refresh" ${mt4EventsLoading ? 'disabled' : ''}>${icon('upload',14)} ${mt4EventsLoading ? 'Checking…' : 'Check for accounts'}</button>` : '';
    const dashboardError = mt4DashboardError ? `<div class="warning-banner"><strong>Account dashboard not ready.</strong> ${escapeHtml(mt4DashboardError)}${productionMode ? ' Apply the multi-account migration and deploy the ingest function.' : ''}</div>` : '';
    return `<section class="connect-page">
      ${modeBanner}${dashboardError}
      <div class="surface-card connect-intro">
        <div><div class="eyebrow">CONNECTED ACCOUNTS</div><h2>Your journals</h2><p>Each connected MT4 or MT5 account automatically gets its own journal — trades, setups, plans, risk settings, and cloud sync stay separate.${manualEntry ? ' The <strong>Manual journal</strong> holds entries you added by hand or imported yourself; it is not a broker connection.' : ''} Switch any time from the Journal selector in the top bar.</p></div>
        <div class="inline-row">${refreshButton}</div>
      </div>
      ${accountCards}${emptyState}${manualCard}
      <div class="surface-card connect-steps">
        <div class="section-title-row"><div><h2>Connect another account</h2><p>One EA copy per account. Use a demo account first.</p></div></div>
        <ol class="connect-step-list">
          <li><strong>Compile the publisher</strong><p>MT4: copy <code>mt4-integration/NketiahAccountLogger.mq4</code> into <code>MQL4/Experts</code> and compile in MetaEditor. MT5: copy <code>NketiahAccountLogger.mq5</code> into <code>MQL5/Experts</code> and compile.</p></li>
          <li><strong>Set the EA inputs</strong><p>Ingest endpoint: <code>${escapeHtml(ingestEndpoint)}</code> · Device token: your write-only private token (the same token works for every account you connect) · Poll seconds: <code>5</code>.</p></li>
          <li><strong>Allow WebRequest</strong><p>Tools → Options → Expert Advisors: allow ${localMt4Mode ? '<code>http://127.0.0.1</code>' : `<code>https://${escapeHtml(ingestHost)}</code>`} for MT4, or the same host under <code>Allow WebRequest for listed URL</code> in MT5.</p></li>
          <li><strong>Attach and fund the demo</strong><p>Add the EA to one chart on the new account, open Account History → All History once, and keep the terminal running. The account appears above within seconds of its first snapshot and gets its own journal. The first connected account auto-activates on its own.</p></li>
        </ol>
        <p class="small-muted">The device token is write-only: the EA can post events but cannot read your journal. Never put the Supabase service-role key inside an EA.</p>
      </div>
    </section>`;
  }

  async function handleCloudAuthState(user) {
    if(!productionMode)return;
    if(!user){
      cloudUser=null;cloudReady=false;cloudRevisions={};cloudConflict=false;isAuthenticated=false;cloudSyncStatus=cloud?'offline':'error';
      mt4AccountEvents=[];mt4EventsError='';mt4DashboardError='';mt4Accounts=[];mt4AccountSnapshot=null;mt4AccountStats={eventCount:0,tradeCloseCount:0,longCloseCount:0,shortCloseCount:0,takeProfitCount:0,stopLossCount:0,unclassifiedCloseCount:0};mt4EventsLoading=false;
      stopCloudRefreshLoop();
      if(cloudSyncTimer)clearTimeout(cloudSyncTimer);
      clearImageUrlCache();render();return;
    }
    if(!cloud||!cloud.isConfigured){ui.loginError=window.NketiahProductionError||'Supabase configuration is missing.';render();return;}
    if(String(user.email||'').toLowerCase()!==cloud.ownerEmail){
      ui.loginError='This Google account is not the configured owner account.';render();
      try{await cloud.signOut();}catch(_){}
      return;
    }
    cloudUser=user;isAuthenticated=true;cloudReady=false;cloudSyncStatus='loading';cloudSyncError='';ui.loginError='';render();
    try{
      const local=loadState();const remote=await cloud.loadSnapshot(activeAccountKey);
      if(remote){
        if(hasLocalJournalData(local))backupLocalJournal();
        state=normalizeStatePayload(remote.payload);journals[activeAccountKey]=state;setCloudRevision(activeAccountKey,remote.revision);cloudReady=true;cloudSyncStatus='synced';
        try{saveJournalStore();}catch(_){}
      }else{
        setCloudRevision(activeAccountKey,0);cloudReady=true;
        if(hasLocalJournalData(local)){
          backupLocalJournal();
          const upload=window.confirm('This account has no cloud journal yet. Upload this browser’s local trades, notes, settings, and images to your private Supabase project? Choose Cancel to keep a local backup and start with an empty cloud journal.');
          if(upload){state=normalizeStatePayload(local);journals[activeAccountKey]=state;cloudSyncStatus='pending';await syncStateToCloud();}
          else{state=defaultState();journals[activeAccountKey]=state;cloudSyncStatus='pending';scheduleCloudSync();}
        }else{state=defaultState();journals[activeAccountKey]=state;cloudSyncStatus='pending';scheduleCloudSync();}
      }
      try { await loadMt4AccountEvents({ renderAfter: false }); } catch (_) { /* MT4 activity is optional until its migration is deployed. */ }
      startCloudRefreshLoop();
      startRiskClock();
      ui.view='performance';render();updateCloudStatusDisplay();toast(remote&&hasLocalJournalData(local)?'Local browser data backed up; loaded the cloud journal.':'Private journal session ready.');
    }catch(error){
      cloudReady=false;cloudSyncStatus='error';cloudSyncError=String(error?.message||error);isAuthenticated=true;cloudUser=user;
      startRiskClock();
      render();
    }
  }
  function openImageDb() {
    if (!('indexedDB' in window)) return Promise.resolve(null);
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE, { keyPath: 'id' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
    });
    return dbPromise;
  }
  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }
  function dataUrlToBlob(dataUrl) {
    const [meta, data] = String(dataUrl).split(',');
    const mime = (meta.match(/data:([^;]+)/) || [])[1] || 'application/octet-stream';
    const binary = atob(data || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  }
  async function savePhoto(file) {
    const id = uid('photo');
    const db = await openImageDb();
    if (!db) {
      return { id: await fileToDataUrl(file), name: file.name, type: file.type, fallback: true };
    }
    return new Promise((resolve, reject) => {
      const tx = db.transaction(DB_STORE, 'readwrite');
      tx.objectStore(DB_STORE).put({ id, name: file.name, type: file.type, blob: file });
      tx.oncomplete = () => resolve({ id, name: file.name, type: file.type });
      tx.onerror = () => reject(tx.error || new Error('Could not save image'));
    });
  }
  async function getPhoto(id) {
    if (!id) return null;
    if (String(id).startsWith('data:')) return id;
    const remotePath=remotePathFromId(id)||cloudImagePathCache.get(id);
    if (imageUrlCache.has(id)) {
      const expires=imageUrlExpiry.get(id);
      if(remotePath&&expires&&expires<=Date.now()){imageUrlCache.delete(id);imageUrlExpiry.delete(id);}
      else return imageUrlCache.get(id);
    }
    if(remotePath&&cloud&&isAuthenticated){
      try{const url=await cloud.createSignedImageUrl(remotePath);imageUrlCache.set(id,url);imageUrlExpiry.set(id,Date.now()+55*60*1000);cloudImagePathCache.set(id,remotePath);return url;}catch(_){return null;}
    }
    const db = await openImageDb();
    if (!db) return null;
    return new Promise((resolve) => {
      const tx = db.transaction(DB_STORE, 'readonly');
      const request = tx.objectStore(DB_STORE).get(id);
      request.onsuccess = () => {
        const record = request.result;
        if (!record || !record.blob) { resolve(null); return; }
        const url = URL.createObjectURL(record.blob);
        imageUrlCache.set(id, url);
        resolve(url);
      };
      request.onerror = () => resolve(null);
    });
  }
  async function getPhotoDataUrl(id) {
    if (!id) return null;
    if (String(id).startsWith('data:')) return id;
    const remotePath=remotePathFromId(id)||cloudImagePathCache.get(id);
    if(remotePath&&cloud&&isAuthenticated){
      try{return await fileToDataUrl(await cloud.downloadImage(remotePath));}catch(_){return null;}
    }
    const db = await openImageDb();
    if (!db) return null;
    return new Promise((resolve) => {
      const tx = db.transaction(DB_STORE, 'readonly');
      const request = tx.objectStore(DB_STORE).get(id);
      request.onsuccess = async () => {
        if (!request.result?.blob) { resolve(null); return; }
        try { resolve(await fileToDataUrl(request.result.blob)); } catch (_) { resolve(null); }
      };
      request.onerror = () => resolve(null);
    });
  }
  async function deletePhoto(id) {
    if (!id) return;
    const remotePath=remotePathFromId(id)||cloudImagePathCache.get(id);
    const cachedUrl=imageUrlCache.get(id);if(cachedUrl?.startsWith('blob:'))URL.revokeObjectURL(cachedUrl);
    imageUrlCache.delete(id);imageUrlExpiry.delete(id);
    if(remotePath){
      cloudImagePathCache.delete(id);
      queueRemoteDelete(remotePath);
    }
    if(String(id).startsWith('data:'))return;
    const db = await openImageDb();
    if (!db) return;
    imageUrlCache.delete(id);
    return new Promise((resolve) => {
      const tx = db.transaction(DB_STORE, 'readwrite');
      tx.objectStore(DB_STORE).delete(id);
      tx.oncomplete = resolve;
      tx.onerror = resolve;
    });
  }
  function clearImageUrlCache() {
    for(const url of imageUrlCache.values())if(String(url).startsWith('blob:'))URL.revokeObjectURL(url);
    imageUrlCache.clear();imageUrlExpiry.clear();cloudImagePathCache.clear();
  }
  async function hydrateImages(scope = document) {
    const imgs = [...scope.querySelectorAll('img[data-photo-id]')];
    await Promise.all(imgs.map(async (img) => {
      const src = await getPhoto(img.dataset.photoId);
      if (src && img.isConnected) img.src = src;
    }));
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }
  function escapeAttr(value) { return escapeHtml(value).replace(/`/g, '&#96;'); }
  function parseDate(value) { return value ? new Date(`${value}T12:00:00`) : new Date(); }
  function formatDate(value, options = { day: 'numeric', month: 'short', year: 'numeric' }) {
    if (!value) return '—';
    const date = value instanceof Date ? new Date(value.getTime()) : parseDate(value);
    if (Number.isNaN(date.getTime())) return '—';
    return date.toLocaleDateString('en-GB', options);
  }
  function formatShortDate(value) { return formatDate(value, { day: '2-digit', month: 'short' }); }
  function journalCurrency() {
    const code = String(state?.settings?.accountCurrency || 'USD').trim().toUpperCase();
    return /^[A-Z]{3}$/.test(code) ? code : 'USD';
  }
  function money(value, compact = false, currency = journalCurrency()) {
    const amount = Number(value || 0);
    const code = /^[A-Z]{3}$/.test(String(currency||'').toUpperCase()) ? String(currency).toUpperCase() : 'USD';
    const formatter = new Intl.NumberFormat('en-US', { style: 'currency', currency: code, minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (compact && Math.abs(amount) >= 10000) return `${amount < 0 ? '−' : ''}${formatter.format(Math.abs(amount / 1000))}k`;
    return formatter.format(amount);
  }
  function fmtNumber(value, digits = 1) {
    if (value === null || value === undefined || !Number.isFinite(Number(value))) return '—';
    return new Intl.NumberFormat('en-US', { maximumFractionDigits: digits }).format(Number(value));
  }
  function sortTrades(trades) { return [...trades].sort((a, b) => (b.closedAt || '').localeCompare(a.closedAt || '') || (b.createdAt || '').localeCompare(a.createdAt || '')); }
  function getStats(trades) {
    const wins = trades.filter(t => Number(t.pnlUsd) > 0);
    const losses = trades.filter(t => Number(t.pnlUsd) < 0);
    const breakevens = trades.filter(t => Number(t.pnlUsd) === 0);
    const pnl = trades.reduce((sum, t) => sum + Number(t.pnlUsd || 0), 0);
    return { pnl, wins: wins.length, losses: losses.length, breakevens: breakevens.length, total: trades.length, winRate: trades.length ? (wins.length / trades.length) * 100 : null };
  }
  function getSetup(setupId) { return state.setups.find(s => s.id === setupId); }
  function getPlan(planId) { return state.plans.find(p => p.id === planId); }
  function getTrade(id) { return state.trades.find(t => t.id === id); }
  const stageMeta = {
    before: { label: 'Before trade', subtitle: 'Capture the zone, setup, and reason you are considering entry.', icon: 'target' },
    during: { label: 'While trade is running', subtitle: 'Record how price develops while the position is open.', icon: 'trend' },
    after: { label: 'After trade', subtitle: 'Save the close, outcome, and post-trade chart context.', icon: 'check' }
  };
  function getStageImages(trade) {
    const result = { before: [], during: [], after: [] };
    if (!trade) return result;
    for (const stage of Object.keys(result)) {
      const entries = trade.stages?.[stage];
      if (Array.isArray(entries)) result[stage].push(...entries.map(item => typeof item === 'string' ? { id: item, name: 'Chart image' } : item).filter(item => item?.id));
    }
    const legacy = trade.images || {};
    const legacyMap = [['snr','before','SNR Zone'],['confirmation','before','Confirmation'],['price','during','Price Running'],['after','after','After trade']];
    for (const [key, stage, name] of legacyMap) {
      const id = legacy[key];
      if (id && !result[stage].some(item => item.id === id)) result[stage].push({ id, name });
    }
    return result;
  }
  function getAllPhotoIds(trade) {
    const ids = new Set();
    Object.values(getStageImages(trade)).flat().forEach(item => { if (item?.id) ids.add(item.id); });
    return [...ids];
  }
  function getSelectedTrades({ includeSymbol = true, includeYear = true } = {}) {
    return state.trades.filter(t => {
      if (includeYear && ui.year !== 'all' && String(parseDate(t.closedAt).getFullYear()) !== String(ui.year)) return false;
      if (includeSymbol && ui.symbol !== 'all' && t.symbol !== ui.symbol) return false;
      return true;
    });
  }
  function resultType(trade) { const n = Number(trade.pnlUsd || 0); return n > 0 ? 'win' : n < 0 ? 'loss' : 'breakeven'; }
  function resultChip(trade) {
    const r = resultType(trade);
    const label = r === 'win' ? 'Win' : r === 'loss' ? 'Loss' : 'Breakeven';
    return `<span class="pill ${r === 'win' ? 'mint' : r === 'loss' ? 'red' : 'amber'}">${label}</span>`;
  }
  function pnlClass(value) { return Number(value) > 0 ? 'pos' : Number(value) < 0 ? 'neg' : 'zero'; }
  function showToast(message, type = 'success') {
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.textContent = message;
    toastRoot.appendChild(el);
    window.setTimeout(() => el.remove(), 3400);
  }
  const toast = showToast;

  const navItems = [
    { id: 'performance', label: 'Performance', icon: 'performance', group: 'journal' },
    { id: 'goals', label: 'Weekly goal', icon: 'target', group: 'journal' },
    { id: 'journal', label: 'Trade journal', icon: 'journal', group: 'journal' },
    { id: 'playbook', label: 'SNR playbook', icon: 'playbook', group: 'process' },
    { id: 'plans', label: 'Trade plans', icon: 'plans', group: 'process' },
    { id: 'calendar', label: 'Calendar', icon: 'calendar', group: 'review' },
    { id: 'analytics', label: 'Analytics', icon: 'analytics', group: 'review' },
    { id: 'ai', label: 'AI reviews', icon: 'sparkle', group: 'review' },
    { id: 'tools', label: 'Risk tools', icon: 'tools', group: 'review' },
    { id: 'mt4-activity', label: 'Broker activity', icon: 'bolt', group: 'review' },
    { id: 'connect', label: 'Connect', icon: 'plug', group: 'account' },
    { id: 'settings', label: 'Settings & backup', icon: 'settings', group: 'account' }
  ];
  const viewMeta = {
    performance: ['Performance', 'Keep track. Review your week. Refine your process.'],
    goals: ['Weekly goal', 'One number for the week. Pace, runway, and honest delivery.'],
    journal: ['Trade journal', 'Every closed position, with the context that matters.'],
    playbook: ['SNR playbook', 'Document the setups you trade and learn from their results.'],
    plans: ['Trade plans', 'Write down the idea before the market tests it.'],
    calendar: ['P&L calendar', 'See how your closed trades add up across the month.'],
    analytics: ['Analytics', 'Turn recorded outcomes into a clearer performance picture.'],
    ai: ['AI reviews', 'Explore trade debriefs and weekly reflections, with privacy kept in focus.'],
    tools: ['Risk tools', 'Plan position size and review your daily limits.'],
    'mt4-activity': ['MetaTrader account activity', 'Review imported trades, order events, and balance adjustments.'],
    connect: ['Connect accounts', 'Link MT4 and MT5 accounts so each one gets its own journal.'],
    settings: ['Settings & backup', 'Keep your journal preferences and data portable.']
  };
  function brandMark() {
    return `<div class="brand-mark" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="13.7" fill="#f5f1e7" stroke="#c8c4b6"/><path d="M8.5 22V10l8 10V10m2.8 12V10l5 12" stroke="#17191a" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/><circle cx="23.8" cy="9" r="2.1" fill="#39dda0"/></svg></div>`;
  }
  function renderNavButton(item) {
    return `<button class="nav-item ${ui.view === item.id ? 'active' : ''}" data-action="navigate" data-view="${item.id}" aria-current="${ui.view === item.id ? 'page' : 'false'}">${icon(item.icon)}<span>${item.label}</span></button>`;
  }
  function renderSidebar() {
    const groups = [
      ['JOURNAL', navItems.filter(x => x.group === 'journal')],
      ['PROCESS', navItems.filter(x => x.group === 'process')],
      ['REVIEW & TOOLS', navItems.filter(x => x.group === 'review')]
    ];
    return `<aside class="sidebar">
      ${groups.map(([label, items]) => `<div class="sidebar-group-label">${label}</div><div class="nav-list">${items.map(renderNavButton).join('')}</div>`).join('')}
      <div class="sidebar-spacer"></div>
      <div class="sidebar-tip"><div class="tip-kicker">A note to self</div><p>Good process is repeatable. Record what you saw, what you did, and what you learned.</p></div>
      <div class="nav-list">${navItems.filter(x => x.group === 'account').map(renderNavButton).join('')}</div>
      <button class="profile-mini" data-action="logout" title="Sign out of this preview session"><div class="avatar">N</div><div class="profile-info"><strong>Nketiah</strong><span>Sign out</span></div>${icon('logout',15)}</button>
    </aside>`;
  }
  function mt4SnapshotState() {
    if (mt4DashboardError) return 'offline';
    if (!mt4AccountSnapshot) return 'waiting';
    const updated = Date.parse(mt4AccountSnapshot.updated_at || mt4AccountSnapshot.observed_at || '');
    if (!Number.isFinite(updated)) return 'online';
    return Date.now() - updated <= 30000 ? 'online' : 'stale';
  }
  function renderMt4AccountStrip() {
    if (!localMt4Mode && !productionMode) return '';
    // The live strip belongs to the active account journal. The manual journal has no
    // broker account, so it never shows another account's balance/equity.
    if (activeAccountKey === MANUAL_JOURNAL_KEY) return '';
    const snapshot = mt4AccountSnapshot;
    const currency = snapshot?.account_currency || state.settings.accountCurrency || 'USD';
    const stateLabel = mt4SnapshotState();
    const timestamp = snapshot?.updated_at || snapshot?.observed_at || '';
    const timeLabel = timestamp && Number.isFinite(Date.parse(timestamp))
      ? new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
    const statusText = stateLabel === 'online' ? `Live · updated ${timeLabel || 'just now'}`
      : stateLabel === 'stale' ? `Stale · last update ${timeLabel || 'unknown'}`
      : stateLabel === 'offline' ? 'Offline · retrying automatically' : 'Waiting for an account snapshot';
    const accountLabel = snapshot?.account_login ? `Account ${escapeHtml(snapshot.account_login)} · ${escapeHtml(snapshot.account_server || '')}` : 'Account not connected yet';
    const value = (field) => snapshot && snapshot[field] !== null && snapshot[field] !== undefined
      ? escapeHtml(money(snapshot[field], false, currency)) : '—';
    const floatingClass = snapshot && snapshot.floating_pl !== null ? pnlClass(snapshot.floating_pl) : '';
    const eyebrow = snapshot ? `${brokerLabel(snapshot.platform).toUpperCase()} LIVE ACCOUNT` : 'METATRADER LIVE ACCOUNT';
    return `<section class="mt4-account-strip" data-mt4-account-strip aria-label="Live MetaTrader account summary">
      <div class="mt4-account-strip-head"><div><div class="eyebrow">${eyebrow}</div><small>${accountLabel}</small></div><span class="mt4-account-live-status" data-state="${stateLabel}">${statusText}</span></div>
      <div class="mt4-account-metrics"><div class="mt4-account-metric"><span>ACCOUNT SIZE · BALANCE</span><strong>${value('balance')}</strong></div><div class="mt4-account-metric"><span>FLOATING P/L</span><strong class="amount ${floatingClass}">${value('floating_pl')}</strong></div><div class="mt4-account-metric"><span>EQUITY</span><strong>${value('equity')}</strong></div></div>
    </section>`;
  }
  function mt4AccountIdentity() {
    const snapshot = mt4AccountSnapshot;
    const server = String(snapshot?.account_server || '');
    if (!server) return null;
    const cut = server.lastIndexOf('-');
    const broker = (cut > 0 ? server.slice(0, cut) : server).trim() || server;
    const suffix = cut > 0 ? server.slice(cut + 1).trim() : '';
    const environment = /^demo$/i.test(suffix) ? 'Demo' : /^live$/i.test(suffix) ? 'Live' : suffix;
    const name = String(snapshot?.name || '').trim();
    const label = [broker, environment].filter(Boolean).join(' · ');
    return { broker, environment, name, label, login: String(snapshot?.account_login || ''), server };
  }
  function mt4AccountIdentityPill() {
    const identity = mt4AccountIdentity();
    if (!identity) return '';
    const text = `${identity.label}${identity.name ? ` · ${identity.name}` : ''}`;
    const title = `Connected MetaTrader account · ${identity.server}${identity.login ? ` · login ${identity.login}` : ''}`;
    return `<div class="local-pill mt4-account-pill" data-mt4-account-pill title="${escapeAttr(title)}"><span class="dot"></span>${escapeHtml(text)}</div>`;
  }
  function updateMt4AccountStrip() {
    const strip = document.querySelector('[data-mt4-account-strip]');
    if (!strip) return;
    if (updateMt4AccountStripValues()) return;
    strip.outerHTML = renderMt4AccountStrip();
  }

  function updateMt4AccountStripValues() {
    const strip = document.querySelector('[data-mt4-account-strip]');
    if (!strip || typeof strip.querySelectorAll !== 'function') return false;
    const snapshot = mt4AccountSnapshot;
    const currency = snapshot?.account_currency || state.settings.accountCurrency || 'USD';
    const value = (field) => snapshot && snapshot[field] !== null && snapshot[field] !== undefined
      ? money(snapshot[field], false, currency) : '—';
    const metrics = strip.querySelectorAll('.mt4-account-metric strong');
    if (metrics.length >= 3) {
      metrics[0].textContent = value('balance');
      metrics[1].textContent = value('floating_pl');
      metrics[1].className = `amount ${snapshot && snapshot.floating_pl !== null ? pnlClass(snapshot.floating_pl) : ''}`;
      metrics[2].textContent = value('equity');
    }
    const status = strip.querySelector('.mt4-account-live-status');
    if (status) {
      const stateLabel = mt4SnapshotState();
      const timestamp = snapshot?.updated_at || snapshot?.observed_at || '';
      const timeLabel = timestamp && Number.isFinite(Date.parse(timestamp))
        ? new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
      const statusText = stateLabel === 'online' ? `Live · updated ${timeLabel || 'just now'}`
        : stateLabel === 'stale' ? `Stale · last update ${timeLabel || 'unknown'}`
        : stateLabel === 'offline' ? 'Offline · retrying automatically' : 'Waiting for an account snapshot';
      status.textContent = statusText;
      status.dataset.state = stateLabel;
    }
    const label = strip.querySelector('.mt4-account-strip-head small');
    if (label) {
      label.textContent = snapshot?.account_login
        ? `Account ${snapshot.account_login} · ${snapshot.account_server || ''}` : 'Account not connected yet';
    }
    return true;
  }

  function renderTopbar() {
    const meta = viewMeta[ui.view] || viewMeta.performance;
    return `<header class="topbar">
      <div class="topbar-left">
        ${brandMark()}
        <div class="brand-name"><strong>NKETIAH JOURNAL</strong><span>SEE THE UNSEEN</span></div>
        <div class="topbar-view">${meta[0]}</div>
      </div>
      <div class="topbar-right">
        ${renderAccountSwitcher()}
        ${mt4AccountIdentityPill()}
        ${productionMode?`<div class="local-pill cloud-status-${escapeAttr(cloudSyncStatus)}" data-cloud-status title="${escapeAttr(cloudSyncError||'Private Supabase journal sync')}"><span class="dot"></span>${cloudSyncStatus==='synced'?'Cloud synced':cloudSyncStatus==='syncing'?'Syncing…':cloudSyncStatus==='pending'?'Sync queued':cloudSyncStatus==='conflict'?'Sync conflict':cloudSyncStatus==='error'?'Sync error':'Private cloud'}</div>`:`<div class="local-pill" title="This prototype saves data in this browser. Production authentication and cloud sync are not connected yet."><span class="dot"></span>Local preview</div>`}
        <button class="icon-button" data-action="navigate" data-view="settings" title="Settings">${icon('settings')}</button>
      </div>
    </header>`;
  }
  function renderMobileNav() {
    const mobileItems = [
      { id: 'performance', label: 'Home', icon: 'performance' },
      { id: 'journal', label: 'Journal', icon: 'journal' },
      { id: 'playbook', label: 'SNR', icon: 'playbook' },
      { id: 'calendar', label: 'Calendar', icon: 'calendar' }
    ];
    const primary = mobileItems.map(item => `<button class="${ui.view === item.id ? 'active' : ''}" data-action="navigate" data-view="${item.id}">${icon(item.icon)}<span>${item.label}</span></button>`).join('');
    return `<nav class="mobile-nav">${primary}<button class="${['goals','plans','analytics','ai','tools','mt4-activity','connect','settings'].includes(ui.view) ? 'active' : ''}" data-action="toggle-more">${icon('more')}<span>More</span></button></nav>
      <div class="mobile-more-menu ${ui.moreOpen ? 'open' : ''}">${navItems.filter(x => ['goals','plans','analytics','ai','tools','mt4-activity','connect','settings'].includes(x.id)).map(item => `<button data-action="navigate" data-view="${item.id}">${icon(item.icon)}<span>${item.label}</span></button>`).join('')}</div>`;
  }
  function renderLogin() {
    if(productionMode){
      const configured=Boolean(cloud&&cloud.isConfigured);
      const error=ui.loginError||window.NketiahProductionError||'';
      return `<div class="login-screen"><header class="login-topbar"><div class="brand-lockup">${brandMark()}<div class="brand-name"><strong>NKETIAH JOURNAL</strong><span>SEE THE UNSEEN</span></div></div><div class="login-preview-pill"><span class="dot"></span>PRIVATE CLOUD</div></header><main class="login-layout"><section class="login-story"><div class="eyebrow">A PRIVATE TRADING JOURNAL</div><h1>See the unseen<br/><span>in your process.</span></h1><p>Record the setup. Review the execution. Learn from the result. Your journal syncs to your private account.</p><div class="login-promise-grid"><div><span class="promise-index">01</span><strong>Capture</strong><small>Keep trade details and stage-by-stage evidence together.</small></div><div><span class="promise-index">02</span><strong>Review</strong><small>Sync your journal across your signed-in devices.</small></div><div><span class="promise-index">03</span><strong>Refine</strong><small>Request an AI process review only when you choose.</small></div></div><div class="login-quote"><span>${icon('shield',16)}</span><p>“Private owner access. Your journal stays yours.”</p></div></section><section class="login-card-wrap"><div class="login-card"><div class="login-card-icon">${icon('lock',20)}</div><div class="eyebrow">OWNER ACCESS</div><h2>Sign in with Google</h2><p class="login-card-subtitle">Use the Google account configured for this private journal.</p>${error?`<div class="login-error" role="alert">${icon('help',14)}<span>${escapeHtml(error)}</span></div>`:''}<button class="primary-button login-submit" type="button" data-action="sign-in-google" ${configured?'':'disabled'}>${icon('arrowUpRight',15)} Continue with Google</button><div class="login-notice"><span class="notice-lock">${icon('shield',14)}</span><span>${configured?'Google OAuth and owner-only access are enforced by the configured Supabase project.':'Production credentials are not configured yet. Follow PRODUCTION_SETUP.md.'}</span></div></div><div class="login-build-note">Nketiah Journal · Owner-only cloud account</div></section></main><footer class="login-footer"><span>PRIVATE BY DESIGN</span><span>AI requests are optional and require separate consent.</span><span>© ${new Date().getFullYear()} NKETIAH</span></footer></div>`;
    }
    return `<div class="login-screen"><header class="login-topbar"><div class="brand-lockup">${brandMark()}<div class="brand-name"><strong>NKETIAH JOURNAL</strong><span>SEE THE UNSEEN</span></div></div><div class="login-preview-pill"><span class="dot"></span>PRIVATE PREVIEW</div></header><main class="login-layout"><section class="login-story"><div class="eyebrow">A PRIVATE TRADING JOURNAL</div><h1>See the unseen<br/><span>in your process.</span></h1><p>Record the setup. Review the execution. Learn from the result. Your journal is waiting.</p><div class="login-promise-grid"><div><span class="promise-index">01</span><strong>Capture</strong><small>Keep trade details and stage-by-stage chart evidence together.</small></div><div><span class="promise-index">02</span><strong>Review</strong><small>See the week, the month, and the decisions behind each result.</small></div><div><span class="promise-index">03</span><strong>Refine</strong><small>Build a repeatable process, one honest review at a time.</small></div></div><div class="login-quote"><span>${icon('sparkle',16)}</span><p>“Good process is repeatable. Make the lesson visible.”</p></div></section><section class="login-card-wrap"><div class="login-card"><div class="login-card-icon">${icon('lock',20)}</div><div class="eyebrow">YOUR JOURNAL</div><h2>Welcome back</h2><p class="login-card-subtitle">Sign in to continue to your personal trading journal.</p><form id="login-form" novalidate><div class="form-field"><label for="login-username">Username</label><input id="login-username" name="username" type="text" value="${escapeAttr(ui.loginUsername)}" autocomplete="username" autocapitalize="none" spellcheck="false" required /></div><div class="form-field"><label for="login-password">Password</label><div class="password-field"><input id="login-password" name="password" type="${ui.showPassword?'text':'password'}" autocomplete="current-password" required /><button type="button" data-action="toggle-password">${ui.showPassword?'Hide':'Show'}</button></div></div>${ui.loginError?`<div class="login-error" role="alert">${icon('help',14)}<span>${escapeHtml(ui.loginError)}</span></div>`:''}<button class="primary-button login-submit" type="submit">Sign in ${icon('arrowUpRight',15)}</button></form><div class="login-notice"><span class="notice-lock">${icon('shield',14)}</span><span>Preview login only. Your journal data stays in this browser; cloud sync is not connected.</span></div></div><div class="login-build-note">Nketiah Journal · Owner access only</div></section></main><footer class="login-footer"><span>PRIVATE BY DESIGN</span><span>Built for clear thinking, not more noise.</span><span>© ${new Date().getFullYear()} NKETIAH</span></footer></div>`;
  }
  function render() {
    if (!isAuthenticated) { appRoot.innerHTML = renderLogin(); return; }
    if(productionMode&&!cloudReady){const failed=cloudSyncStatus==='error';appRoot.innerHTML=`<div class="login-screen"><main class="login-layout"><section class="login-card"><div class="eyebrow">PRIVATE CLOUD JOURNAL</div><h2>${failed?'Could not load your journal':'Loading your journal…'}</h2><p class="login-card-subtitle">${escapeHtml(failed?(cloudSyncError||'Check the network and try again.'):'Checking your session and loading your owner-scoped cloud backup.')}</p>${failed?`<div class="cloud-ai-controls"><button class="primary-button" data-action="cloud-retry-load">Retry</button><button class="secondary-button" data-action="logout">Sign out</button></div>`:''}</section></main></div>`;return;}
    const meta = viewMeta[ui.view] || viewMeta.performance;
    const shellRisk = dailyRiskSummary();
    appRoot.innerHTML = `<div class="app-shell${shellRisk.level === 'halt' ? ' risk-halted' : ''}">${renderTopbar()}${ui.view === 'performance' ? '' : renderGlobalRiskBar()}${renderMt4AccountStrip()}<div class="app-body">${renderSidebar()}<main class="main-content"><div class="page-heading"><div><div class="eyebrow">NKETIAH JOURNAL · ${ui.view === 'performance' ? 'YOUR PROCESS, IN FOCUS' : 'SEE THE UNSEEN'}</div><h1>${meta[0]}</h1><p class="page-subtitle">${meta[1]}</p></div><div class="page-actions"><button class="secondary-button" data-action="export-csv">${icon('download',15)} Export</button><button class="primary-button" data-action="new-trade">${icon('plus')} Add trade</button></div></div>${renderView()}</main></div>${renderMobileNav()}</div>${renderRiskHaltOverlay()}${ui.goalEquity ? renderGoalEquityModal() : ''}${renderAgentFab()}${ui.agentOpen && ui.view === 'goals' ? renderCoachChat() : ''}`;
    hydrateImages(appRoot);
    if(ui.goalEquity)initEquityChart();
    if(ui.agentOpen&&ui.view==='goals')initCoachChat();
  }
  function renderView() {
    switch (ui.view) {
      case 'journal': return renderJournal();
      case 'goals': return renderGoals();
      case 'playbook': return renderPlaybook();
      case 'plans': return renderPlans();
      case 'calendar': return renderCalendar();
      case 'analytics': return renderAnalytics();
      case 'ai': return renderAIReview();
      case 'tools': return renderTools();
      case 'mt4-activity': return renderMt4Activity();
      case 'connect': return renderConnect();
      case 'settings': return renderSettings();
      default: return renderPerformance();
    }
  }
  function yearsForFilter() {
    const years = new Set([String(currentYear)]);
    state.trades.forEach(t => { if (t.closedAt) years.add(String(parseDate(t.closedAt).getFullYear())); });
    return [...years].sort((a,b) => Number(b)-Number(a));
  }
  function symbolsForFilter(trades = state.trades) { return [...new Set(trades.map(t => t.symbol).filter(Boolean))].sort((a,b) => a.localeCompare(b)); }
  function filterOptions(includeSymbol = true) {
    const years = yearsForFilter();
    const symbols = symbolsForFilter();
    return `<div class="filter-row">
      <div class="filter-control"><label for="filter-year">Year</label><div class="select-wrap"><select id="filter-year" data-filter="year"><option value="all" ${ui.year === 'all' ? 'selected' : ''}>All years</option>${years.map(y => `<option value="${y}" ${ui.year === y ? 'selected' : ''}>${y}</option>`).join('')}</select></div></div>
      ${includeSymbol ? `<div class="filter-control"><label for="filter-symbol">Symbol</label><div class="select-wrap"><select id="filter-symbol" data-filter="symbol"><option value="all" ${ui.symbol === 'all' ? 'selected' : ''}>All symbols</option>${symbols.map(s => `<option value="${escapeAttr(s)}" ${ui.symbol === s ? 'selected' : ''}>${escapeHtml(s)}</option>`).join('')}</select></div></div>` : ''}
    </div>`;
  }
  function metricCard(label, value, helper, iconName, color = '') {
    return `<article class="stat-card"><div class="stat-label-row"><span class="stat-label">${label}</span><span class="stat-icon">${icon(iconName,14)}</span></div><div class="stat-value ${color}">${value}</div><div class="stat-helper">${helper}</div></article>`;
  }
  function getTrendBins(trades, period) {
    const now = new Date();
    const selectedYear = ui.year === 'all' ? null : Number(ui.year);
    const filtered = trades.filter(t => {
      const d = parseDate(t.closedAt);
      if (selectedYear && d.getFullYear() !== selectedYear) return false;
      return true;
    });
    if (period === 'monthly') {
      const groups = new Map();
      filtered.forEach(t => {
        const d = parseDate(t.closedAt);
        const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
        groups.set(key, (groups.get(key) || 0) + Number(t.pnlUsd || 0));
      });
      let keys;
      if (selectedYear) keys = Array.from({length:12}, (_, i) => `${selectedYear}-${String(i+1).padStart(2,'0')}`);
      else {
        const anchor = filtered.length ? parseDate(sortTrades(filtered)[0].closedAt) : now;
        keys = [];
        for (let i=11; i>=0; i--) { const d = new Date(anchor.getFullYear(), anchor.getMonth()-i, 1); keys.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`); }
      }
      return keys.map(key => { const [y,m] = key.split('-').map(Number); return { key, value: groups.get(key) || 0, label: new Date(y,m-1,1).toLocaleDateString('en-GB',{month:'short'}), title: new Date(y,m-1,1).toLocaleDateString('en-GB',{month:'long',year:'numeric'}) }; });
    }
    // Weekly chart buckets are Monday-Friday. Weekend trades remain in summary totals.
    const weekdayTrades = filtered.filter(t => { const d = parseDate(t.closedAt).getDay(); return d !== 0 && d !== 6; });
    const groups = new Map();
    weekdayTrades.forEach(t => {
      const d = parseDate(t.closedAt);
      const start = new Date(d); const day = start.getDay(); start.setDate(start.getDate() + (day === 0 ? -6 : 1 - day));
      const end = new Date(start); end.setDate(end.getDate()+4);
      const key = localDateString(start);
      const group = groups.get(key) || { value: 0, start, end };
      group.value += Number(t.pnlUsd || 0); groups.set(key, group);
    });
    let items = [...groups.entries()].sort((a,b) => a[0].localeCompare(b[0]));
    if (items.length > 12) items = items.slice(-12);
    return items.map(([key, g]) => ({ key, value: g.value, label: `${g.start.toLocaleDateString('en-GB',{day:'2-digit',month:'short'})}`, title: `${g.start.toLocaleDateString('en-GB',{day:'numeric',month:'short'})}–${g.end.toLocaleDateString('en-GB',{day:'numeric',month:'short'})}` }));
  }
  function renderChart(bins, period, hasTrades = state.trades.length > 0) {
    if (!hasTrades) {
      return `<div class="chart-empty"><div class="empty-state"><div class="empty-visual">${icon('trend',25)}</div><h3>Your performance story starts here</h3><p>Log a closed position to see your ${period === 'weekly' ? 'weekday-by-weekday' : 'month-by-month'} P/L. You can also explore the dashboard with sample trades.</p><div class="empty-actions"><button class="primary-button small" data-action="new-trade">${icon('plus',14)} Add first trade</button><button class="secondary-button small" data-action="load-sample">${icon('sparkle',14)} Explore sample data</button></div></div></div>`;
    }
    if (!bins.length) {
      return `<div class="chart-empty"><div class="empty-state"><div class="empty-visual">${icon('calendar',24)}</div><h3>No weekday closes in this view</h3><p>Weekend trades remain in your headline totals and monthly results. The weekly chart displays Monday–Friday closes only.</p><button class="secondary-button small" data-action="navigate" data-view="journal">Review journal</button></div></div>`;
    }
    const maxAbs = Math.max(1, ...bins.map(b => Math.abs(b.value)));
    const maxPositive = Math.max(0, ...bins.map(b => b.value));
    const maxNegative = Math.max(0, ...bins.map(b => -b.value));
    const topLabel = money(maxPositive || maxAbs, true);
    const bottomLabel = maxNegative ? money(-maxNegative, true) : money(0, true);
    const bars = bins.map(bin => {
      const positive = bin.value >= 0;
      const height = Math.max(2, Math.abs(bin.value) / maxAbs * (positive ? 61 : 27));
      const top = positive ? (67 - height) : 67;
      return `<div class="chart-bar-group" title="${escapeAttr(bin.title)} · ${escapeAttr(money(bin.value))}"><div class="chart-bar-area"><span class="chart-bar ${positive ? '' : 'negative'}" style="top:${top}%;height:${height}%" aria-label="${escapeAttr(bin.title)} ${escapeAttr(money(bin.value))}"></span></div><span class="chart-bar-label">${escapeHtml(bin.label)}</span></div>`;
    }).join('');
    return `<div class="chart-scroll"><div class="bar-chart"><div class="chart-y-labels"><span>${escapeHtml(topLabel)}</span><span>${escapeHtml(money(0,true))}</span><span>${escapeHtml(bottomLabel)}</span></div><div class="chart-plot"><span class="chart-gridline one"></span><span class="chart-gridline two"></span><span class="chart-gridline zero"></span><span class="chart-gridline three"></span>${bars}</div></div></div>`;
  }
  function msUntilNextDay() {
    const now = new Date();
    const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    return Math.max(0, next.getTime() - now.getTime());
  }
  function formatCountdown(ms) {
    const total = Math.max(0, Math.floor(Number(ms || 0) / 1000));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    if (hours > 0) return `${hours}h ${String(minutes).padStart(2, '0')}m`;
    if (minutes > 0) return `${minutes}m ${String(seconds).padStart(2, '0')}s`;
    return `${seconds}s`;
  }
  function dailyRiskSummary() {
    const lossLimit = Number(state.settings.dailyLossLimit || 0);
    const tradeLimit = Number(state.settings.maxDailyTrades || 0);
    const todays = state.trades.filter(t => t.closedAt === today);
    const dayPnl = todays.reduce((sum, t) => sum + Number(t.pnlUsd || 0), 0);
    const lossUsed = Math.max(0, -dayPnl);
    const lossPct = lossLimit > 0 ? lossUsed / lossLimit * 100 : 0;
    const countPct = tradeLimit > 0 ? todays.length / tradeLimit * 100 : 0;
    const pct = Math.max(lossPct, countPct);
    const level = pct >= 100 ? 'halt' : pct >= 75 ? 'warn' : 'ok';
    return {
      lossLimit, tradeLimit, todays, dayPnl, lossUsed, lossPct, countPct, pct, level,
      resetMs: msUntilNextDay(),
      configured: lossLimit > 0 || tradeLimit > 0,
      acknowledged: String(state.settings.riskHaltAcknowledgedDate || '') === today
    };
  }
  function riskMeter(pct, level) {
    const cls = level === 'halt' ? 'danger' : level === 'warn' ? 'warn' : '';
    return `<div class="risk-meter risk-meter-ticks"><span class="${cls}" style="width:${Math.min(100, Math.max(0, pct)).toFixed(1)}%"></span></div>`;
  }
  function renderGlobalRiskBar() {
    const risk = dailyRiskSummary();
    if (!risk.configured) return '';
    const badge = risk.level === 'halt' ? `${icon('bolt', 13)} RISK HALT · STAND DOWN`
      : risk.level === 'warn' ? `${icon('shield', 13)} APPROACHING DAILY LIMIT`
        : `${icon('shield', 13)} DAILY RISK`;
    return `<section class="risk-bar risk-bar-${risk.level}" data-risk-bar aria-label="Daily risk limit">
      <span class="risk-bar-badge">${badge}</span>
      <div class="risk-bar-meters">
        ${risk.lossLimit ? `<div class="risk-bar-meter"><span class="risk-bar-key">Loss</span>${riskMeter(risk.lossPct, risk.level)}<span class="risk-bar-figures"><strong>${escapeHtml(money(risk.lossUsed))}</strong> / ${escapeHtml(money(risk.lossLimit))}</span></div>` : ''}
        ${risk.tradeLimit ? `<div class="risk-bar-meter"><span class="risk-bar-key">Trades</span>${riskMeter(risk.countPct, risk.level)}<span class="risk-bar-figures"><strong>${risk.todays.length}</strong> / ${risk.tradeLimit}</span></div>` : ''}
      </div>
      <div class="risk-bar-side">
        <span class="risk-bar-day ${pnlClass(risk.dayPnl)}">Today ${escapeHtml(money(risk.dayPnl))}</span>
        <span class="risk-bar-reset" data-risk-reset="${risk.resetMs}">resets in ${formatCountdown(risk.resetMs)}</span>
      </div>
    </section>`;
  }
  function renderRiskHaltOverlay() {
    const risk = dailyRiskSummary();
    if (risk.level !== 'halt' || risk.acknowledged) return '';
    const ringPct = Math.min(100, Math.max(0, risk.pct));
    const circumference = 2 * Math.PI * 42;
    const dash = circumference * ringPct / 100;
    return `<div class="halt-overlay" data-halt-overlay><div class="halt-panel" role="alertdialog" aria-modal="true" aria-label="Daily risk limit reached">
      <div class="halt-ring"><svg viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="42" class="halt-ring-track"></circle><circle cx="50" cy="50" r="42" class="halt-ring-value" stroke-dasharray="${dash.toFixed(1)} ${circumference.toFixed(1)}"></circle></svg><strong>${Math.round(risk.pct)}%</strong><span>of limit</span></div>
      <div class="halt-eyebrow">DAILY LIMIT REACHED · ${escapeHtml(formatDate(today, { weekday: 'long', day: 'numeric', month: 'short' }))}</div>
      <h2>Step away from the chart.</h2>
      <p>Today sits at <strong class="${pnlClass(risk.dayPnl)}">${escapeHtml(money(risk.dayPnl))}</strong>${risk.lossLimit ? ` against a ${escapeHtml(money(risk.lossLimit))} daily loss limit` : ''}${risk.tradeLimit ? ` and ${risk.todays.length} of ${risk.tradeLimit} allowed trades` : ''}. The journal switches to review-only until the reset.</p>
      <div class="halt-countdown"><span>Auto reset in</span><strong data-risk-reset="${risk.resetMs}">${formatCountdown(risk.resetMs)}</strong><span>at local midnight</span></div>
      <div class="halt-actions"><button class="primary-button" data-action="risk-review-today">Review today’s trades</button><button class="secondary-button" data-action="risk-acknowledge">Acknowledge · journal only</button></div>
      <p class="halt-note">${icon('shield', 13)} Discipline guardrail, not a broker control — your broker will not block new orders for you.</p>
    </div></div>`;
  }
  function confirmRiskHalt() {
    const risk = dailyRiskSummary();
    if (risk.level !== 'halt') return true;
    return window.confirm(`Your daily risk limit is reached (${money(risk.dayPnl)} today${risk.lossLimit ? ` vs ${money(risk.lossLimit)} limit` : ''}). Resets in ${formatCountdown(risk.resetMs)}. Log this entry anyway?`);
  }
  function updateRiskCountdowns() {
    const rolledDay = localDateString(new Date());
    if (rolledDay !== today) {
      today = rolledDay;
      render();
      return;
    }
    const nodes = document.querySelectorAll('[data-risk-reset]');
    if (!nodes || !nodes.length) return;
    const remaining = msUntilNextDay();
    nodes.forEach(node => {
      node.textContent = node.classList.contains('risk-bar-reset') ? `resets in ${formatCountdown(remaining)}` : formatCountdown(remaining);
      node.setAttribute('data-risk-reset', String(remaining));
    });
  }
  function startRiskClock() {
    if (riskClockTimer) return;
    riskClockTimer = window.setInterval(updateRiskCountdowns, 1000);
  }
  function weekStartFor(offsetWeeks = 0) {
    const d = new Date();
    const day = d.getDay();
    d.setDate(d.getDate() + (day === 0 ? -6 : 1 - day) - offsetWeeks * 7);
    return d;
  }
  function weekSlots(offsetWeeks = 0) {
    const start = weekStartFor(offsetWeeks);
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    return labels.map((label, index) => {
      const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + index);
      const key = localDateString(date);
      const closed = state.trades.filter(t => t.closedAt === key);
      return { label, date: key, pnl: closed.reduce((sum, t) => sum + Number(t.pnlUsd || 0), 0), count: closed.length };
    });
  }
  function weeklyGoalContext() {
    const target = Number(state.settings.weeklyGoal || 0);
    const slots = weekSlots(0);
    const achieved = slots.reduce((sum, slot) => sum + slot.pnl, 0);
    const todayIndex = slots.findIndex(slot => slot.date === today);
    const weekday = new Date().getDay();
    const daysElapsed = todayIndex >= 0 ? todayIndex + 1 : (weekday === 0 ? 0 : 5);
    const daysLeft = Math.max(0, 5 - daysElapsed);
    const remaining = target - achieved;
    const expected = target * (daysElapsed / 5);
    const paceDelta = achieved - expected;
    const pct = target > 0 ? achieved / target * 100 : 0;
    const status = target <= 0 ? 'unset'
      : achieved >= target ? 'hit'
        : daysElapsed === 5 && daysLeft === 0 ? 'missed'
          : paceDelta >= 0 ? 'ahead'
            : paceDelta >= -Math.max(1, target * 0.25) ? 'behind' : 'at-risk';
    return {
      target, slots, achieved, remaining, daysElapsed, daysLeft, expected, paceDelta, pct, status,
      requiredPerDay: daysLeft > 0 ? Math.max(0, remaining) / daysLeft : 0,
      history: [1, 2, 3, 4].map(offset => {
        const week = weekSlots(offset);
        const total = week.reduce((sum, slot) => sum + slot.pnl, 0);
        return { offset, total, slots: week, pct: target > 0 ? total / target * 100 : 0, hit: target > 0 && total >= target };
      })
    };
  }
  function weeklyEquitySeries() {
    const slots = weekSlots(0);
    let cum = 0;
    return slots.map(slot => { cum += slot.pnl; return { label: slot.label, date: slot.date, pnl: slot.pnl, count: slot.count, cumulative: cum }; });
  }
  function renderGoalEquityModal() {
    const ctx = weeklyGoalContext();
    const series = weeklyEquitySeries();
    const W = 540, H = 250, padL = 48, padR = 16, padT = 18, padB = 34;
    const points = [{ label: 'Open', value: 0, pnl: null, count: 0 }, ...series.map(s => ({ label: s.label, value: s.cumulative, pnl: s.pnl, count: s.count }))];
    const values = points.map(p => p.value);
    if (ctx.target > 0) values.push(ctx.target);
    const dataMin = Math.min(...values), dataMax = Math.max(...values);
    const pad = Math.max(12, (dataMax - dataMin) * 0.15);
    const lo = dataMin - pad, hi = dataMax + pad;
    const innerW = W - padL - padR, innerH = H - padT - padB;
    const x = i => padL + (points.length > 1 ? innerW * i / (points.length - 1) : 0);
    const y = v => padT + innerH * (hi - v) / ((hi - lo) || 1);
    const coords = points.map((p, i) => [x(i), y(p.value)]);
    const linePath = coords.map(([cx, cy], i) => `${i ? 'L' : 'M'}${cx.toFixed(1)},${cy.toFixed(1)}`).join(' ');
    const zeroY = y(0);
    const areaPath = `${linePath} L${coords[coords.length - 1][0].toFixed(1)},${zeroY.toFixed(1)} L${coords[0][0].toFixed(1)},${zeroY.toFixed(1)} Z`;
    const grid = [0.25, 0.5, 0.75].map(f => { const gy = (padT + innerH * f).toFixed(1); return `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" class="eq-grid"/>`; }).join('');
    const goalLine = ctx.target > 0 ? `<line x1="${padL}" y1="${y(ctx.target).toFixed(1)}" x2="${W - padR}" y2="${y(ctx.target).toFixed(1)}" class="eq-goal"/><text x="${W - padR}" y="${(y(ctx.target) - 6).toFixed(1)}" text-anchor="end" class="eq-label eq-goal-label">GOAL ${escapeHtml(money(ctx.target, true))}</text>` : '';
    const xLabels = points.map((p, i) => `<text x="${x(i).toFixed(1)}" y="${H - 10}" text-anchor="middle" class="eq-label">${p.label}</text>`).join('');
    const dots = coords.map(([cx, cy], i) => {
      const p = points[i];
      const tone = i === 0 ? '' : p.pnl > 0 ? ' win' : p.pnl < 0 ? ' neg' : ' flat';
      return `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="4.5" class="eq-dot${tone}" data-eq-dot style="animation-delay:${420 + i * 70}ms"></circle>`;
    }).join('');
    const crosshair = `<line class="eq-crosshair" x1="0" y1="${padT}" x2="0" y2="${H - padB}"/>`;
    const endLabel = `<text x="${(coords[coords.length - 1][0] - 4).toFixed(1)}" y="${(coords[coords.length - 1][1] - 10).toFixed(1)}" text-anchor="end" class="eq-value ${pnlClass(series[series.length - 1].cumulative)}">${escapeHtml(money(series[series.length - 1].cumulative, true))}</text>`;
    const startOfWeek = weekStartFor(0);
    const rangeLabel = `${formatDate(localDateString(startOfWeek), { day: 'numeric', month: 'short' })} – ${formatDate(localDateString(new Date(startOfWeek.getFullYear(), startOfWeek.getMonth(), startOfWeek.getDate() + 4)), { day: 'numeric', month: 'short' })}`;
    const bestDay = series.reduce((a, b) => (b.pnl > a.pnl ? b : a), series[0]);
    return `<div class="equity-overlay" data-action="close-goal-equity"><div class="equity-modal" role="dialog" aria-modal="true" aria-label="Weekly goal equity curve">
      <div class="equity-head"><div><div class="eyebrow">WEEKLY GOAL · ${escapeHtml(rangeLabel.toUpperCase())}</div><h3>Equity curve</h3><p class="equity-sub">Cumulative Monday–Friday closes, session by session${ctx.target > 0 ? `, against your ${escapeHtml(money(ctx.target))} goal` : '. Set a weekly goal to track pace against a target'}.</p></div><button class="equity-close" data-action="close-goal-equity" aria-label="Close">${icon('close', 16)}</button></div>
      <div class="equity-chart" data-equity-chart data-vb-w="${W}" data-vb-h="${H}"><div class="eq-tooltip" hidden></div><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Weekly goal equity curve"><defs><linearGradient id="eq-area" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#39dda0" stop-opacity="0.22"/><stop offset="100%" stop-color="#39dda0" stop-opacity="0"/></linearGradient></defs>${grid}<line x1="${padL}" y1="${zeroY.toFixed(1)}" x2="${W - padR}" y2="${zeroY.toFixed(1)}" class="eq-zero"/>${goalLine}<path d="${areaPath}" class="eq-area" fill="url(#eq-area)"/><path d="${linePath}" pathLength="1" class="eq-line"/>${crosshair}${dots}${endLabel}${xLabels}</svg></div>
      <div class="equity-stats"><div class="equity-stat"><span>WEEK EQUITY</span><strong class="${pnlClass(ctx.achieved)}">${escapeHtml(money(ctx.achieved))}</strong></div><div class="equity-stat"><span>OF GOAL</span><strong>${ctx.target > 0 ? `${escapeHtml(money(ctx.target))} · ${fmtNumber(Math.max(0, ctx.pct), 0)}%` : 'Not set'}</strong></div><div class="equity-stat"><span>BEST SESSION</span><strong class="${pnlClass(bestDay.pnl)}">${bestDay.label} ${escapeHtml(money(bestDay.pnl))}</strong></div></div>
      <p class="footer-note">Hover any point to see that session’s win or loss and the running equity. Curve counts recorded closes only — open floating P/L is not included.</p>
    </div></div>`;
  }
  function initEquityChart() {
    const wrap = document.querySelector('[data-equity-chart]');
    if (!wrap) return;
    const svg = wrap.querySelector('svg');
    const tooltip = wrap.querySelector('.eq-tooltip');
    const crosshair = svg && svg.querySelector('.eq-crosshair');
    const dots = svg ? Array.from(svg.querySelectorAll('.eq-dot')) : [];
    if (!svg || !tooltip || !crosshair || !dots.length) return;
    const vbW = Number(wrap.getAttribute('data-vb-w') || 540);
    const vbH = Number(wrap.getAttribute('data-vb-h') || 250);
    const series = weeklyEquitySeries();
    const points = [{ label: 'Open', value: 0, pnl: null, count: 0 }, ...series.map(s => ({ label: s.label, value: s.cumulative, pnl: s.pnl, count: s.count }))];
    const hide = () => {
      tooltip.hidden = true;
      tooltip.className = 'eq-tooltip';
      crosshair.classList.remove('show');
      dots.forEach(d => d.classList.remove('active'));
    };
    wrap.addEventListener('mouseleave', hide);
    wrap.addEventListener('mousemove', (event) => {
      const rect = svg.getBoundingClientRect();
      if (!rect.width) return;
      const mouseX = (event.clientX - rect.left) / rect.width * vbW;
      let nearest = 0, bestDist = Infinity;
      dots.forEach((d, i) => {
        const dist = Math.abs(Number(d.getAttribute('cx')) - mouseX);
        if (dist < bestDist) { bestDist = dist; nearest = i; }
      });
      const dot = dots[nearest];
      const p = points[nearest];
      const cx = Number(dot.getAttribute('cx'));
      const cy = Number(dot.getAttribute('cy'));
      dots.forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
      crosshair.setAttribute('x1', String(cx));
      crosshair.setAttribute('x2', String(cx));
      crosshair.classList.add('show');
      const tone = p.pnl === null ? 'open' : p.pnl > 0 ? 'win' : p.pnl < 0 ? 'loss' : 'flat';
      const tag = p.pnl === null ? 'OPEN' : p.pnl > 0 ? 'WIN' : p.pnl < 0 ? 'LOSS' : (p.count ? 'BREAKEVEN' : 'NO CLOSES');
      const dayValue = p.pnl === null ? 'Start of week' : escapeHtml(money(p.pnl, true));
      tooltip.hidden = false;
      tooltip.className = `eq-tooltip show ${tone}`;
      tooltip.innerHTML = `<div class="eq-tip-head"><span>${escapeHtml(p.label)}</span><em>${tag}</em></div><strong class="eq-tip-value">${dayValue}</strong><div class="eq-tip-row"><span>Running equity</span><strong class="${pnlClass(p.value)}">${escapeHtml(money(p.value, true))}</strong></div><div class="eq-tip-row"><span>Closes logged</span><strong>${p.count}</strong></div>`;
      const px = cx / vbW * rect.width;
      const py = cy / vbH * rect.height;
      const clampedX = Math.max(84, Math.min(rect.width - 84, px));
      tooltip.style.left = `${clampedX}px`;
      tooltip.style.top = `${Math.max(58, py)}px`;
    });
  }
  function weekTrades(offset = 0) {
    const dates = new Set(weekSlots(offset).map(s => s.date));
    return state.trades.filter(t => dates.has(t.closedAt));
  }
  function coachWeekStats() {
    const ctx = weeklyGoalContext();
    const trades = weekTrades(0);
    const wins = trades.filter(t => Number(t.pnlUsd || 0) > 0);
    const losses = trades.filter(t => Number(t.pnlUsd || 0) < 0);
    const followed = trades.filter(t => t.followedSop);
    const notFollowed = trades.filter(t => !t.followedSop);
    const pnlOf = list => list.reduce((sum, t) => sum + Number(t.pnlUsd || 0), 0);
    const bySymbol = {};
    trades.forEach(t => { const k = t.symbol || '—'; bySymbol[k] = (bySymbol[k] || 0) + Number(t.pnlUsd || 0); });
    const symbols = Object.entries(bySymbol).sort((a, b) => a[1] - b[1]);
    const worstDay = ctx.slots.reduce((a, s) => (s.pnl < a.pnl ? s : a), ctx.slots[0]);
    const bestDay = ctx.slots.reduce((a, s) => (s.pnl > a.pnl ? s : a), ctx.slots[0]);
    const risk = dailyRiskSummary();
    return { ctx, trades, wins, losses, followed, notFollowed, pnlOf, symbols, worstDay, bestDay, risk };
  }
  function coachCard(title, rows) {
    return `<div class="coach-bubble-card"><div class="coach-card-title">${title}</div>${rows.map(r => `<div class="coach-card-row"><span>${r[0]}</span><strong class="${r[2] || ''}">${r[1]}</strong></div>`).join('')}</div>`;
  }
  function sortedTradesDesc() {
    return [...state.trades].sort((a, b) => {
      const d = String(b.closedAt || '').localeCompare(String(a.closedAt || ''));
      return d || String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
    });
  }
  function tradesPnl(trades) { return trades.reduce((sum, t) => sum + Number(t.pnlUsd || 0), 0); }
  function winRateOf(trades) { return trades.length ? trades.filter(t => Number(t.pnlUsd || 0) > 0).length / trades.length * 100 : 0; }
  function recentTradesCard(list) {
    const rows = list.map((t) => {
      const pnl = Number(t.pnlUsd || 0);
      const tag = pnl > 0 ? 'WIN' : pnl < 0 ? 'LOSS' : 'FLAT';
      const when = formatDate(t.closedAt, { day: 'numeric', month: 'short' });
      return `<div class="coach-trade-row"><span>${escapeHtml(`${when} · ${t.symbol} ${t.side}`)}</span><strong class="${pnlClass(pnl)}">${escapeHtml(money(pnl, true))} · ${tag}</strong></div>`;
    }).join('');
    const net = tradesPnl(list);
    return `<div class="coach-bubble-card"><div class="coach-card-title">RECENT CLOSES · AUTO-GENERATED</div>${rows}<div class="coach-card-row coach-card-sum"><span>Net of ${list.length}</span><strong class="${pnlClass(net)}">${escapeHtml(money(net))}</strong></div><div class="coach-card-row"><span>Win rate</span><strong>${fmtNumber(winRateOf(list), 0)}%</strong></div></div>`;
  }
  function journalStats() {
    const trades = sortedTradesDesc();
    const stats = getStats(trades);
    const grossWin = trades.filter(t => Number(t.pnlUsd || 0) > 0).reduce((s, t) => s + Number(t.pnlUsd || 0), 0);
    const grossLoss = Math.abs(trades.filter(t => Number(t.pnlUsd || 0) < 0).reduce((s, t) => s + Number(t.pnlUsd || 0), 0));
    const bySymbol = {};
    const bySetup = {};
    const byWeekday = {};
    trades.forEach((t) => {
      const pnl = Number(t.pnlUsd || 0);
      const sym = String(t.symbol || '—');
      bySymbol[sym] = (bySymbol[sym] || 0) + pnl;
      const setup = getSetup(t.setupId);
      const setupName = setup ? setup.name : '';
      if (setupName) {
        if (!bySetup[setupName]) bySetup[setupName] = { name: setupName, pnl: 0, count: 0, wins: 0 };
        bySetup[setupName].pnl += pnl;
        bySetup[setupName].count += 1;
        if (pnl > 0) bySetup[setupName].wins += 1;
      }
      if (t.closedAt) {
        const day = parseDate(t.closedAt).getDay();
        if (day >= 1 && day <= 5) {
          if (!byWeekday[day]) byWeekday[day] = { day, pnl: 0, count: 0 };
          byWeekday[day].pnl += pnl;
          byWeekday[day].count += 1;
        }
      }
    });
    const symbols = Object.entries(bySymbol).sort((a, b) => b[1] - a[1]);
    const setups = Object.values(bySetup).sort((a, b) => b.pnl - a.pnl);
    const WD = ['', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    const weekdays = Object.values(byWeekday).sort((a, b) => b.pnl - a.pnl).map(w => ({ ...w, label: WD[w.day] }));
    let streak = { type: 'none', count: 0 };
    let longestWin = 0, longestLoss = 0, runW = 0, runL = 0;
    trades.forEach((t) => {
      const pnl = Number(t.pnlUsd || 0);
      if (pnl > 0) { runW += 1; runL = 0; longestWin = Math.max(longestWin, runW); }
      else if (pnl < 0) { runL += 1; runW = 0; longestLoss = Math.max(longestLoss, runL); }
    });
    for (const t of trades) {
      const pnl = Number(t.pnlUsd || 0);
      if (pnl === 0) continue;
      const type = pnl > 0 ? 'win' : 'loss';
      if (!streak.count) streak = { type, count: 1 };
      else if (streak.type === type) streak = { type, count: streak.count + 1 };
      else break;
    }
    const monthKey = today.slice(0, 7);
    const lastMonthDate = new Date();
    lastMonthDate.setDate(1);
    lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
    const prevKey = localDateString(lastMonthDate).slice(0, 7);
    const mtd = getStats(trades.filter(t => String(t.closedAt || '').startsWith(monthKey)));
    const prev = getStats(trades.filter(t => String(t.closedAt || '').startsWith(prevKey)));
    let biggestWin = trades[0] || null, biggestLoss = trades[0] || null;
    trades.forEach((t) => {
      if (biggestWin && Number(t.pnlUsd || 0) > Number(biggestWin.pnlUsd || 0)) biggestWin = t;
      if (biggestLoss && Number(t.pnlUsd || 0) < Number(biggestLoss.pnlUsd || 0)) biggestLoss = t;
    });
    return {
      trades, count: stats.total, net: stats.pnl, winRate: stats.winRate,
      wins: stats.wins, losses: stats.losses,
      expectancy: stats.total ? stats.pnl / stats.total : 0,
      avgWin: stats.wins ? grossWin / stats.wins : 0,
      avgLoss: stats.losses ? grossLoss / stats.losses : 0,
      profitFactor: grossLoss > 0 ? fmtNumber(grossWin / grossLoss, 2) : grossWin > 0 ? '∞' : '—',
      symbols, bestSymbol: symbols[0] || null, worstSymbol: symbols[symbols.length - 1] || null,
      setups, weekdays, streak, longestWin, longestLoss, mtd, prev, biggestWin, biggestLoss
    };
  }
  function coachGreeting() {
    const ctx = weeklyGoalContext();
    const weekLine = ctx.target > 0
      ? `Week of ${formatDate(weekStartFor(0), { day: 'numeric', month: 'short' })}: goal ${escapeHtml(money(ctx.target))}, you're at ${escapeHtml(money(ctx.achieved))} (${fmtNumber(Math.max(0, ctx.pct), 0)}%).`
      : `Week of ${formatDate(weekStartFor(0), { day: 'numeric', month: 'short' })}: no weekly goal set — say <strong>set goal 300</strong> or skip straight to the numbers.`;
    const memG = agentMemory();
    let topId = '', topCount = 0;
    for (const [idG, cG] of Object.entries(memG.counts)) if (cG > topCount) { topCount = cG; topId = idG; }
    const habitLine = topCount >= 3 && COACH_INTENT_LABELS[topId] ? `\n\nYou usually ask about ${COACH_INTENT_LABELS[topId]} here.` : '';
    return `Hello — I'm Agent Nketiah, your journal desk. I hold every close you've logged: this week, this month, and all-time. No signals, no predictions — just your data.\n\n${weekLine}${habitLine}\n\n1. Weekly goal report\n2. Recent trades\n3. Week autopsy\n4. Discipline check\n5. Risk check\n6. Weekly focus\n\nReply with a number or ask anything — “biggest loss”, “my setups”, “what did I trade on XAUUSD”. (The ✦ button up top toggles quick-reply chips.)`;
  }
  function coachWeeklyFocus(s) {
    const { ctx, trades, followed, notFollowed, pnlOf, risk } = s;
    if (risk.level === 'halt') return `Hard stop first: your daily risk limit is hit (${escapeHtml(money(risk.dayPnl))} today). <strong>Focus today — protect the rest of the week.</strong> No new entries until the reset; review instead. ${coachCard('FOCUS · PROTECT', [['Action', 'Journal only until midnight'], ['Why', 'One bad day can erase a good week'], ['Then', 'Restart tomorrow with half size if needed']])}`;
    if (trades.length && followed.length / trades.length < 0.6 && notFollowed.length >= 2) return `Your process leak this week is rule adherence — only ${followed.length} of ${trades.length} closes had the SOP checked. <strong>Focus: one rule per trade.</strong> If it's not written down before entry, it doesn't count. ${coachCard('FOCUS · PROCESS', [['SOP followed', `${followed.length}/${trades.length}`], ['P&L with SOP', escapeHtml(money(pnlOf(followed)))], ['P&L without', `${escapeHtml(money(pnlOf(notFollowed)))}`, pnlClass(pnlOf(notFollowed))]])}`;
    const tradeDays = ctx.slots.filter(sl => sl.count > 0);
    const limit = Number(state.settings.maxDailyTrades || 0);
    const overDays = limit ? ctx.slots.filter(sl => sl.count > limit).length : 0;
    if (overDays > 0) return `You've broken your ${limit}-trade daily cap on ${overDays} session${overDays === 1 ? '' : 's'}. <strong>Focus: fewer, better.</strong> Cap the count, not just the loss — overtrading is how a small red day becomes a red week. ${coachCard('FOCUS · RESTRAINT', [['Your cap', `${limit} trades/day`], ['Days over', String(overDays)], ['Week so far', escapeHtml(money(ctx.achieved)), pnlClass(ctx.achieved)]])}`;
    if (ctx.target > 0 && ctx.achieved < 0) return `Down ${escapeHtml(money(Math.abs(ctx.achieved)))} on the week with ${ctx.daysLeft} session${ctx.daysLeft === 1 ? '' : 's'} left. <strong>Focus: stop the bleed before chasing the goal.</strong> Chasing from red is how red becomes worse. Cut size, wait for A+ setups only. ${coachCard('FOCUS · RECOVERY', [['Current', escapeHtml(money(ctx.achieved)), 'neg'], ['Goal', escapeHtml(money(ctx.target))], ['Rule', 'Half size until first green session']])}`;
    if (tradeDays.length >= 3 && tradeDays.every(sl => sl.pnl >= 0)) return `Three-plus green sessions in a row — the process is working. <strong>Focus: keep the routine identical.</strong> Same size, same checklist; don't upgrade risk mid-streak. ${coachCard('FOCUS · LOCK IT IN', [['Green sessions', String(tradeDays.length)], ['Week equity', escapeHtml(money(ctx.achieved)), pnlClass(ctx.achieved)], ['Rule', 'No size increase on a streak']])}`;
    return `Week of ${formatDate(weekStartFor(0), { day: 'numeric', month: 'short' })}: ${trades.length} close${trades.length === 1 ? '' : 's'}, win rate ${trades.length ? fmtNumber(s.wins.length / trades.length * 100, 0) : 0}%. <strong>Focus: trade the plan you wrote down.</strong> Ask me for an autopsy if something feels off. ${coachCard('FOCUS · BASELINE', [['Week equity', escapeHtml(money(ctx.achieved)), pnlClass(ctx.achieved)], ['Wins / losses', `${s.wins.length} / ${s.losses.length}`], ['Sessions traded', String(tradeDays.length)]])}`;
  }
  const AGENT_MEMORY_KEY = 'nketiah-agent-memory-v1';
  const COACH_STOPWORDS = new Set(['i', 'my', 'me', 'the', 'a', 'an', 'for', 'is', 'was', 'are', 'am', 'do', 'does', 'did', 'what', 'whats', 'how', 'much', 'on', 'in', 'of', 'to', 'and', 'or', 'it', 'this', 'that', 'about', 'please', 'can', 'could', 'you', 'now', 'total', 'overall', 'get', 'give', 'show', 'tell', 'need', 'want', 'so', 'far']);
  const COACH_INTENT_LABELS = { 'pace': 'the goal pace report', 'pre-flight': 'whether you should trade', 'verdict': 'all-time profitability', 'counts': 'trade counts', 'totals': 'accumulated totals', 'recent': 'recent closes', 'biggest': 'your biggest trades', 'setups': 'your setups', 'compare-weeks': 'week-vs-week comparisons', 'month': 'month to date', 'all-time-report': 'the all-time report', 'calendar': 'the calendar view', 'runway': 'the goal runway', 'autopsy': 'week autopsies', 'sop': 'discipline checks', 'markets': 'market breakdowns', 'risk': 'daily risk', 'focus': 'weekly focus', 'scoped-profit': 'period profit', 'my-view': 'what I know', 'who-am-i': 'your file', 'help': 'the help menu' };
  function agentMemory() {
    try {
      const raw = localStorage.getItem(AGENT_MEMORY_KEY);
      const mem = raw ? JSON.parse(raw) : null;
      if (mem && mem.version === 1 && mem.counts && Array.isArray(mem.phrases) && mem.thumbs) return mem;
    } catch (_) {}
    return { version: 1, counts: {}, phrases: [], thumbs: {} };
  }
  function saveAgentMemory(mem) {
    try { localStorage.setItem(AGENT_MEMORY_KEY, JSON.stringify(mem)); } catch (_) {}
  }
  function normalizeCoachQuery(q) {
    return String(q || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function coachQueryWords(q) {
    return normalizeCoachQuery(q).split(' ').filter(w => w.length > 1 && !COACH_STOPWORDS.has(w));
  }
  function coachJaccard(a, b) {
    if (!a.size || !b.size) return 0;
    let inter = 0;
    a.forEach(w => { if (b.has(w)) inter += 1; });
    return inter / (a.size + b.size - inter);
  }
  function matchLearnedPhrase(lower) {
    const mem = agentMemory();
    if (!mem.phrases.length) return null;
    const qWords = new Set(coachQueryWords(lower));
    if (!qWords.size) return null;
    let best = null;
    for (const phrase of mem.phrases) {
      if (!phrase.canonical) continue;
      const pWords = new Set([...(phrase.words || []), ...coachQueryWords(phrase.canonical)]);
      const j = coachJaccard(qWords, pWords);
      let covered = pWords.size > 0;
      qWords.forEach(w => { if (!pWords.has(w)) covered = false; });
      const score = Math.max(j, covered ? 1 : 0);
      if (score >= 0.4 && (!best || score > best.score || (score === best.score && (phrase.hits || 0) > (best.phrase.hits || 0)))) best = { phrase, score };
    }
    return best && best.phrase.canonical ? best.phrase : null;
  }
  let coachLastHit = { id: '', canonical: '' };
  function coachEmit(id, canonical, text) {
    coachLastHit = { id, canonical: canonical || '' };
    return text;
  }
  function coachReply(raw, _depth) {
    const text = String(raw || '').trim();
    const lower = text.toLowerCase();
    const s = coachWeekStats();
    const { ctx, trades, wins, losses, followed, notFollowed, pnlOf, symbols, worstDay, bestDay, risk } = s;
    const winRate = trades.length ? fmtNumber(wins.length / trades.length * 100, 0) : 0;
    if (/\b(clear|remove|delete|reset)\b.*\bgoal\b|\bgoal\b.*\b(clear|remove|delete|reset)\b/.test(lower)) {
      state.settings = { ...state.settings, weeklyGoal: '' };
      persistState();
      return coachEmit('goal-clear', '', `Weekly goal cleared. The curve and pace tracking stay available — set a new number any time (<strong>set goal 300</strong>). ${coachCard('GOAL', [['Status', 'Not set'], ['This week', escapeHtml(money(ctx.achieved)), pnlClass(ctx.achieved)]])}`);
    }
    const setMatch = text.match(/(?:set|change|update|make|raise|lower|adjust)\s+(?:my\s+)?(?:weekly\s+)?goal\s*(?:to|at|of)?\s*[$€£]?\s*(\d+(?:\.\d+)?)/i) || text.match(/\bgoal\s+to\s+[$€£]?\s*(\d+(?:\.\d+)?)/i);
    if (setMatch) {
      const value = Number(setMatch[1]);
      if (Number.isFinite(value) && value >= 0) {
        state.settings = { ...state.settings, weeklyGoal: String(value) };
        persistState();
        const fresh = weeklyGoalContext();
        const needed = fresh.daysLeft > 0 ? money(Math.max(0, fresh.remaining) / fresh.daysLeft) : money(0);
        return coachEmit('goal-set', '', `Done — weekly goal is now <strong>${escapeHtml(money(value))}</strong>. ${fresh.achieved >= value ? 'You are already there; everything above it is buffer.' : `That means ${escapeHtml(needed)} per remaining session from here.`} ${coachCard('GOAL UPDATED', [['New target', escapeHtml(money(value))], ['Achieved', escapeHtml(money(fresh.achieved)), pnlClass(fresh.achieved)], ['Pace status', fresh.status.replace('-', ' ')], ['Sessions left', String(fresh.daysLeft)]])}`);
      }
    }
    const menuMap = { '1': 'on pace', '2': 'recent trades', '3': 'week autopsy', '4': 'SOP check', '5': 'daily risk', '6': 'weekly focus' };
    if (menuMap[lower]) return coachReply(menuMap[lower]);
    if (/\bwho are you\b|\bwhat are you\b|\byour name\b|\bwho is agent\b|\bab(?:ou)?t you\b|\btell me about yourself\b|\bare you (?:an? )?(?:ai|bot|assistant|human|chatgpt|gpt|real)\b|\byou (?:are|'re) (?:an? )?(?:ai|bot|chatgpt|real)\b|\byou a bot\b|\bis this chatgpt\b|\bwhich (?:model|ai)\b|\bwhat model\b/.test(lower)) {
      const riskNow = dailyRiskSummary();
      const ctxNow = weeklyGoalContext();
      const haltLine = riskNow.level === 'halt' ? ` Your daily loss limit is hit right now, so I'm keeping us in review-only mode until midnight.` : '';
      return coachEmit('who-are-you', 'who are you', `I'm Agent Nketiah — the built-in desk agent of your Nketiah Journal. Not ChatGPT, not a cloud model: I'm a deterministic engine that lives inside this app, fully offline, and I answer only from the journal you've logged.${haltLine}

What I hold right now: ${state.trades.length} closes on record (this week: ${weekTrades(0).length}, net ${escapeHtml(money(weeklyGoalContext().achieved))}), ${state.setups.length} setups, ${(state.plans || []).length} plans, weekly goal ${ctxNow.target > 0 ? escapeHtml(money(ctxNow.target)) : 'not set'}, all-time net ${escapeHtml(money(getStats(state.trades).pnl))}.

I don't predict markets and I don't give financial advice — I read your tape back to you honestly. Ask “who am I”, reply 1–6 for the menu, or throw any question about your own numbers at me.`);
    }
    if (/^who am i\b|\bmy name\b|\bab(?:ou)?t me\b|\bwhat do you know about me\b|\bmy profile\b|\bknow me\b|\bmy file\b/.test(lower)) {
      const stMe = journalStats();
      const uname = ui.loginUsername || 'the journal owner';
      return coachEmit('who-am-i', 'who am i', `You're ${escapeHtml(uname)} — owner and sole user of this journal. Everything you tell it stays in this browser; nothing is sent anywhere. ${coachCard('YOUR FILE', [['Closes logged', String(stMe.count)], ['All-time net', escapeHtml(money(stMe.net)), pnlClass(stMe.net)], ['Month to date', escapeHtml(money(stMe.mtd.pnl)), pnlClass(stMe.mtd.pnl)], ['Weekly goal', state.settings.weeklyGoal ? escapeHtml(money(Number(state.settings.weeklyGoal))) : 'Not set'], ['Daily loss limit', Number(state.settings.dailyLossLimit) ? escapeHtml(money(state.settings.dailyLossLimit)) : 'Not set'], ['Trade cap / day', state.settings.maxDailyTrades ? String(state.settings.maxDailyTrades) : 'Not set'], ['Currency', journalCurrency()], ['Setups / plans', `${state.setups.length} / ${(state.plans || []).length}`], ['AI reviews saved', String((state.aiReviews || []).length)]])}`);
    }
    if (/\bwhat can you see\b|\bwhat do you know\b|\bwhat data\b|\binventory\b|\bwhat do you have\b|\bwhat are you (?:aware|reading|looking)\b|\bwhat's in (?:the )?journal\b|\bshow me what you know\b|\bwhat are you (?:tracking|watching)\b/.test(lower)) {
      return coachEmit('my-view', '', `I read only what you've logged in this journal — here is my entire view: ${coachCard('MY VIEW', [['Closes', `${state.trades.length} (today: ${state.trades.filter(t => t.closedAt === today).length}, this week: ${weekTrades(0).length})`], ['Setups', String(state.setups.length)], ['Trade plans', String((state.plans || []).length)], ['AI reviews', String((state.aiReviews || []).length)], ['Weekly goal', state.settings.weeklyGoal ? escapeHtml(money(Number(state.settings.weeklyGoal))) : 'Not set'], ['Daily loss limit', Number(state.settings.dailyLossLimit) ? escapeHtml(money(state.settings.dailyLossLimit)) : 'Not set'], ['Trade cap / day', state.settings.maxDailyTrades ? String(state.settings.maxDailyTrades) : 'Not set'], ['Currency', journalCurrency()]])} No open positions, no live broker feed, no internet — just the journal, read honestly.`);
    }
    if (/\bthanks?\b|\bthank you\b|\bcheers\b|\bappreciate\b|\bnice one\b|\bwell done\b|\bgood job\b/.test(lower)) {
      const ctxT = weeklyGoalContext();
      const wkT = weekTrades(0);
      return coachEmit('thanks', '', `Any time. The data does the talking — I just read it back without flattery. ${wkT.length ? `This week so far: ${escapeHtml(money(ctxT.achieved))} across ${wkT.length} close${wkT.length === 1 ? '' : 's'}.` : 'No closes this week yet — log the next one and I will keep score.'}`);
    }
    if (/^(?:bye|goodbye|good night|goodnight|see you|cya|later|gtg)\b/.test(lower)) {
      const ctxB = weeklyGoalContext();
      return coachEmit('bye', '', `Logging off — the journal stays right here. Week equity ${escapeHtml(money(ctxB.achieved))}${ctxB.target > 0 ? ` of ${escapeHtml(money(ctxB.target))}` : ''}, ${state.trades.length} closes on record. Trade the plan; I'm on the FAB whenever you need the numbers.`);
    }
    if (/should i (?:trade|continue|keep trading|take a trade|size up|size down|stop)\b|\bcan i trade\b|\bis it (?:safe )?to trade\b|\btime to trade\b|\bshould i stop\b|\bkeep going\b/.test(lower)) {
      const riskQ = dailyRiskSummary();
      const focusNote = coachWeeklyFocus(coachWeekStats());
      const verdictQ = riskQ.level === 'halt' ? `No. Your daily loss limit is hit — review-only until midnight. That rule is the coach.` : riskQ.level === 'warn' ? `Borderline. You are close to the daily line — half size or stand down; do not negotiate with the meter.` : `Your risk meter allows it. That is permission within YOUR rules — mine is to keep reminding you what they are.`;
      return coachEmit('pre-flight', 'should i trade today', `${verdictQ} ${coachCard('PRE-FLIGHT', [['Today', escapeHtml(money(riskQ.dayPnl)), pnlClass(riskQ.dayPnl)], ['Loss used', riskQ.lossLimit ? `${escapeHtml(money(riskQ.lossUsed))} / ${escapeHtml(money(riskQ.lossLimit))}` : 'No limit set', riskQ.level === 'halt' ? 'neg' : ''], ['Trades today', riskQ.tradeLimit ? `${riskQ.todays.length} / ${riskQ.tradeLimit}` : String(riskQ.todays.length)], ['Resets in', formatCountdown(riskQ.resetMs)]])} ${focusNote}`);
    }
    const scopedPeriod = /\ball[- ]?time\b/.test(lower) ? 'all-time'
      : /\byesterday\b/.test(lower) ? 'yesterday'
      : /\btoday\b|\bso far today\b|\bthis morning\b/.test(lower) ? 'today'
      : /\blast week\b|\bprevious week\b/.test(lower) ? 'last week'
      : /\bthis week\b|\bweek so far\b|\bweek to date\b/.test(lower) ? 'this week'
      : /\blast month\b/.test(lower) ? 'last month'
      : /\bthis month\b|\bmonth to date\b|\bmt[d]\b/.test(lower) ? 'this month'
      : /\bthis year\b/.test(lower) ? 'this year' : '';
    if (scopedPeriod && /\b(profit|pnl|made|lost|lose|earn|gain|total|how much|net|equity|down|up)\b/.test(lower) && !/\bper session\b|\brunway\b|\bneed\b|\bpace\b|\bcompare\b|\bwhy\b/.test(lower)) {
      let poolS = [], labelS = '';
      if (scopedPeriod === 'all-time') { poolS = state.trades; labelS = 'All-time'; }
      else if (scopedPeriod === 'today') { poolS = state.trades.filter(t => t.closedAt === today); labelS = 'Today'; }
      else if (scopedPeriod === 'yesterday') { const dY = new Date(); dY.setDate(dY.getDate() - 1); const yKey = localDateString(dY); poolS = state.trades.filter(t => t.closedAt === yKey); labelS = 'Yesterday'; }
      else if (scopedPeriod === 'this week') { poolS = weekTrades(0); labelS = 'This week'; }
      else if (scopedPeriod === 'last week') { poolS = weekTrades(-1); labelS = 'Last week'; }
      else if (scopedPeriod === 'this month') { const mk = today.slice(0, 7); poolS = state.trades.filter(t => String(t.closedAt || '').slice(0, 7) === mk); labelS = 'This month'; }
      else if (scopedPeriod === 'last month') { const dM = new Date(); dM.setDate(1); dM.setMonth(dM.getMonth() - 1); const pmk = localDateString(dM).slice(0, 7); poolS = state.trades.filter(t => String(t.closedAt || '').slice(0, 7) === pmk); labelS = 'Last month'; }
      else if (scopedPeriod === 'this year') { const yk = today.slice(0, 4); poolS = state.trades.filter(t => String(t.closedAt || '').slice(0, 4) === yk); labelS = 'This year'; }
      const winsS = poolS.filter(t => Number(t.pnlUsd || 0) > 0);
      const lossesS = poolS.filter(t => Number(t.pnlUsd || 0) < 0);
      const netS = tradesPnl(poolS);
      const grossWinS = tradesPnl(winsS);
      const grossLossS = tradesPnl(lossesS);
      const leadS = !poolS.length ? `No closes logged ${labelS.toLowerCase()} yet.`
        : netS >= 0 ? `${labelS} you're net <strong>${escapeHtml(money(netS))}</strong> across ${poolS.length} close${poolS.length === 1 ? '' : 's'}.`
        : `${labelS} sits at <strong>${escapeHtml(money(netS))}</strong> across ${poolS.length} close${poolS.length === 1 ? '' : 's'} — name the leak before the next session.`;
      return coachEmit('scoped-profit', '', `${leadS} ${coachCard(`${labelS.toUpperCase()} TOTALS`, [['Net', escapeHtml(money(netS)), pnlClass(netS)], ['Gross wins', escapeHtml(money(grossWinS)), 'pos'], ['Gross losses', escapeHtml(money(grossLossS)), 'neg'], ['Wins / losses', `${winsS.length} / ${lossesS.length}`], ['Closes', String(poolS.length)]])}`);
    }
    if (/\bam i profitable\b|\bam i (?:winning|losing|good|a good trader|up|down)\b|\boverall (?:profit|pnl|result)\b|\bhave i made money\b|\bis my strategy working\b|\bdo i have an edge\b/.test(lower) && !/\b(today|yesterday|this week|last week|this month|this year|mt[d])\b/.test(lower)) {
      const stV = journalStats();
      const verdictV = stV.count === 0 ? `Flat all-time — no closes logged yet, so there is nothing to judge. Add trades and ask me again.` : stV.net > 0 ? `Yes — all-time you are net positive: ${escapeHtml(money(stV.net))} over ${stV.count} closes. The edge is real in the data; the job now is not giving it back.` : `Not yet — all-time sits at ${escapeHtml(money(stV.net))} over ${stV.count} closes. That is information, not a verdict: expectancy is ${escapeHtml(money(stV.expectancy))} per close at a ${fmtNumber(stV.winRate || 0, 0)}% win rate. Fix process first; the P/L follows.`;
      return coachEmit('verdict', 'am i profitable', `${verdictV} ${coachCard('VERDICT', [['All-time net', escapeHtml(money(stV.net)), pnlClass(stV.net)], ['This month', escapeHtml(money(stV.mtd.pnl)), pnlClass(stV.mtd.pnl)], ['Expectancy / trade', escapeHtml(money(stV.expectancy)), pnlClass(stV.expectancy)], ['Win rate', stV.winRate === null ? '—' : fmtNumber(stV.winRate, 0) + '%'], ['Profit factor', escapeHtml(stV.profitFactor)], ['Best setup', stV.setups.length ? `${escapeHtml(stV.setups[0].name)} ${escapeHtml(money(stV.setups[0].pnl))}` : 'None tagged', stV.setups.length ? pnlClass(stV.setups[0].pnl) : '']])}`);
    }
    if (/how many|\bnumber of trades\b|\btrade count\b|\bcount (?:of )?trades\b/.test(lower)) {
      const dayList = state.trades.filter(t => t.closedAt === today);
      const wkList = weekTrades(0);
      const stC = journalStats();
      return coachEmit('counts', 'how many trades', `Closes on the books: ${coachCard('COUNTS', [['Today', `${dayList.length} · ${escapeHtml(money(tradesPnl(dayList)))}`, pnlClass(tradesPnl(dayList))], ['This week', `${wkList.length} · ${escapeHtml(money(tradesPnl(wkList)))}`, pnlClass(tradesPnl(wkList))], ['This month', `${stC.mtd.total} · ${escapeHtml(money(stC.mtd.pnl))}`, pnlClass(stC.mtd.pnl)], ['All-time', `${stC.count} · ${escapeHtml(money(stC.net))}`, pnlClass(stC.net)]])}`);
    }
    if (/\btotal\b|\baccumulated\b|\baggregated\b|\bcumulative\b|\bgross\b|\bnet total\b|\boverall (?:loss|profit|pnl|net)\b|\ball[- ]?time (?:loss|profit|pnl|net)\b|\bhow much (?:have|did) i\b|\bhow much money\b/.test(lower) && !/\bhow much (?:do|did) i need\b|\bper session\b|\brunway\b|\b(today|yesterday|this week|last week|this month|last month|this year|so far|mt[d])\b/.test(lower)) {
      const knownT = [...new Set(state.trades.map(t => String(t.symbol || '').trim()).filter(Boolean))];
      const scopeSym = knownT.find(sym => lower.includes(sym.toLowerCase()) || (/^xau/i.test(sym) && /\bxau|gold\b/.test(lower)));
      const poolAll = scopeSym ? sortedTradesDesc().filter(t => String(t.symbol || '') === scopeSym) : sortedTradesDesc();
      const lossesT = poolAll.filter(t => Number(t.pnlUsd || 0) < 0);
      const winsT = poolAll.filter(t => Number(t.pnlUsd || 0) > 0);
      const grossLossT = tradesPnl(lossesT);
      const grossWinT = tradesPnl(winsT);
      const netT = grossWinT + grossLossT;
      const wkNetT = tradesPnl(weekTrades(0));
      const stT = journalStats();
      const scopeLine = scopeSym ? `on ${escapeHtml(scopeSym)}` : 'all-time';
      const directT = lossesT.length ? `Your accumulated losses ${scopeLine}: ${escapeHtml(money(grossLossT))} across ${lossesT.length} losing close${lossesT.length === 1 ? '' : 's'}.` : `No losing closes recorded ${scopeLine} yet.`;
      const winLine = winsT.length ? ` Winners total ${escapeHtml(money(grossWinT))} across ${winsT.length} closes, so net ${scopeLine} is ${escapeHtml(money(netT))}.` : '';
      return coachEmit('totals', 'total accumulated loss', `${directT}${winLine} ${coachCard('TOTALS', [['Gross losses', escapeHtml(money(grossLossT)), 'neg'], ['Gross wins', escapeHtml(money(grossWinT)), 'pos'], ['Net', escapeHtml(money(netT)), pnlClass(netT)], ['Losing / winning closes', `${lossesT.length} / ${winsT.length}`], ['This week net', escapeHtml(money(wkNetT)), pnlClass(wkNetT)], ['This month net', escapeHtml(money(stT.mtd.pnl)), pnlClass(stT.mtd.pnl)], ['Expectancy / trade', escapeHtml(money(poolAll.length ? netT / poolAll.length : 0)), pnlClass(poolAll.length ? netT / poolAll.length : 0)]])}`);
    }
    const knownSymbols = [...new Set(state.trades.map(t => String(t.symbol || '').trim()).filter(Boolean))];
    const symHit = knownSymbols.find((sym) => {
      const s = sym.toLowerCase();
      if (lower.includes(s)) return true;
      if (/^xau/.test(s) && /\bxau|gold\b/.test(lower)) return true;
      return false;
    });
    if (symHit && !/\bweek\b|breakdown/.test(lower)) {
      const mine = sortedTradesDesc().filter(t => String(t.symbol || '') === symHit);
      const stSym = getStats(mine);
      const card = mine.length ? recentTradesCard(mine.slice(0, 5)) : '';
      return coachEmit('symbol', '', `All-time on ${escapeHtml(symHit)}: ${stSym.total} close${stSym.total === 1 ? '' : 's'}, net ${escapeHtml(money(stSym.pnl))}, win rate ${stSym.winRate === null ? '—' : fmtNumber(stSym.winRate, 0) + '%'}. ${card}`.trim());
    }
    if (/\brecent\b|history|last \d+|what did i trade|my closes|latest|newest/.test(lower) && !/\ball[- ]?time\b/.test(lower)) {
      const list = sortedTradesDesc().slice(0, 8);
      if (!list.length) return coachEmit('recent', 'recent trades', `No closes logged yet — add a trade and ask me again; I'll auto-generate the list straight from the journal.`);
      return coachEmit('recent', 'recent trades', `Auto-generated from your journal — your ${list.length} most recent closes, newest first. ${recentTradesCard(list)} Ask <strong>show XAUUSD</strong> to filter a market, or <strong>all-time report</strong> for the full picture.`);
    }
    if (/\bbiggest\b|\blargest\b|\bbest trade\b|\bworst trade\b/.test(lower)) {
      const all = sortedTradesDesc();
      if (!all.length) return coachEmit('biggest', 'biggest loss', `No closes logged yet — nothing to rank.`);
      let biggestWin = all[0], biggestLoss = all[0];
      all.forEach((t) => {
        if (Number(t.pnlUsd || 0) > Number(biggestWin.pnlUsd || 0)) biggestWin = t;
        if (Number(t.pnlUsd || 0) < Number(biggestLoss.pnlUsd || 0)) biggestLoss = t;
      });
      const labelOf = t => `${formatDate(t.closedAt, { day: 'numeric', month: 'short' })} · ${escapeHtml(t.symbol)} ${escapeHtml(t.side)}`;
      return coachEmit('biggest', 'biggest loss', `Your extremes across ${all.length} closes: ${coachCard('BIGGEST TRADES', [['Best win', labelOf(biggestWin)], ['Best P/L', escapeHtml(money(biggestWin.pnlUsd)), 'pos'], ['Worst loss', labelOf(biggestLoss)], ['Worst P/L', escapeHtml(money(biggestLoss.pnlUsd)), 'neg']])}`);
    }
    if (/\bweekday\b|which day|day of week|best day|monday|tuesday|wednesday|thursday|friday/.test(lower) && !/\bweek of|this week|weekly\b/.test(lower)) {
      const st = journalStats();
      if (!st.weekdays.length) return coachEmit('weekday', '', `Not enough dated closes to rank weekdays yet.`);
      const best = st.weekdays[0];
      const worst = st.weekdays[st.weekdays.length - 1];
      return coachEmit('weekday', '', `Your weekday edge, all-time: strongest is ${best.label} (${escapeHtml(money(best.pnl))} over ${best.count} close${best.count === 1 ? '' : 's'}), weakest ${worst.label} (${escapeHtml(money(worst.pnl))}). ${coachCard('WEEKDAYS · ALL-TIME', st.weekdays.map(w => [w.label, `${escapeHtml(money(w.pnl))} · ${w.count}t`, pnlClass(w.pnl)]))}`);
    }
    if (/\bsetup|strategy|playbook\b/.test(lower) && !/\bsop\b|checklist/.test(lower)) {
      const st = journalStats();
      if (!st.setups.length) return coachEmit('setups', 'my setups', `No setup-tagged closes yet — pick a setup when you log a trade and I'll rank them by net P/L.`);
      const top = st.setups[0];
      const topRate = top.count ? fmtNumber(top.wins / top.count * 100, 0) : 0;
      return coachEmit('setups', 'my setups', `<strong>${escapeHtml(top.name)}</strong> is your best setup by net: ${escapeHtml(money(top.pnl))} over ${top.count} closes (${topRate}% win rate). ${coachCard('SETUP RANKING', st.setups.slice(0, 5).map(u => [escapeHtml(u.name), `${escapeHtml(money(u.pnl))} · ${u.count}t · ${u.count ? fmtNumber(u.wins / u.count * 100, 0) : 0}%`, pnlClass(u.pnl)]))}`);
    }
    if (/\bstreak\b/.test(lower)) {
      const st = journalStats();
      const cur = st.streak.count ? `${st.streak.count}-trade ${st.streak.type}` : '—';
      return coachEmit('streak', '', `Live streak: ${cur}. ${coachCard('STREAKS', [['Current', cur, st.streak.type === 'win' ? 'pos' : st.streak.type === 'loss' ? 'neg' : ''], ['Longest win run', `${st.longestWin} in a row`, 'pos'], ['Longest loss run', `${st.longestLoss} in a row`, 'neg']])}`);
    }
    if (/compare|last week|previous week|vs .*week|week over week/.test(lower)) {
      const cur = weekSlots(0).reduce((sum, slot) => sum + slot.pnl, 0);
      const prev = weekSlots(1).reduce((sum, slot) => sum + slot.pnl, 0);
      const delta = cur - prev;
      const verdict = delta >= 0 ? `That's ${escapeHtml(money(delta))} better than last week — ask me what drove it before you change anything.` : `That's ${escapeHtml(money(delta))} worse than last week — an autopsy beats guessing.`;
      return coachEmit('compare-weeks', 'compare last week', `${verdict} ${coachCard('WEEK VS WEEK', [['This week', escapeHtml(money(cur)), pnlClass(cur)], ['Last week', escapeHtml(money(prev)), pnlClass(prev)], ['Delta', escapeHtml(money(delta)), pnlClass(delta)]])}`);
    }
    if (/\bmonth\b|\bmtd\b/.test(lower)) {
      const st = journalStats();
      const swing = st.mtd.pnl - st.prev.pnl;
      const vsLine = st.prev.total ? `Last month finished ${escapeHtml(money(st.prev.pnl))} over ${st.prev.total} closes — you're ${escapeHtml(money(swing))} against that pace.` : 'No closes last month to compare against.';
      return coachEmit('month', 'this month', `Month to date: ${escapeHtml(money(st.mtd.pnl))} across ${st.mtd.total} closes, win rate ${st.mtd.winRate === null ? '—' : fmtNumber(st.mtd.winRate, 0) + '%'}. ${vsLine} ${coachCard('MONTH TO DATE', [['Net', escapeHtml(money(st.mtd.pnl)), pnlClass(st.mtd.pnl)], ['Closes', String(st.mtd.total)], ['Win rate', st.mtd.winRate === null ? '—' : fmtNumber(st.mtd.winRate, 0) + '%'], ['Avg per trade', escapeHtml(money(st.mtd.total ? st.mtd.pnl / st.mtd.total : 0)), pnlClass(st.mtd.total ? st.mtd.pnl / st.mtd.total : 0)]])}`);
    }
    if (/report|all[- ]?time|overall|full\b|my stats\b|\bstats\b|summary/.test(lower)) {
      const st = journalStats();
      const settingsRows = [
        ['Weekly goal', state.settings.weeklyGoal ? escapeHtml(money(Number(state.settings.weeklyGoal))) : 'Not set']
      ];
      if (Number(state.settings.maxDailyLossUsd)) settingsRows.push(['Daily loss limit', escapeHtml(money(state.settings.maxDailyLossUsd))]);
      if (Number(state.settings.maxDailyTrades)) settingsRows.push(['Trade cap / day', String(state.settings.maxDailyTrades)]);
      settingsRows.push(['Plans logged', String((state.plans || []).length)]);
      settingsRows.push(['Setups tagged', String(state.setups.length)]);
      return coachEmit('all-time-report', 'all-time report', `Full journal read — every close you've logged. ${coachCard('ALL-TIME', [['Net', escapeHtml(money(st.net)), pnlClass(st.net)], ['Closes', String(st.count)], ['Win rate', st.winRate === null ? '—' : fmtNumber(st.winRate, 0) + '%'], ['Expectancy / trade', escapeHtml(money(st.expectancy)), pnlClass(st.expectancy)], ['Avg win', escapeHtml(money(st.avgWin)), 'pos'], ['Avg loss', escapeHtml(money(st.avgLoss)), 'neg'], ['Profit factor', escapeHtml(st.profitFactor)], ['Best market', st.bestSymbol ? `${escapeHtml(st.bestSymbol[0])} ${escapeHtml(money(st.bestSymbol[1]))}` : '—', st.bestSymbol ? pnlClass(st.bestSymbol[1]) : ''], ['Worst market', st.worstSymbol ? `${escapeHtml(st.worstSymbol[0])} ${escapeHtml(money(st.worstSymbol[1]))}` : '—', st.worstSymbol ? pnlClass(st.worstSymbol[1]) : '']])} ${coachCard('THIS MONTH', [['Net', escapeHtml(money(st.mtd.pnl)), pnlClass(st.mtd.pnl)], ['Closes', String(st.mtd.total)], ['Win rate', st.mtd.winRate === null ? '—' : fmtNumber(st.mtd.winRate, 0) + '%']])} ${coachCard('BEST SETUP', st.setups.length ? [[escapeHtml(st.setups[0].name), escapeHtml(money(st.setups[0].pnl)), pnlClass(st.setups[0].pnl)]] : [['Tagged closes', 'None yet — tag setups when logging']])} ${coachCard('RULES', settingsRows)}`);
    }
    if (/\btoday\b|\byesterday\b|\bwhat day\b|\bwhat time\b|\bwhat date\b|\bwhat week\b|\bday is it\b/.test(lower)) {
      const isYest = /\byesterday\b/.test(lower);
      const refDate = new Date();
      if (isYest) refDate.setDate(refDate.getDate() - 1);
      const refKey = localDateString(refDate);
      const dayList = state.trades.filter(t => t.closedAt === refKey);
      const netDay = tradesPnl(dayList);
      const ctxD = weeklyGoalContext();
      const dayName = formatDate(refKey, { weekday: 'long', day: 'numeric', month: 'long' });
      const timeNow = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
      const rowsD = [['Date', dayName]];
      if (/\bwhat time\b|\bwhat date\b/.test(lower)) rowsD.push(['Local time', timeNow]);
      rowsD.push([isYest ? 'Yesterday net' : 'Today net', escapeHtml(money(netDay)), pnlClass(netDay)]);
      rowsD.push(['Closes', String(dayList.length)]);
      rowsD.push(['Week equity', escapeHtml(money(ctxD.achieved)), pnlClass(ctxD.achieved)]);
      if (ctxD.target > 0) rowsD.push(['Goal', `${escapeHtml(money(ctxD.achieved))} / ${escapeHtml(money(ctxD.target))}`]);
      rowsD.push(['Sessions left this week', String(ctxD.daysLeft)]);
      return coachEmit('calendar', 'today', `${isYest ? 'Yesterday' : 'Today'} is ${dayName}. ${dayList.length ? `${dayList.length} close${dayList.length === 1 ? '' : 's'}, net ${escapeHtml(money(netDay))}.` : 'No closes logged for that day yet.'} Week of ${formatDate(weekStartFor(0), { day: 'numeric', month: 'short' })} sits at ${escapeHtml(money(ctxD.achieved))}${ctxD.target > 0 ? ` of ${escapeHtml(money(ctxD.target))}` : ''} with ${ctxD.daysLeft} session${ctxD.daysLeft === 1 ? '' : 's'} left. ${coachCard('CALENDAR', rowsD)}`);
    }
    if (/help|what can you|commands|abilities|how do you work|menu/.test(lower)) {
      return coachEmit('help', 'help', `I'm Agent Nketiah — the journal desk. Deterministic engine, offline, grounded in every close you've logged: this week, this month, and all-time, plus setups, streaks, and risk rules. No signals, no predictions. ${coachCard('MENU', [['1', 'Weekly goal report / pace'], ['2', 'Recent closes — auto list'], ['3', 'Week autopsy'], ['4', 'Discipline & SOP check'], ['5', 'Daily risk check'], ['6', 'Weekly focus'], ['all-time report', 'Full stats & rules'], ['set goal 300', 'Update the target']])} Or just ask — “who are you”, “am I profitable”, “should I trade today”, “why did I lose”, “my setups this month”, “compare last week”, “what did I trade on gold”. New chat resets this thread.`);
    }
    if (/^(hi|hey|hello|yo|sup)\b/.test(lower)) {
      return coachEmit('hello', '', `${coachGreeting()} ${coachCard('WEEK SNAPSHOT', [['Equity', escapeHtml(money(ctx.achieved)), pnlClass(ctx.achieved)], ['Closes', String(trades.length)], ['Win rate', `${winRate}%`]])}`);
    }
    if (/need|require|per (day|session)|runway|left to|catch up|catch up/.test(lower)) {
      if (!ctx.target) return coachEmit('runway', '', `No goal set, so there's nothing to pace against. Say <strong>set goal 300</strong> and I'll give you the runway math.`);
      if (ctx.achieved >= ctx.target) return coachEmit('runway', '', `Goal already cleared — ${escapeHtml(money(ctx.achieved))} vs ${escapeHtml(money(ctx.target))}. Nothing needed; protect the buffer. ${coachCard('RUNWAY', [['Buffer', escapeHtml(money(ctx.achieved - ctx.target)), 'pos'], ['Sessions left', String(ctx.daysLeft)], ['Rule', 'Preserve, do not escalate']])}`);
      if (ctx.daysLeft <= 0) return coachEmit('runway', '', `The Monday–Friday window is closed at ${escapeHtml(money(ctx.achieved))} of ${escapeHtml(money(ctx.target))}. Reset is the next week's job — review what the tape taught you, then set the next number.`);
      return coachEmit('runway', '', `You need <strong>${escapeHtml(money(ctx.remaining))}</strong> across ${ctx.daysLeft} remaining session${ctx.daysLeft === 1 ? '' : 's'} — that's <strong>${escapeHtml(money(ctx.remaining / ctx.daysLeft))}</strong> per session. For reference, your best session this week was ${escapeHtml(money(bestDay.pnl))} (${bestDay.label}). ${coachCard('RUNWAY MATH', [['Remaining', escapeHtml(money(ctx.remaining)), 'neg'], ['Per session', escapeHtml(money(ctx.remaining / ctx.daysLeft))], ['Best session', `${bestDay.label} ${escapeHtml(money(bestDay.pnl))}`, pnlClass(bestDay.pnl)], ['Pace delta', escapeHtml(money(ctx.paceDelta)), pnlClass(ctx.paceDelta)]])}`);
    }
    if (/pace|on track|behind|ahead|status|how am i|doing|progress/.test(lower)) {
      if (!ctx.target) return coachEmit('pace', 'on pace', `No target set — I can still read the week: ${escapeHtml(money(ctx.achieved))} across ${trades.length} closes. Set a goal if you want pace tracking.`);
      const verdict = ctx.status === 'hit' ? 'Goal hit. Anything else this week is buffer — protect it.' : ctx.paceDelta >= 0 ? 'Ahead of pace. Do not inflate size because it feels good.' : ctx.status === 'at-risk' ? 'At risk. The math is unforgiving from here — cut size, wait for quality.' : 'Behind pace. Catching up is a process problem, not a size problem.';
      return coachEmit('pace', 'on pace', `${verdict} ${coachCard('PACE CHECK', [['Target', escapeHtml(money(ctx.target))], ['Achieved', escapeHtml(money(ctx.achieved)), pnlClass(ctx.achieved)], ['Expected by now', escapeHtml(money(ctx.expected))], ['Delta', escapeHtml(money(ctx.paceDelta)), pnlClass(ctx.paceDelta)], ['Status', ctx.status.replace('-', ' ')]])}`);
    }
    if (/\bautopsy\b|\bworst\b|\bwent wrong\b|\bwhy did i\b|\blos(?:e|es|ing|t)\b|\blosses\b|\bbad day\b|\bbad session\b|\breview my week\b|\bwhat happened\b|\bblow(?:n|up)\b|\bdown (?:bad|badly|again)\b/.test(lower)) {
      if (!trades.length) return coachEmit('autopsy', 'week autopsy', `No closes recorded this week yet — nothing to autopsy. The curve is flat at zero.`);
      const worstTrade = trades.reduce((a, t) => (Number(t.pnlUsd || 0) < Number(a.pnlUsd || 0) ? t : a), trades[0]);
      const worstSymbol = symbols[0];
      const bestSymbol = symbols[symbols.length - 1];
      return coachEmit('autopsy', 'week autopsy', `Here's the honest read: worst session was ${worstDay.label} at ${escapeHtml(money(worstDay.pnl))}. ${worstSymbol && worstSymbol[1] < 0 ? `${escapeHtml(worstSymbol[0])} is your heaviest drag (${escapeHtml(money(worstSymbol[1]))}). ` : ''}${notFollowed.length ? `${notFollowed.length} close${notFollowed.length === 1 ? '' : 's'} happened without the SOP checked — they cost ${escapeHtml(money(pnlOf(notFollowed)))}.` : 'Every close had the SOP checked — keep that standard.'} ${coachCard('WEEK AUTOPSY', [['Worst session', `${worstDay.label} ${escapeHtml(money(worstDay.pnl))}`, 'neg'], ['Worst close', `${worstSymbol ? escapeHtml(worstSymbol[0]) : worstTrade.symbol} ${escapeHtml(money(worstTrade.pnlUsd))}`, 'neg'], ['Best market', bestSymbol ? `${escapeHtml(bestSymbol[0])} ${escapeHtml(money(bestSymbol[1]))}` : '—', bestSymbol ? pnlClass(bestSymbol[1]) : ''], ['Without SOP', `${notFollowed.length} closes · ${escapeHtml(money(pnlOf(notFollowed)))}`, pnlClass(pnlOf(notFollowed))]])}`);
    }
    if (/sop|discipline|rule|follow|checklist|process/.test(lower)) {
      if (!trades.length) return coachEmit('sop', 'SOP check', `No closes this week to grade. When you log one, ask me for the SOP check.`);
      const rate = fmtNumber(followed.length / trades.length * 100, 0);
      const withPnl = pnlOf(followed);
      const withoutPnl = pnlOf(notFollowed);
      const verdict = Number(rate) >= 80 ? 'Elite adherence — that is the edge showing up in the data.' : Number(rate) >= 50 ? 'Mixed. The trades you planned paid differently than the ones you improvised.' : 'This is the leak. Fix the checklist before touching strategy.';
      return coachEmit('sop', 'SOP check', `${verdict} ${coachCard('SOP DISCIPLINE', [['Adherence', `${followed.length}/${trades.length} · ${rate}%`], ['With SOP', escapeHtml(money(withPnl)), pnlClass(withPnl)], ['Without SOP', escapeHtml(money(withoutPnl)), pnlClass(withoutPnl)], ['Cost of skipping', escapeHtml(money(withoutPnl - withPnl)), pnlClass(withoutPnl - withPnl)]])}`);
    }
    if (/symbol|pair|market|eurusd|xau|which.*(win|lose)/.test(lower)) {
      if (!symbols.length) return coachEmit('markets', '', `No closes this week, so no market breakdown yet.`);
      const worst = symbols[0];
      const best = symbols[symbols.length - 1];
      return coachEmit('markets', '', `This week ${escapeHtml(worst[0])} is your biggest drag (${escapeHtml(money(worst[1]))}) and ${escapeHtml(best[0])} your strongest (${escapeHtml(money(best[1]))}). ${worst[1] < 0 ? `Consider trading ${escapeHtml(worst[0])} half size until it turns, or skip it — the data is voting.` : 'Every market is net positive — rare, enjoy it.'} ${coachCard('MARKET BREAKDOWN', symbols.slice(0, 5).map(([sym, pnl]) => [escapeHtml(sym), escapeHtml(money(pnl)), pnlClass(pnl)]))}`);
    }
    if (/risk|limit|halt|stop trading|max loss|daily/.test(lower)) {
      const rows = [];
      if (risk.lossLimit) rows.push(['Loss used', `${escapeHtml(money(risk.lossUsed))} / ${escapeHtml(money(risk.lossLimit))}`, risk.level === 'halt' ? 'neg' : '']);
      if (risk.tradeLimit) rows.push(['Trades today', `${risk.todays.length} / ${risk.tradeLimit}`]);
      rows.push(['Today', escapeHtml(money(risk.dayPnl)), pnlClass(risk.dayPnl)]);
      rows.push(['Resets in', formatCountdown(risk.resetMs)]);
      const verdict = risk.level === 'halt' ? 'Limit hit — the journal is review-only until midnight. That rule is the coach.' : risk.level === 'warn' ? 'Close to the line. Size down or stop; do not negotiate with the meter.' : 'Within limits. Keep it that way by pre-committing the next trade size now.';
      return coachEmit('risk', 'daily risk', `${verdict} ${coachCard('DAILY RISK', rows)}`);
    }
    if (/focus|advice|improve|next|tip|plan|recommend|suggest|what should|how do i get/.test(lower)) return coachEmit('focus', 'weekly focus', coachWeeklyFocus(s));
    if (!_depth) {
      const learnedHit = matchLearnedPhrase(lower);
      if (learnedHit) {
        const replyText = coachReply(learnedHit.canonical, 1);
        coachLastHit = { ...coachLastHit, learnedQ: learnedHit.q };
        return replyText;
      }
    }
    const riskGlance = dailyRiskSummary();
    return coachEmit('fallback', '', `I didn't quite catch that — I'm deterministic, so I answer best when the topic is clear. ${coachCard('TRY ASKING', [['Who are you', 'Who I am & how I work'], ['Who am I', 'What I know about you'], ['1', 'Weekly goal report'], ['2', 'Recent trades — auto list'], ['Should I trade today', 'Risk pre-flight check'], ['Why did I lose', 'Loss autopsy'], ['Am I profitable', 'All-time verdict'], ['How many trades', 'Counts by period'], ['all-time report', 'Full stats & rules']])} ${coachCard('AT A GLANCE', [['Today', escapeHtml(money(riskGlance.dayPnl)), pnlClass(riskGlance.dayPnl)], ['Week equity', escapeHtml(money(ctx.achieved)), pnlClass(ctx.achieved)], ['Week closes', String(trades.length)], ['On record', String(state.trades.length)]])}`);
  }
  function pushCoachMessage(role, text, meta) {
    const key = weekKeyFor(0);
    if (!state.goalCoach || state.goalCoach.weekKey !== key || !Array.isArray(state.goalCoach.messages)) {
      state.goalCoach = { weekKey: key, messages: [] };
    }
    const msg = { role, text, ts: Date.now() };
    if (meta && meta.id) { msg.intent = meta.id; msg.canonical = meta.canonical || ''; if (meta.learnedQ) msg.learnedQ = meta.learnedQ; }
    state.goalCoach.messages.push(msg);
    if (state.goalCoach.messages.length > 40) state.goalCoach.messages = state.goalCoach.messages.slice(-40);
    persistState();
  }
  function ensureCoachThread() {
    const key = weekKeyFor(0);
    if (!state.goalCoach || state.goalCoach.weekKey !== key || !Array.isArray(state.goalCoach.messages) || !state.goalCoach.messages.length) {
      state.goalCoach = { weekKey: key, messages: [{ role: 'coach', text: coachGreeting(), ts: Date.now() }] };
      persistState();
    }
  }
  function submitCoachMessage(text) {
    const clean = String(text || '').trim();
    if (!clean) return;
    ensureCoachThread();
    pushCoachMessage('you', clean);
    ui.coachTyping = true;
    render();
    setTimeout(() => {
      const reply = coachReply(clean);
      ui.coachTyping = false;
      pushCoachMessage('coach', reply, coachLastHit);
      if (coachLastHit.id && coachLastHit.id !== 'fallback') {
        const memA = agentMemory();
        memA.counts[coachLastHit.id] = (memA.counts[coachLastHit.id] || 0) + 1;
        saveAgentMemory(memA);
      }
      render();
    }, 620);
  }
  function coachThumb(ts, vote) {
    const mem = agentMemory();
    const msgs = (state.goalCoach && Array.isArray(state.goalCoach.messages)) ? state.goalCoach.messages : [];
    const idx = msgs.findIndex(m => m.role === 'coach' && m.ts === ts);
    if (idx < 0) return;
    const msg = msgs[idx];
    const intent = msg.intent || '';
    const key = String(ts);
    let q = '';
    for (let j = idx - 1; j >= 0; j--) if (msgs[j].role === 'you') { q = msgs[j].text; break; }
    const nq = msg.learnedQ || normalizeCoachQuery(q);
    const prev = Number(mem.thumbs[key] || 0);
    let next = vote;
    if (prev === vote) next = 0;
    const dropPhrase = () => { const i = mem.phrases.findIndex(p => p.q === nq); if (i >= 0) mem.phrases.splice(i, 1); };
    if (prev === 1) dropPhrase();
    if (next === 1) {
      if (msg.canonical && nq) {
        const words = coachQueryWords(q);
        const existing = mem.phrases.find(p => p.q === nq);
        if (existing) { existing.hits += 1; existing.ts = Date.now(); existing.canonical = msg.canonical; existing.intent = intent; existing.words = words; }
        else mem.phrases.push({ q: nq, canonical: msg.canonical, intent, words, hits: 1, ts: Date.now() });
      }
    } else if (next === -1) dropPhrase();
    if (next === 0) delete mem.thumbs[key]; else mem.thumbs[key] = next;
    mem.phrases.sort((a, b) => (b.hits || 0) - (a.hits || 0) || (b.ts || 0) - (a.ts || 0));
    if (mem.phrases.length > 40) mem.phrases.length = 40;
    saveAgentMemory(mem);
    render();
  }
  function renderCoachChat() {
    ensureCoachThread();
    const memC = agentMemory();
    const chips = [
      ['1 · Goal report', '1'], ['2 · Recent trades', '2'], ['3 · Autopsy', '3'],
      ['4 · Discipline', '4'], ['5 · Risk check', '5'], ['6 · Focus', '6'],
      ['All-time report', 'all-time report'], ['Compare last week', 'compare last week'],
      ['My setups', 'my setups'], ['Biggest loss', 'biggest loss']
    ];
    const chipIntent = { '1': 'pace', '2': 'recent', '3': 'autopsy', '4': 'sop', '5': 'risk', '6': 'focus', 'all-time report': 'all-time-report', 'compare last week': 'compare-weeks', 'my setups': 'setups', 'biggest loss': 'biggest' };
    chips.forEach((c, i) => { c[2] = i; });
    chips.sort((a, b) => (memC.counts[chipIntent[b[1]]] || 0) - (memC.counts[chipIntent[a[1]]] || 0) || a[2] - b[2]);
    const messages = state.goalCoach.messages.map((m, i) => {
      const body = m.role === 'you' ? escapeHtml(m.text) : m.text;
      const delay = `style="animation-delay:${Math.min(i * 25, 250)}ms"`;
      return m.role === 'you'
        ? `<div class="coach-msg you" ${delay}><div class="coach-bubble">${body}</div></div>`
        : `<div class="coach-msg coach" ${delay}><div class="coach-avatar-sm" aria-hidden="true">N</div><div class="coach-body"><div class="coach-bubble">${body}</div>${m.intent && m.intent !== 'fallback' ? `<div class="coach-thumbs"><button type="button" class="coach-thumb${memC.thumbs[String(m.ts)] === 1 ? ' on' : ''}" data-action="coach-thumb" data-ts="${m.ts}" data-vote="1" title="Good answer" aria-label="Good answer" aria-pressed="${memC.thumbs[String(m.ts)] === 1}">✓</button><button type="button" class="coach-thumb${memC.thumbs[String(m.ts)] === -1 ? ' on bad' : ''}" data-action="coach-thumb" data-ts="${m.ts}" data-vote="-1" title="Bad answer" aria-label="Bad answer" aria-pressed="${memC.thumbs[String(m.ts)] === -1}">✗</button></div>` : ''}</div></div>`;
    }).join('');
    const typing = ui.coachTyping ? `<div class="coach-msg coach"><div class="coach-avatar-sm" aria-hidden="true">N</div><div class="coach-bubble coach-typing" aria-label="Agent Nketiah is thinking"><i></i><i></i><i></i></div></div>` : '';
    return `<section class="agent-panel" role="dialog" aria-label="Agent Nketiah chat">
      <header class="agent-head">
        <div class="coach-avatar agent-head-avatar">${icon('bolt', 15)}</div>
        <div class="agent-head-body"><h2>Agent Nketiah</h2><p>Journal desk · holds every close · offline engine</p></div>
        <button type="button" class="agent-icon-btn${ui.chipsOpen ? ' active' : ''}" data-action="agent-chips" title="Toggle quick replies" aria-label="Toggle quick replies" aria-pressed="${ui.chipsOpen}">${icon('sparkle', 14)}</button>
        <button type="button" class="agent-icon-btn" data-action="agent-new-chat" title="New chat" aria-label="New chat">${icon('plus', 14)}</button>
        <button type="button" class="agent-icon-btn" data-action="agent-toggle" title="Close chat" aria-label="Close chat">${icon('close', 14)}</button>
      </header>
      <div class="coach-messages agent-messages">${messages}${typing}</div>
      ${ui.chipsOpen ? `<div class="coach-chips agent-chips">${chips.map(([label, prompt]) => `<button type="button" class="coach-chip" data-action="coach-ask" data-prompt="${escapeAttr(prompt)}">${escapeHtml(label)}</button>`).join('')}</div>` : ''}
      <form id="goal-coach-form" class="coach-input-row agent-input-row"><input class="input-control" name="coachMessage" placeholder="Ask Agent Nketiah anything…" autocomplete="off" maxlength="240" required /><button class="primary-button small agent-send-btn" type="submit" aria-label="Send">${icon('send', 15)}</button></form>
    </section>`;
  }
  function renderAgentFab() {
    if (ui.agentOpen || ui.view !== 'goals') return '';
    return `<button type="button" class="agent-fab" data-action="agent-toggle" aria-label="Open Agent Nketiah" title="Agent Nketiah">${icon('chat', 22)}</button>`;
  }
  function initCoachChat() {
    const box = document.querySelector('.agent-messages');
    if (box) box.scrollTop = box.scrollHeight;
    const input = document.querySelector('#goal-coach-form input[name="coachMessage"]');
    if (input) input.focus();
  }
  function weekKeyFor(offset = 0) { return localDateString(weekStartFor(offset)); }
  function renderGoalDayDetail(ctx) {
    if (!ui.goalDay) return '';
    const slot = ctx.slots.find(s => s.date === ui.goalDay);
    if (!slot) return '';
    const dayTrades = state.trades.filter(t => t.closedAt === slot.date).slice().sort((a, b) => Math.abs(Number(b.pnlUsd || 0)) - Math.abs(Number(a.pnlUsd || 0)));
    const net = tradesPnl(dayTrades);
    const winsD = dayTrades.filter(t => Number(t.pnlUsd || 0) > 0);
    const lossesD = dayTrades.filter(t => Number(t.pnlUsd || 0) < 0);
    const winRateD = dayTrades.length ? `${fmtNumber(winsD.length / dayTrades.length * 100, 0)}%` : '—';
    const bestD = dayTrades.length ? dayTrades[0] : null;
    const worstD = dayTrades.length ? dayTrades[dayTrades.length - 1] : null;
    const fullDate = formatDate(slot.date, { weekday: 'long', day: 'numeric', month: 'long' });
    const setupNameOf = (t) => { const su = (state.setups || []).find(x => x.id === t.setupId); return su ? su.name : '—'; };
    const chips = dayTrades.length
      ? `<span class="pill ${pnlClass(net) === 'positive' ? 'mint' : net < 0 ? 'red' : ''}">Net ${escapeHtml(money(net, true))}</span><span class="pill">${dayTrades.length} close${dayTrades.length === 1 ? '' : 's'} · ${winRateD} win rate</span><span class="pill mint">Wins ${escapeHtml(money(tradesPnl(winsD), true))}</span><span class="pill red">Losses ${escapeHtml(money(tradesPnl(lossesD), true))}</span>${bestD ? `<span class="pill">Best ${escapeHtml(bestD.symbol)} ${escapeHtml(money(bestD.pnlUsd, true))}</span>` : ''}${worstD && worstD !== bestD ? `<span class="pill">Worst ${escapeHtml(worstD.symbol)} ${escapeHtml(money(worstD.pnlUsd, true))}</span>` : ''}`
      : `<span class="pill">No closes on ${escapeHtml(slot.label)} yet</span>`;
    const rows = dayTrades.slice(0, 50).map((t) => {
      const pnl = Number(t.pnlUsd || 0);
      return `<tr><td><strong>${escapeHtml(t.symbol)}</strong> <span class="muted">${escapeHtml(t.side)}</span></td><td><span class="amount ${pnlClass(pnl)}">${escapeHtml(money(pnl, true))}</span></td><td>${escapeHtml(t.exitReason || '—')}</td><td>${escapeHtml(setupNameOf(t))}</td><td>${t.followedSop ? `<span class="pill mint">${icon('check', 11)} SOP</span>` : '<span class="muted">—</span>'}</td></tr>`;
    }).join('');
    return `<div class="goal-day-detail" id="goal-day-detail">
      <div class="goal-day-detail-head"><div><h3>${escapeHtml(slot.label)} · ${escapeHtml(fullDate)}</h3><p>${dayTrades.length ? `${dayTrades.length} close${dayTrades.length === 1 ? '' : 's'}, net ${escapeHtml(money(net))}. Biggest first.` : 'Nothing logged on this session yet.'}</p></div><button type="button" class="secondary-button small" data-action="goal-day-close">Close</button></div>
      <div class="goal-day-chips">${chips}</div>
      ${dayTrades.length ? `<div class="trades-card"><div class="table-wrap"><table class="trade-table"><thead><tr><th>Market</th><th>P/L</th><th>Exit</th><th>Setup</th><th>SOP</th></tr></thead><tbody>${rows}</tbody></table></div></div>${dayTrades.length > 50 ? `<p class="footer-note">Showing the 50 biggest of ${dayTrades.length} closes — the full list lives in the Trade journal.</p>` : ''}` : ''}
    </div>`;
  }
  function renderGoals() {
    const ctx = weeklyGoalContext();
    const targetForm = `<form id="goal-form" class="goal-target-form"><label for="goal-target">Weekly profit goal · ${journalCurrency()}</label><div class="inline-row" style="gap:8px"><input id="goal-target" class="input-control" type="number" name="weeklyGoal" min="0" step="0.01" value="${escapeAttr(state.settings.weeklyGoal || '')}" placeholder="e.g. 250" style="max-width:180px" /><button class="primary-button small" type="submit">${icon('target', 14)} Save goal</button></div></form>`;
    if (!ctx.target) {
      return `<section class="surface-card goal-empty"><div class="empty-state"><div class="empty-visual">${icon('target', 24)}</div><h3>Set one number for the week</h3><p>Name the profit you want from Monday to Friday. The goal view tracks every closed trade against it — pace, remaining runway, and whether the week actually delivered.</p></div>${targetForm}<div class="inline-row" style="justify-content:center;margin-top:14px"><button class="secondary-button small" data-action="toggle-goal-equity">${icon('trend', 14)} Preview equity curve</button><button class="secondary-button small" data-action="agent-toggle">${icon('chat', 14)} Ask Agent Nketiah</button></div></section>`;
    }
    const ringPct = Math.min(100, Math.max(0, ctx.pct));
    const circumference = 2 * Math.PI * 46;
    const dash = circumference * ringPct / 100;
    const ringAnimate = !goalRingAnimated;
    goalRingAnimated = true;
    const ringStyle = `--ring-c:${circumference.toFixed(1)};--ring-offset:${(circumference - dash).toFixed(1)};stroke-dasharray:${dash.toFixed(1)} ${circumference.toFixed(1)}${ringAnimate ? '' : `;stroke-dashoffset:${(circumference - dash).toFixed(1)}`}`;
    const statusChips = { hit: ['mint', 'Goal hit'], ahead: ['mint', 'Ahead of pace'], behind: ['amber', 'Behind pace'], 'at-risk': ['red', 'At risk'], missed: ['red', 'Week closed short'], unset: ['', 'No target'] };
    const [chipClass, chipLabel] = statusChips[ctx.status] || statusChips.unset;
    const milestones = [25, 50, 75, 100];
    const maxAbs = Math.max(1, ...ctx.slots.map(slot => Math.abs(slot.pnl)));
    const dayColumns = ctx.slots.map(slot => {
      const positive = slot.pnl >= 0;
      const height = slot.pnl === 0 ? 2 : Math.max(6, Math.abs(slot.pnl) / maxAbs * 100);
      const isToday = slot.date === today;
      return `<button type="button" class="goal-day${isToday ? ' today' : ''}${ui.goalDay === slot.date ? ' selected' : ''}" data-action="goal-day" data-date="${escapeAttr(slot.date)}" aria-pressed="${ui.goalDay === slot.date}"><span class="goal-day-track"><span class="goal-day-bar ${positive ? '' : 'negative'}" style="height:${height.toFixed(1)}%" title="${escapeAttr(slot.label)} ${escapeAttr(money(slot.pnl))}"></span></span><span class="goal-day-label">${slot.label}</span><span class="goal-day-value ${pnlClass(slot.pnl)}">${slot.pnl === 0 ? '—' : escapeHtml(money(slot.pnl, true))}</span><span class="goal-day-count">${slot.count} trade${slot.count === 1 ? '' : 's'}</span></button>`;
    }).join('');
    const historyRows = ctx.history.map(week => {
      const start = weekStartFor(week.offset);
      const end = new Date(start.getFullYear(), start.getMonth(), start.getDate() + 4);
      const range = `${formatDate(localDateString(start), { day: 'numeric', month: 'short' })} – ${formatDate(localDateString(end), { day: 'numeric', month: 'short' })}`;
      const [cls, label] = week.hit ? ['mint', 'Hit'] : week.total >= 0 ? ['amber', 'Short'] : ['red', 'Drawdown'];
      return `<tr><td>${range}</td><td><span class="amount ${pnlClass(week.total)}">${escapeHtml(money(week.total))}</span></td><td>${week.pct >= 0 ? '+' : ''}${fmtNumber(week.pct, 0)}%</td><td><span class="pill ${cls}">${label}</span></td></tr>`;
    }).join('');
    return `<div class="goal-hero surface-card">
      <div class="goal-ring"><svg viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="46" class="goal-ring-track"></circle><circle cx="50" cy="50" r="46" class="goal-ring-value${ringAnimate ? ' animate' : ''}" style="${ringStyle}"></circle></svg><div class="goal-ring-center"><strong>${fmtNumber(Math.max(0, ctx.pct), 0)}%</strong><span>of goal</span></div></div>
      <div class="goal-hero-body">
        <div class="eyebrow">WEEK OF ${escapeHtml(formatDate(weekStartFor(0), { day: 'numeric', month: 'long' }).toUpperCase())}</div>
        <h2 class="goal-hero-title ${pnlClass(ctx.achieved)}">${escapeHtml(money(ctx.achieved))} <span>of ${escapeHtml(money(ctx.target))}</span></h2>
        <div class="goal-hero-chips"><span class="pill ${chipClass}">${chipLabel}</span><span class="pill">${ctx.daysLeft} session${ctx.daysLeft === 1 ? '' : 's'} left</span>${ctx.pct >= 100 ? '<span class="pill mint">Locked in</span>' : ''}</div>
        <p class="goal-hero-note">${ctx.status === 'hit' ? `Goal cleared with ${escapeHtml(money(Math.max(0, ctx.achieved - ctx.target)))} to spare. Protect it — do not give it back.` : ctx.daysLeft > 0 ? `Need ${escapeHtml(money(ctx.requiredPerDay))} per remaining session to land the goal. Expected pace so far: ${escapeHtml(money(ctx.expected))}.` : 'The Monday–Friday window has closed. Review the week, then set the next one.'}</p>
        ${targetForm}
      </div>
    </div>
    <div class="stats-grid">
      ${metricCard(`WEEKLY GOAL · ${journalCurrency()}`, money(ctx.target), 'Monday–Friday closes', 'target')}
      ${metricCard('ACHIEVED', money(ctx.achieved), `${ctx.slots.reduce((s, x) => s + x.count, 0)} closes this week`, 'dollar', ctx.achieved > 0 ? 'positive' : ctx.achieved < 0 ? 'negative' : '')}
      ${metricCard('REMAINING', ctx.remaining < 0 ? `+${money(Math.abs(ctx.remaining))}` : money(ctx.remaining), ctx.remaining < 0 ? 'Spare above goal' : `${ctx.daysLeft} session${ctx.daysLeft === 1 ? '' : 's'} of runway left`, 'trend', ctx.remaining < 0 ? 'positive' : '')}
      ${metricCard('REQUIRED PACE', ctx.daysLeft > 0 ? money(ctx.requiredPerDay) : money(Math.max(0, ctx.remaining)), ctx.daysLeft > 0 ? `per session · expected today ${money(ctx.expected)}` : 'Window complete', 'clock', ctx.paceDelta >= 0 ? 'positive' : 'negative')}
    </div>
    <section class="surface-card goal-week"><div class="section-title-row" style="margin:0 0 14px"><div><h2>Session runway</h2><p>Monday–Friday closes against the goal line. Weekend trades stay in monthly results only.</p></div>      <div class="inline-row" style="gap:10px"><button class="secondary-button small" data-action="toggle-goal-equity">${icon('trend', 14)} Equity curve</button><button class="secondary-button small" data-action="agent-toggle">${icon('chat', 14)} Ask agent</button><span class="pill">${ctx.paceDelta >= 0 ? '+' : ''}${escapeHtml(money(ctx.paceDelta))} vs pace</span></div></div>
      <div class="goal-days">${dayColumns}</div>
      ${renderGoalDayDetail(ctx)}
      <div class="goal-pace-line"><span>Goal line</span><div class="goal-pace-bar"><span style="width:${Math.min(100, Math.max(0, ctx.pct)).toFixed(1)}%"></span></div><strong>${escapeHtml(money(ctx.achieved))} / ${escapeHtml(money(ctx.target))}</strong></div>
      <div class="goal-milestones">${milestones.map(m => `<span class="goal-milestone ${ctx.pct >= m ? 'reached' : ''}">${icon('check', 12)} ${m}%</span>`).join('')}</div>
    </section>
    <section class="surface-card goal-history"><div class="section-title-row" style="margin:0 0 14px"><div><h2>Recent goal weeks</h2><p>The last four Monday–Friday windows, measured against today’s target.</p></div></div>
      <div class="trades-card"><div class="table-wrap"><table class="trade-table"><thead><tr><th>Week</th><th>Net P/L · ${journalCurrency()}</th><th>Of goal</th><th>Result</th></tr></thead><tbody>${historyRows}</tbody></table></div></div>
      <p class="footer-note">Goals are measured from closed trades only, using the close date. Open positions and live floating P/L are not counted.</p>
    </section>`;
  }
  function renderDailyRiskPanel() {
    const risk = dailyRiskSummary();
    if (!risk.configured) return '';
    const copy = risk.level === 'halt' ? 'Limit reached — stand down and review.'
      : risk.level === 'warn' ? 'Close to your limit. Size down or stop.'
        : 'Within your limits today. Resets at local midnight.';
    const recent = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const key = localDateString(date);
      const closed = state.trades.filter(t => t.closedAt === key);
      const pnl = closed.reduce((sum, t) => sum + Number(t.pnlUsd || 0), 0);
      const breach = risk.lossLimit > 0 && -pnl >= risk.lossLimit;
      recent.push({ key, pnl, count: closed.length, breach, label: formatDate(key, { weekday: 'short', day: 'numeric' }) });
    }
    const riskPanels = [risk.lossLimit ? 1 : 0, risk.tradeLimit ? 1 : 0].filter(Boolean).length;
    return `<section class="surface-card risk-panel" data-risk-panel><div class="section-title-row" style="margin:0 0 14px"><div><h2>Daily risk console</h2><p>${escapeHtml(copy)}</p></div><button class="text-button" data-action="navigate" data-view="settings">Edit limits ${icon('chevronRight', 13)}</button></div>
      <div class="two-column${riskPanels === 1 ? ' single' : ''}">
        ${risk.lossLimit ? `<div class="metric-mini"><div class="label">Daily loss limit</div><div class="value ${risk.level === 'halt' ? 'negative' : ''}">${escapeHtml(money(risk.lossUsed))} / ${escapeHtml(money(risk.lossLimit))}</div>${riskMeter(risk.lossPct, risk.level)}<div class="helper">Today’s closes: ${escapeHtml(money(risk.dayPnl))} · ${Math.round(risk.lossPct)}% of limit used</div></div>` : ''}
        ${risk.tradeLimit ? `<div class="metric-mini"><div class="label">Trade count limit</div><div class="value ${risk.level === 'halt' ? 'negative' : ''}">${risk.todays.length} / ${risk.tradeLimit}</div>${riskMeter(risk.countPct, risk.level)}<div class="helper">Closed positions logged today</div></div>` : ''}
      </div>
      <div class="risk-history"><div class="label">Last 7 sessions</div><div class="risk-history-days">${recent.map(day => `<span class="risk-day ${day.breach ? 'breach' : pnlClass(day.pnl)}" title="${escapeAttr(`${day.label} · ${money(day.pnl)} · ${day.count} trades`)}"><em>${escapeHtml(day.label.split(' ')[1] || day.label)}</em><i>${day.pnl === 0 && !day.count ? '·' : escapeHtml(money(day.pnl, true))}</i></span>`).join('')}</div></div>
    </section>`;
  }
  function renderPerformance() {
    const trades = getSelectedTrades();
    const stats = getStats(trades);
    const bins = getTrendBins(trades, ui.period);
    const pnlDisplay = money(stats.pnl);
    const signClass = stats.pnl > 0 ? 'positive' : stats.pnl < 0 ? 'negative' : '';
    const rate = stats.winRate === null ? '—' : `${fmtNumber(stats.winRate,1)}%`;
    const yearLabel = ui.year === 'all' ? 'All years' : ui.year;
    const symbolLabel = ui.symbol === 'all' ? 'all symbols' : ui.symbol;
    return `<div class="stats-grid">
      ${metricCard(`NET PROFIT · ${journalCurrency()}`,  pnlDisplay, 'After commission & swap', 'dollar', signClass)}
      ${metricCard('WIN RATE', rate, stats.total ? 'Breakeven included in denominator' : 'No closed trades in this view', 'target')}
      ${metricCard('WIN / LOSS', `${stats.wins} / ${stats.losses}`, `${stats.breakevens} breakeven${stats.breakevens===1?'':'s'}`, 'trend')}
      ${metricCard('TOTAL TRADES', String(stats.total), `${yearLabel} · ${symbolLabel}`, 'journal')}
    </div>
    ${renderDailyRiskPanel()}
    <div class="controls-row"><div class="segmented" role="tablist" aria-label="Performance grouping"><button class="${ui.period==='weekly'?'active':''}" data-action="set-period" data-period="weekly" role="tab" aria-selected="${ui.period==='weekly'}">Weekly</button><button class="${ui.period==='monthly'?'active':''}" data-action="set-period" data-period="monthly" role="tab" aria-selected="${ui.period==='monthly'}">Monthly</button></div>${filterOptions()}</div>
    ${state.sampleWorkspace ? `<div class="warning-banner" style="margin:0 0 14px">Sample workspace loaded — these trades are fictional. <button class="text-button" style="display:inline-flex;padding:0 2px" data-action="clear-sample">Clear sample data</button></div>` : ''}
    <section class="chart-card"><div class="chart-top"><div><h2>${ui.period==='weekly'?'Weekly':'Monthly'} net P/L</h2><p>${ui.period==='weekly'?'Weekday closes, Monday–Friday':'All calendar days, including weekends'} · ${yearLabel} · ${symbolLabel}</p></div><div class="chart-legend"><span class="legend-dot"></span>Net P/L</div></div>${renderChart(bins,ui.period,trades.length>0)}</section>
    <div class="section-title-row"><div><h2>Recent trades</h2><p>Closed positions in the selected year and symbol.</p></div><button class="text-button" data-action="navigate" data-view="journal">View journal ${icon('chevronRight',14)}</button></div>
    ${renderTradeTable(sortTrades(trades).slice(0,5), { compact: true })}
    <p class="footer-note">Results use the trade close date. Weekly chart groups exclude weekend closes; monthly and headline totals include them.</p>`;
  }
  function renderTradeTable(trades, { compact = false } = {}) {
    if (!trades.length) return `<div class="trades-card"><div class="table-empty">No trades match this view yet. Add a closed position to begin your journal.</div></div>`;
    return `<div class="trades-card"><div class="table-wrap"><table class="trade-table"><thead><tr><th>Close date</th><th>Symbol</th><th>Setup / discipline</th><th>Result</th><th>Net P/L · ${journalCurrency()}</th>${compact?'':'<th></th>'}</tr></thead><tbody>${trades.map(t => {
      const setup = getSetup(t.setupId);
      const sop = t.followedSop === 'yes' ? '<span class="pill mint">SOP followed</span>' : t.followedSop === 'no' ? '<span class="pill red">SOP missed</span>' : '<span class="pill">SOP —</span>';
      return `<tr data-action="trade-detail" data-id="${escapeAttr(t.id)}"><td>${formatDate(t.closedAt,{day:'2-digit',month:'short',year:'numeric'})}</td><td><span class="trade-symbol"><span class="symbol-mark">${escapeHtml(t.symbol.slice(0,2))}</span>${escapeHtml(t.symbol)}</span></td><td>${setup?`<span class="pill">${escapeHtml(setup.name)}</span>`:sop}</td><td>${resultChip(t)}</td><td><span class="amount ${pnlClass(t.pnlUsd)}">${money(t.pnlUsd)}</span></td>${compact?'':`<td><button class="icon-button" style="width:30px;height:30px" title="Open trade" data-action="trade-detail" data-id="${escapeAttr(t.id)}">${icon('arrowUpRight',14)}</button></td>`}</tr>`;
    }).join('')}</tbody></table></div><div class="table-footer"><span>${trades.length} closed position${trades.length===1?'':'s'}</span><span>Sorted by close date</span></div></div>`;
  }

  function renderJournal() {
    const all = getSelectedTrades();
    const query = ui.search.trim().toLowerCase();
    const trades = sortTrades(all.filter(t => !query || [t.symbol,t.notes,getSetup(t.setupId)?.name].some(v => String(v||'').toLowerCase().includes(query))));
    const days = new Map();
    trades.forEach(t => { const key = t.closedAt || ''; if (!days.has(key)) days.set(key, []); days.get(key).push(t); });
    const grouped = [...days.entries()].map(([date, items]) => {
      const dailyStats = getStats(items);
      return `<section class="journal-day surface-card"><div class="journal-day-head"><div><strong>${formatDate(date,{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</strong><span>${items.length} closed position${items.length===1?'':'s'}</span></div><strong class="amount ${pnlClass(dailyStats.pnl)}">${money(dailyStats.pnl)}</strong></div><div class="journal-day-trades">${items.map(t => renderJournalTrade(t)).join('')}</div></section>`;
    }).join('');
    return `<div class="toolbar-row journal-toolbar"><div class="search-field">${icon('search',15)}<input id="journal-search" type="search" placeholder="Search symbol, setup or notes" value="${escapeAttr(ui.search)}" autocomplete="off"></div>${filterOptions()}<button class="secondary-button small" data-action="trigger-import">${icon('upload',14)} Import</button><button class="secondary-button small" data-action="export-json">${icon('download',14)} Backup JSON</button><input id="import-file" type="file" accept=".csv,.json,application/json,text/csv" class="hidden-input" /></div>
      <div class="inline-row" style="justify-content:space-between;margin:18px 0 12px"><div class="small-muted">${trades.length} result${trades.length===1?'':'s'} · ${ui.year==='all'?'all years':ui.year}</div><button class="text-button" data-action="clear-search">Clear filters</button></div>
      ${trades.length ? grouped : `<div class="surface-card" style="padding:32px 20px"><div class="empty-state"><div class="empty-visual">${icon('journal',24)}</div><h3>Your journal is ready</h3><p>${all.length && query ? 'No trades match that search. Try another word or clear the search.' : 'Each trade is a chance to record the process, not just the result.'}</p><div class="empty-actions"><button class="primary-button small" data-action="new-trade">${icon('plus',14)} Add trade</button>${!state.trades.length?'<button class="secondary-button small" data-action="load-sample">Explore sample data</button>':''}</div></div></div>`}`;
  }
  function renderJournalTrade(t) {
    const setup = getSetup(t.setupId);
    const images = getAllPhotoIds(t).length;
    return `<article class="journal-trade" data-action="trade-detail" data-id="${escapeAttr(t.id)}"><div class="journal-trade-left"><div class="symbol-mark">${escapeHtml(t.symbol.slice(0,2))}</div><div class="journal-trade-copy"><div class="journal-trade-title"><strong>${escapeHtml(t.symbol)}</strong>${setup?`<span class="pill">${escapeHtml(setup.name)}</span>`:''}${resultChip(t)}</div><p>${escapeHtml((t.notes||'No review notes added.').slice(0,130))}${(t.notes||'').length>130?'…':''}</p><div class="journal-trade-meta"><span>${t.followedSop==='yes'?'SOP followed':t.followedSop==='no'?'SOP not followed':'SOP not recorded'}</span>${t.snrTf?`<span>· SNR ${escapeHtml(t.snrTf)}</span>`:''}${images?`<span>· ${images} chart image${images===1?'':'s'}</span>`:''}</div></div></div><div class="journal-trade-result"><strong class="amount ${pnlClass(t.pnlUsd)}">${money(t.pnlUsd)}</strong><span>${t.collectedPips!==''&&t.collectedPips!=null?`${fmtNumber(t.collectedPips,1)} pips`:formatDate(t.closedAt,{day:'2-digit',month:'short'})}</span></div></article>`;
  }

  function renderPlaybook() {
    const setups = [...state.setups].sort((a,b) => a.name.localeCompare(b.name));
    const cards = setups.map(s => {
      const trades = state.trades.filter(t => t.setupId === s.id);
      const stats = getStats(trades);
      const avg = trades.length ? stats.pnl/trades.length : null;
      const symbols = (s.symbols || '').split(',').map(x=>x.trim()).filter(Boolean);
      const tfs = (s.timeframes || '').split(',').map(x=>x.trim()).filter(Boolean);
      return `<article class="setup-card"><div class="setup-card-top"><div class="setup-symbol">${icon('target',17)}</div><div class="card-actions"><button class="icon-button" style="width:31px;height:31px" title="Edit setup" data-action="edit-setup" data-id="${escapeAttr(s.id)}">${icon('edit',14)}</button><button class="icon-button" style="width:31px;height:31px" title="More options" data-action="setup-menu" data-id="${escapeAttr(s.id)}">${icon('more',15)}</button></div></div><h3>${escapeHtml(s.name)}</h3><p>${escapeHtml(s.description || s.entryTrigger || 'No setup summary added yet.')}</p><div class="chip-list">${[...symbols,...tfs].slice(0,5).map(v=>`<span class="chip">${escapeHtml(v)}</span>`).join('')}${!symbols.length&&!tfs.length?'<span class="chip">Add timeframe or symbol</span>':''}</div><div class="setup-stats"><div><span>Trades</span><strong>${stats.total}</strong></div><div><span>Win rate</span><strong>${stats.winRate===null?'—':`${fmtNumber(stats.winRate,0)}%`}</strong></div><div><span>Net P/L</span><strong class="amount ${pnlClass(stats.pnl)}">${money(stats.pnl,true)}</strong></div></div><div class="inline-row" style="justify-content:space-between;margin-top:13px"><span class="small-muted">Avg / trade ${avg===null?'—':money(avg,true)}</span><button class="text-button" data-action="setup-detail" data-id="${escapeAttr(s.id)}">Open setup ${icon('chevronRight',13)}</button></div></article>`;
    }).join('');
    return `<div class="info-banner" style="margin-bottom:17px">Your playbook turns SNR rules into reviewable setups. Trades can be linked to a setup when logged; unassigned trades stay in the journal and are not counted in setup stats.</div>
      <div class="section-title-row" style="margin-top:0"><div><h2>Your setups</h2><p>Setup results use the same P/L and breakeven definitions as your dashboard.</p></div><button class="primary-button small" data-action="new-setup">${icon('plus',14)} Add setup</button></div>
      ${setups.length?`<div class="cards-grid">${cards}</div>`:`<div class="surface-card" style="padding:38px 22px"><div class="empty-state"><div class="empty-visual">${icon('playbook',24)}</div><h3>Build your first SNR setup</h3><p>Capture its rules, entry trigger, preferred timeframes, and what invalidates the idea. You can link trades to it as you review.</p><div class="empty-actions"><button class="primary-button small" data-action="new-setup">${icon('plus',14)} Create first setup</button><button class="secondary-button small" data-action="load-sample">Explore sample data</button></div></div></div>`}`;
  }
  function renderPlans() {
    const plans = [...state.plans].sort((a,b) => (b.createdAt||'').localeCompare(a.createdAt||''));
    return `<div class="info-banner" style="margin-bottom:17px">Plan fields are optional and separate from a closed trade. When you log an outcome, you can link it back to an executed plan.</div><div class="section-title-row" style="margin-top:0"><div><h2>Trade plans</h2><p>Thesis, levels, and intended risk—before the result is known.</p></div><button class="primary-button small" data-action="new-plan">${icon('plus',14)} New plan</button></div>
      ${plans.length?`<div class="cards-grid">${plans.map(p=>{const linked=getTrade(p.tradeId);return `<article class="plan-card"><div class="inline-row" style="justify-content:space-between"><span class="plan-status ${escapeAttr(p.status)}">${escapeHtml(p.status[0].toUpperCase()+p.status.slice(1))}</span><button class="icon-button" style="width:31px;height:31px" data-action="plan-menu" data-id="${escapeAttr(p.id)}">${icon('more',15)}</button></div><h3>${escapeHtml(p.symbol||'Untitled plan')} · ${formatDate(p.createdAt?.slice(0,10)||today,{day:'2-digit',month:'short'})}</h3><p>${escapeHtml(p.thesis||'No thesis recorded.')}</p><div class="chip-list">${p.timeframe?`<span class="chip">${escapeHtml(p.timeframe)}</span>`:''}${p.entry?`<span class="chip">Entry ${escapeHtml(p.entry)}</span>`:''}${p.target?`<span class="chip">Target ${escapeHtml(p.target)}</span>`:''}</div>${linked?`<div class="info-banner" style="margin-top:12px">Linked to ${escapeHtml(linked.symbol)} · <span class="amount ${pnlClass(linked.pnlUsd)}">${money(linked.pnlUsd)}</span></div>`:`<div class="inline-row" style="justify-content:space-between;margin-top:13px"><span class="small-muted">${p.stop?`Stop ${escapeHtml(p.stop)}`:'No stop recorded'}</span>${p.status==='pending'?`<button class="text-button" data-action="plan-status" data-id="${escapeAttr(p.id)}" data-status="cancelled">Cancel plan</button>`:''}</div>`}</article>`}).join('')}</div>`:`<div class="surface-card" style="padding:38px 22px"><div class="empty-state"><div class="empty-visual">${icon('plans',24)}</div><h3>Plan before the trade</h3><p>Write the thesis, entry area, stop, and target. When it executes, link your closed position to review plan versus outcome.</p><button class="primary-button small" data-action="new-plan">${icon('plus',14)} Create a plan</button></div></div>`}`;
  }

  function renderCalendar() {
    const month = new Date(ui.calendarMonth.getFullYear(),ui.calendarMonth.getMonth(),1);
    const year = month.getFullYear(); const monthIndex = month.getMonth();
    const first = new Date(year,monthIndex,1); const days = new Date(year,monthIndex+1,0).getDate();
    const offset = (first.getDay()+6)%7;
    const relevant = state.trades.filter(t => ui.calendarSymbol==='all'||t.symbol===ui.calendarSymbol);
    const daily = new Map();
    relevant.forEach(t=>{const d=parseDate(t.closedAt); if(d.getFullYear()===year&&d.getMonth()===monthIndex){const key=d.getDate();const item=daily.get(key)||{pnl:0,count:0};item.pnl+=Number(t.pnlUsd||0);item.count++;daily.set(key,item);}});
    const monthTrades = relevant.filter(t=>{const d=parseDate(t.closedAt);return d.getFullYear()===year&&d.getMonth()===monthIndex;});
    const stats=getStats(monthTrades);
    const cells = Array.from({length:offset},()=>'<div class="calendar-day empty"></div>');
    for(let day=1;day<=days;day++){
      const d=new Date(year,monthIndex,day);const info=daily.get(day);const wknd=d.getDay()===0||d.getDay()===6;const dayKey=`${year}-${String(monthIndex+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
      const pnl=info?.pnl||0;
      cells.push(`<button class="calendar-day ${wknd?'weekend':''} ${info?(pnl>0?'has-pos':pnl<0?'has-neg':''):''}" data-action="calendar-day" data-date="${dayKey}"><span class="day-number">${day}</span>${info?`<span class="day-pnl">${pnl>0?'+':''}${money(pnl,true)}</span><span class="trade-count">${info.count} trade${info.count===1?'':'s'}</span>`:'<span class="trade-count">&nbsp;</span>'}</button>`);
    }
    const symbols=symbolsForFilter();
    return `<div class="three-column" style="margin-bottom:15px"><div class="metric-mini"><div class="label">Month net P/L</div><div class="value amount ${pnlClass(stats.pnl)}">${money(stats.pnl)}</div><div class="helper">Close-date totals · weekends included</div></div><div class="metric-mini"><div class="label">Closed positions</div><div class="value">${stats.total}</div><div class="helper">${stats.wins} wins · ${stats.losses} losses · ${stats.breakevens} BE</div></div><div class="metric-mini"><div class="label">Positive days</div><div class="value">${[...daily.values()].filter(x=>x.pnl>0).length}</div><div class="helper">Days with net positive P/L</div></div></div>
      <section class="surface-card"><div class="calendar-head"><div class="calendar-controls"><button class="icon-button" data-action="calendar-move" data-delta="-1" aria-label="Previous month">${icon('chevronLeft',15)}</button><div class="calendar-month">${month.toLocaleDateString('en-GB',{month:'long',year:'numeric'})}</div><button class="icon-button" data-action="calendar-move" data-delta="1" aria-label="Next month">${icon('chevronRight',15)}</button><button class="text-button" data-action="calendar-today">Today</button></div><div class="select-wrap"><select data-filter="calendar-symbol"><option value="all">All symbols</option>${symbols.map(s=>`<option value="${escapeAttr(s)}" ${ui.calendarSymbol===s?'selected':''}>${escapeHtml(s)}</option>`).join('')}</select></div></div><div class="calendar-grid">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d=>`<div class="calendar-weekday">${d}</div>`).join('')}${cells.join('')}</div><div class="calendar-legend"><span><span class="legend-dot" style="display:inline-block;vertical-align:middle;margin-right:5px"></span>Positive day</span><span style="color:#ff8993">● Negative day</span><span>Weekend trades count in monthly totals.</span></div></section>`;
  }

  function renderEquityChart(points, startingBalance) {
    if (!points.length) return '';
    const values=[startingBalance,...points.map(p=>p.value)];
    const min=Math.min(...values);const max=Math.max(...values);const span=Math.max(1,max-min);
    const width=760;const height=164;const left=16;const right=width-12;const top=12;const bottom=height-22;
    const coords=values.map((value,index)=>{const x=values.length===1?left:left+(right-left)*index/(values.length-1);const y=top+(max-value)/span*(bottom-top);return `${x.toFixed(1)},${y.toFixed(1)}`;});
    const final=coords[coords.length-1].split(',');
    return `<div class="equity-chart-wrap"><svg class="equity-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="P/L-based equity curve"><line x1="${left}" y1="${top}" x2="${right}" y2="${top}" stroke="#292d33"/><line x1="${left}" y1="${bottom}" x2="${right}" y2="${bottom}" stroke="#292d33"/><polyline points="${coords.join(' ')}" fill="none" stroke="#39dda0" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${final[0]}" cy="${final[1]}" r="4" fill="#39dda0" stroke="#10241b" stroke-width="2"/><text x="${left}" y="${height-4}" fill="#737982" font-size="9">Start</text><text x="${right}" y="${height-4}" text-anchor="end" fill="#737982" font-size="9">Latest close</text></svg><div class="equity-axis-labels"><span>${money(max,true)}</span><span>${money(min,true)}</span></div></div>`;
  }
  function renderAnalytics() {
    const trades = getSelectedTrades();
    const stats = getStats(trades);
    const wins = trades.filter(t=>Number(t.pnlUsd)>0).map(t=>Number(t.pnlUsd));
    const losses = trades.filter(t=>Number(t.pnlUsd)<0).map(t=>Number(t.pnlUsd));
    const grossWin = wins.reduce((a,b)=>a+b,0);
    const grossLoss = Math.abs(losses.reduce((a,b)=>a+b,0));
    const pf = grossLoss ? grossWin/grossLoss : grossWin ? Infinity : null;
    const avgWin = wins.length?grossWin/wins.length:null;
    const avgLoss = losses.length?losses.reduce((a,b)=>a+b,0)/losses.length:null;
    const expectancy = trades.length?stats.pnl/trades.length:null;
    const sortedAsc = [...trades].sort((a,b)=>(a.closedAt||'').localeCompare(b.closedAt||''));
    let curStreak=0,bestStreak=0,last=0;
    sortedAsc.forEach(t=>{const sign=Math.sign(Number(t.pnlUsd));if(sign>0){curStreak=last>0?curStreak+1:1;bestStreak=Math.max(bestStreak,curStreak);}else{curStreak=0;}last=sign;});
    const symbols = [...new Set(trades.map(t=>t.symbol))].map(symbol=>{const ts=trades.filter(t=>t.symbol===symbol);return {symbol,...getStats(ts)};}).sort((a,b)=>b.pnl-a.pnl);
    const setupStats=state.setups.map(s=>({setup:s,...getStats(trades.filter(t=>t.setupId===s.id))})).filter(x=>x.total).sort((a,b)=>b.pnl-a.pnl);
    const balance=Number(state.settings.startingBalance||0);
    const equity = balance>0 ? sortedAsc.reduce((arr,t)=>{const prev=arr.length?arr[arr.length-1].value:balance;arr.push({date:t.closedAt,value:prev+Number(t.pnlUsd||0)});return arr;},[]) : [];
    let runningPeak=balance;let maxDrawdown=0;
    equity.forEach(point=>{runningPeak=Math.max(runningPeak,point.value);maxDrawdown=Math.max(maxDrawdown,runningPeak-point.value);});
    return `<div class="inline-row" style="justify-content:space-between;margin-bottom:15px"><div class="small-muted">${ui.year==='all'?'All years':ui.year} · ${ui.symbol==='all'?'All symbols':escapeHtml(ui.symbol)}</div>${filterOptions()}</div>
      <div class="three-column">${metricCard('PROFIT FACTOR',pf===null?'—':pf===Infinity?'∞':fmtNumber(pf,2),'Gross wins ÷ gross losses','trend')}${metricCard('AVERAGE WIN',avgWin===null?'—':money(avgWin),'Per winning closed position','trend')}${metricCard('AVERAGE LOSS',avgLoss===null?'—':money(avgLoss),'Per losing closed position','trendDown')}${metricCard('EXPECTANCY',expectancy===null?'—':money(expectancy),'Average net P/L per trade','dollar',expectancy>0?'positive':expectancy<0?'negative':'')}${metricCard('WIN STREAK',String(bestStreak),'Longest consecutive wins in this view','bolt')}${metricCard('MAX DRAWDOWN',balance>0?money(maxDrawdown):'—',balance>0?'From configured starting balance':'Set a starting balance in Settings','trendDown')}</div>
      <div class="two-column" style="margin-top:16px"><section class="surface-card" style="padding:18px"><div class="section-title-row" style="margin:0 0 13px"><div><h2>Results by symbol</h2><p>Net P/L with all close dates in the selected filter.</p></div></div>${symbols.length?`<div class="analytics-list">${symbols.map(x=>`<div class="analytics-row"><div><strong>${escapeHtml(x.symbol)}</strong><span>${x.total} trades · ${x.winRate===null?'—':`${fmtNumber(x.winRate,0)}% win rate`}</span></div><strong class="amount ${pnlClass(x.pnl)}">${money(x.pnl)}</strong></div>`).join('')}</div>`:'<div class="table-empty">Add trades to compare symbols.</div>'}</section>
      <section class="surface-card" style="padding:18px"><div class="section-title-row" style="margin:0 0 13px"><div><h2>Results by setup</h2><p>Only trades linked to an SNR playbook setup.</p></div><button class="text-button" data-action="navigate" data-view="playbook">Open playbook ${icon('chevronRight',13)}</button></div>${setupStats.length?`<div class="analytics-list">${setupStats.map(x=>`<div class="analytics-row"><div><strong>${escapeHtml(x.setup.name)}</strong><span>${x.total} trades · ${x.winRate===null?'—':`${fmtNumber(x.winRate,0)}% win rate`}</span></div><strong class="amount ${pnlClass(x.pnl)}">${money(x.pnl)}</strong></div>`).join('')}</div>`:'<div class="table-empty">Link trades to setups to see this breakdown.</div>'}</section></div>
      <section class="surface-card" style="padding:18px;margin-top:16px"><div class="section-title-row" style="margin:0 0 13px"><div><h2>Equity & drawdown</h2><p>Trade P/L accumulation from your configured starting balance.</p></div><button class="text-button" data-action="navigate" data-view="settings">Set balance ${icon('chevronRight',13)}</button></div>${balance>0&&equity.length?`<div class="equity-summary"><div><span>Starting balance</span><strong>${money(balance)}</strong></div><div><span>Current journal equity*</span><strong>${money(balance+stats.pnl)}</strong></div><div><span>Maximum drawdown</span><strong class="amount neg">${money(maxDrawdown)}</strong></div></div>${renderEquityChart(equity,balance)}<div class="warning-banner" style="margin-top:12px">*P/L-only estimate. Deposits, withdrawals, open positions, and unrealized results are not included. Use this as a journal view, not a broker balance.</div>`:`<div class="empty-state" style="padding:18px"><div class="empty-visual">${icon('analytics',23)}</div><h3>Starting balance needed</h3><p>Set a starting balance to preview the P/L-based equity curve. Cash flows and open positions are not included in this prototype.</p><button class="secondary-button small" data-action="navigate" data-view="settings">Open settings</button></div>`}</section>
      <div class="section-title-row"><div><h2>Advanced analysis</h2><p>We’ll only show these when the required data is available.</p></div></div><div class="cards-grid"><article class="setup-card"><span class="pill">Needs entry time</span><h3>Time-of-day performance</h3><p>Requires entry timestamps and a selected timezone.</p></article><article class="setup-card"><span class="pill">Needs risk / excursion data</span><h3>R-multiple & execution</h3><p>Requires trade risk, stop/size details, or MAE/MFE measurements.</p></article><article class="setup-card"><span class="pill">Optional insight</span><h3>Discipline patterns</h3><p>Descriptive SOP and trade-count trends with transparent rules and sample sizes.</p></article></div>`;
  }

  function aiWeekStartKey(value) {
    if(!value)return null;
    const d=parseDate(value);const day=d.getDay();if(day===0||day===6)return null;
    d.setDate(d.getDate()-(day-1));return localDateString(d);
  }
  function aiWeekOptions() {
    const keys=[...new Set(state.trades.map(t=>aiWeekStartKey(t.closedAt)).filter(Boolean))].sort((a,b)=>b.localeCompare(a));
    if(!keys.length){const d=parseDate(today);const day=d.getDay();d.setDate(d.getDate()-(day===0?6:day-1));keys.push(localDateString(d));}
    return keys;
  }
  function aiTradesForWeek(startKey) {
    if(!startKey)return [];
    const end=parseDate(startKey);end.setDate(end.getDate()+4);const endKey=localDateString(end);
    return sortTrades(state.trades.filter(t=>t.closedAt>=startKey&&t.closedAt<=endKey));
  }
  function aiWeekLabel(startKey) {
    const start=parseDate(startKey);const end=new Date(start);end.setDate(end.getDate()+4);
    return `${formatDate(startKey,{day:'numeric',month:'short',year:'numeric'})} – ${formatDate(localDateString(end),{day:'numeric',month:'short',year:'numeric'})}`;
  }
  function aiSelectedPhotos(trades) {
    const photos=[];const seen=new Set();
    for(const trade of trades)for(const stage of Object.keys(stageMeta)){
      if(!ui.aiStages[stage])continue;
      for(const photo of getStageImages(trade)[stage])if(!seen.has(photo.id)){seen.add(photo.id);photos.push({trade,stage,photo});}
    }
    return photos;
  }
  function aiStageCounts(trades) {
    const counts={before:0,during:0,after:0};
    for(const trade of trades)for(const stage of Object.keys(counts))counts[stage]+=getStageImages(trade)[stage].length;
    return counts;
  }
  function renderAiStageChoices(trades) {
    const counts=aiStageCounts(trades);
    return `<div class="ai-stage-choices">${Object.keys(stageMeta).map(stage=>`<label class="ai-stage-choice"><input type="checkbox" data-ai-stage="${stage}" ${ui.aiStages[stage]?'checked':''} ${ui.aiRequesting?'disabled':''}/><span class="ai-stage-choice-copy"><strong>${escapeHtml(stageMeta[stage].label)}</strong><small>${counts[stage]} image${counts[stage]===1?'':'s'} available</small></span><span class="ai-check-mark">${icon('check',13)}</span></label>`).join('')}</div>`;
  }
  function renderAiStagePreview(trades) {
    const selected=aiSelectedPhotos(trades);
    if(!selected.length)return `<div class="ai-image-empty">${icon('image',17)} No images selected for this review.</div>`;
    return `<div class="ai-image-preview-grid">${selected.slice(0,9).map(({trade,stage,photo})=>`<figure class="ai-image-preview"><img data-photo-id="${escapeAttr(photo.id)}" alt="${escapeAttr(stageMeta[stage].label)} evidence"/><figcaption><strong>${escapeHtml(stageMeta[stage].label)}</strong><span>${escapeHtml(trade.symbol)} · ${formatDate(trade.closedAt,{day:'2-digit',month:'short'})}</span></figcaption></figure>`).join('')}${selected.length>9?`<div class="ai-more-images">+${selected.length-9} more selected</div>`:''}</div>`;
  }
  function renderAiInputs(trades,mode) {
    const totalImages=aiSelectedPhotos(trades).length;const counts=aiStageCounts(trades);
    const currencyCodes=[...new Set(trades.map(aiCurrencyForTrade))];
    const mixedCurrencies=currencyCodes.length>1;
    const currencyLabel=mixedCurrencies?'Multiple currencies · totals not converted':currencyCodes[0]||journalCurrency();
    const summary=mode==='trade'?(trades[0]?`${trades[0].symbol} · ${formatDate(trades[0].closedAt,{day:'numeric',month:'short',year:'numeric'})} · ${money(trades[0].pnlUsd,false,aiCurrencyForTrade(trades[0]))}`:'No trade selected'):`${trades.length} closed record${trades.length===1?'':'s'} · Monday–Friday only`;
    let rows=[];
    if(mode==='trade'&&trades[0]){
      const t=trades[0];const plan=getPlan(t.planId);const mt4=isBrokerSource(t.source);
      rows=[
        ['Close date',formatDate(t.closedAt)],['Record source',mt4?`${brokerLabel(tradePlatform(t))} · ${t.mt4Server||'server not recorded'} · ${t.mt4Login||'login not recorded'}`:'Manual journal'],
        ['Symbol / direction',`${t.symbol||'—'} · ${aiSideGroup(t)==='long'?'Long / BUY':aiSideGroup(t)==='short'?'Short / SELL':'Direction not recorded'}`],
        ['Net P/L / result',`${money(t.pnlUsd,false,aiCurrencyForTrade(t))} · ${resultType(t)}`],
        ['Lots / ticket',mt4?`${t.lots??'—'} / ${t.mt4Ticket??'—'}`:'Not applicable'],
        ['Entry → exit price',mt4?`${t.entryPrice??'—'} → ${t.exitPrice??'—'}`:'Not recorded'],
        ['Exit reason',mt4?aiExplicitExitReason(t):'Not recorded'],
        ['Stop loss / take profit',mt4?`${t.stopLoss||'—'} / ${t.takeProfit||'—'}`:'Not recorded'],
        ['Open / close time',mt4?`${t.brokerOpenTime||t.openedAt||'—'} / ${t.brokerCloseTime||t.closedAt||'—'}`:'Not recorded'],
        ['Commission / swap',mt4?`${t.commission??'—'} / ${t.swap??'—'} ${aiCurrencyForTrade(t)}`:'Not recorded'],
        ['SOP status',t.followedSop==='yes'?'Followed':t.followedSop==='no'?'Not followed':'Not recorded'],
        ['SNR / confirmation timeframe',`${t.snrTf||'—'} / ${t.confirmTf||'—'}`],['Target / collected pips',`${t.targetPips??'—'} / ${t.collectedPips??'—'}`],
        ['Linked setup / plan',`${getSetup(t.setupId)?.name||'—'} / ${plan?.symbol||'—'}`],
        ['Plan fields sent',plan?`TF ${plan.timeframe||'—'} · entry ${plan.entry||'—'} · stop ${plan.stop||'—'} · target ${plan.target||'—'}`:'No linked plan'],
        ['Plan thesis',plan?.thesis||'—'],['Plan risk notes',plan?.riskNotes||'—'],['Review note',t.notes||'Not recorded']
      ];
    } else {
      const stats=getStats(trades);const known=trades.filter(t=>t.followedSop==='yes'||t.followedSop==='no');
      const mt4Trades=trades.filter(t=>isBrokerSource(t.source));
      const tp=mt4Trades.filter(t=>t.exitReason==='tp').length,sl=mt4Trades.filter(t=>t.exitReason==='sl').length;
      const long=trades.filter(t=>aiSideGroup(t)==='long'),short=trades.filter(t=>aiSideGroup(t)==='short');
      rows=[
        ['Week',ui.aiWeek?aiWeekLabel(ui.aiWeek):'—'],['Weekday closes',String(stats.total)],
        ['Net P/L',mixedCurrencies?'Mixed currencies · not summed':money(stats.pnl,false,currencyCodes[0]||journalCurrency())],['Currency coverage',currencyLabel],
        ['Wins / losses / breakevens',`${stats.wins} / ${stats.losses} / ${stats.breakevens}`],
        ['Win rate',stats.winRate===null?'—':`${fmtNumber(stats.winRate,1)}% (${stats.wins}/${stats.total}; BE included)`],
        ['Long / BUY · Short / SELL',`${long.length} · ${short.length}`],
        ['Broker closes · TP / SL / unclassified',`${mt4Trades.length} · ${tp} / ${sl} / ${mt4Trades.length-tp-sl}`],
        ['SOP recorded',`${known.filter(t=>t.followedSop==='yes').length} followed / ${known.filter(t=>t.followedSop==='no').length} not followed / ${trades.length-known.length} missing`],
        ['Trade records with notes',String(trades.filter(t=>String(t.notes||'').trim()).length)],['Selected stage images',String(totalImages)],
        ['Trade IDs',trades.length?trades.map(t=>t.id).join(', '):'None']
      ];
    }
    const tradeRecords=mode==='week'?`<div class="ai-input-trade-list">${trades.length?trades.map(t=>{
      const stageCounts=getStageImages(t);const note=String(t.notes||'').trim();const plan=getPlan(t.planId);const mt4=isBrokerSource(t.source);
      const reason=mt4?` · Exit: ${aiExplicitExitReason(t)}`:'';
      return `<article><div class="ai-input-record-head"><strong>${formatDate(t.closedAt,{day:'2-digit',month:'short'})} · ${escapeHtml(t.symbol)}</strong><span>${escapeHtml(money(t.pnlUsd,false,aiCurrencyForTrade(t)))} · ${escapeHtml(resultType(t))}</span></div><div class="ai-input-record-meta">${mt4?`${escapeHtml(brokerLabel(tradePlatform(t)))} · ${escapeHtml(aiSideGroup(t)||'side not recorded')} · ${escapeHtml(String(t.lots??'—'))} lot${reason} · `:''}SOP: ${t.followedSop==='yes'?'followed':t.followedSop==='no'?'not followed':'not recorded'} · TF: ${escapeHtml(t.snrTf||'—')} / ${escapeHtml(t.confirmTf||'—')} · Setup: ${escapeHtml(getSetup(t.setupId)?.name||'—')} · Plan: ${escapeHtml(plan?`${plan.symbol} ${plan.timeframe||''} entry ${plan.entry||'—'} stop ${plan.stop||'—'} target ${plan.target||'—'}`:'—')} · Images: ${Object.keys(stageMeta).map(stage=>ui.aiStages[stage]?stageCounts[stage].length:0).join('/')}</div><p>${note?`Note: ${escapeHtml(note)}`:'No review note recorded.'}</p>${plan?.thesis||plan?.riskNotes?`<p>Plan thesis/risk: ${escapeHtml([plan.thesis,plan.riskNotes].filter(Boolean).join(' · '))}</p>`:''}</article>`}).join(''):'<div class="small-muted">No weekday trades in this selected week.</div>'}</div>`:'';
    return `<details class="ai-input-details"><summary>${icon('shield',14)} Review input preview <span>${escapeHtml(summary)}</span></summary><div class="ai-input-details-body"><p>Exact selected journal fields are shown below. ${productionMode?'The optional cloud review sends these fields and selected images to the configured model only after you explicitly consent for this request.':'This local engine keeps the inputs in this browser; no model request is made.'}</p><div class="ai-input-values">${rows.map(([label,value])=>`<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}</div>${tradeRecords}<div class="ai-input-chips"><span class="chip mint">${totalImages} selected image${totalImages===1?'':'s'} · ${productionMode?'cloud request optional':'not sent'}</span><span class="chip">${trades.length} trade record${trades.length===1?'':'s'} · ${escapeHtml(currencyLabel)}</span></div><div class="ai-input-stage-line">${Object.keys(stageMeta).map(stage=>`<span>${escapeHtml(stageMeta[stage].label)}: ${ui.aiStages[stage]?counts[stage]:0} selected</span>`).join('')}</div><p class="ai-image-disclaimer">${productionMode?'Only stage images checked above are included in the optional request. They are read from private Storage by the owner-authenticated Edge Function.':'Selected image previews remain local. The offline review engine uses stage coverage only; it does not inspect image pixels.'}</p></div></details>`;
  }
  function parseAiBrokerTime(value) {
    if (!value) return null;
    const match = String(value).match(/^(\d{4})[.\/-](\d{2})[.\/-](\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
    if (match) return Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), Number(match[4]), Number(match[5]), Number(match[6] || 0));
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  function aiTradeDurationText(trade) {
    const open = parseAiBrokerTime(trade.brokerOpenTime || trade.openedAt);
    const close = parseAiBrokerTime(trade.brokerCloseTime || trade.closedAt);
    if (open === null || close === null || close < open) return 'Not recorded';
    const minutes = Math.round((close - open) / 60000);
    return minutes < 60 ? `${minutes} min` : `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
  }
  function aiExplicitExitReason(trade) {
    if (!isBrokerSource(trade?.source)) return 'not a broker record';
    return trade.exitReason === 'tp' ? 'TP · explicitly reported' : trade.exitReason === 'sl' ? 'SL · explicitly reported' : 'Unclassified · no explicit TP/SL reason';
  }
  function aiSideGroup(trade) {
    const side = String(trade?.side || '').toLowerCase();
    if (side === 'buy' || side === 'long') return 'long';
    if (side === 'sell' || side === 'short') return 'short';
    return '';
  }
  function aiPriceDistanceRatio(trade) {
    const entry = Number(trade.entryPrice);
    const stop = Number(trade.stopLoss);
    const target = Number(trade.takeProfit);
    const side = aiSideGroup(trade);
    if (![entry, stop, target].every(Number.isFinite) || entry <= 0 || stop <= 0 || target <= 0) return null;
    const geometry = side === 'long' ? stop < entry && target > entry : side === 'short' ? target < entry && stop > entry : true;
    const riskDistance = Math.abs(entry - stop);
    const rewardDistance = Math.abs(target - entry);
    if (!geometry || riskDistance <= 0 || rewardDistance <= 0) return null;
    return rewardDistance / riskDistance;
  }
  function aiCurrencyForTrade(trade) {
    const code = String(trade?.accountCurrency || journalCurrency()).toUpperCase();
    return /^[A-Z]{3}$/.test(code) ? code : journalCurrency();
  }
  function buildOfflineTradeReview(trade) {
    const photos = aiSelectedPhotos([trade]);
    const result = resultType(trade);
    const resultLabel = result === 'win' ? 'win' : result === 'loss' ? 'loss' : 'breakeven';
    const side = aiSideGroup(trade);
    const currency = aiCurrencyForTrade(trade);
    const mt4 = isBrokerSource(trade.source);
    const ratio = mt4 ? aiPriceDistanceRatio(trade) : null;
    const duration = mt4 ? aiTradeDurationText(trade) : 'Not applicable';
    const facts = [
      ['Close date', formatDate(trade.closedAt, { day: 'numeric', month: 'long', year: 'numeric' })],
      ['Source / account', mt4 ? `${brokerLabel(tradePlatform(trade))} · ${trade.mt4Server || 'server not recorded'} · ${trade.mt4Login || 'login not recorded'}` : 'Manual journal entry'],
      ['Symbol / direction', `${trade.symbol || 'Not recorded'}${side ? ` · ${side === 'long' ? 'Long / BUY' : 'Short / SELL'}` : ''}`],
      ['Net P/L', money(trade.pnlUsd, false, currency)],
      ['Outcome', resultLabel[0].toUpperCase() + resultLabel.slice(1)],
      ['Broker exit reason', mt4 ? aiExplicitExitReason(trade) : 'Not recorded'],
      ['Entry → exit', mt4 ? `${trade.entryPrice ?? '—'} → ${trade.exitPrice ?? '—'}` : 'Not recorded'],
      ['Lots / duration', mt4 ? `${trade.lots ?? '—'} · ${duration}` : 'Not recorded'],
      ['Stop loss / take profit', mt4 ? `${trade.stopLoss || '—'} / ${trade.takeProfit || '—'}` : 'Not recorded'],
      ['Price-distance reward / risk', ratio === null ? 'Not calculable from recorded levels' : `${fmtNumber(ratio, 2)} : 1 · price distance only`],
      ['SOP status', trade.followedSop === 'yes' ? 'Marked followed' : trade.followedSop === 'no' ? 'Marked not followed' : 'Not recorded'],
      ['Linked setup / plan', `${getSetup(trade.setupId)?.name || '—'} / ${getPlan(trade.planId)?.symbol || '—'}`]
    ];
    const observations = [];
    observations.push(`Recorded result: ${resultLabel} with net P/L ${money(trade.pnlUsd, false, currency)}. This is a journal fact and does not establish what caused the outcome.`);
    if (mt4 && trade.exitReason === 'tp') observations.push('Broker history explicitly reported a take-profit token. This is counted as TP only because the terminal/broker comment supplied that label; the review does not infer an exit reason from price proximity.');
    else if (mt4 && trade.exitReason === 'sl') observations.push('Broker history explicitly reported a stop-loss token. This is counted as SL only because the terminal/broker comment supplied that label; the review does not infer an exit reason from price proximity.');
    else if (mt4) observations.push('The broker did not explicitly identify TP or SL in the close metadata. The exit is kept as unclassified rather than guessed from the close price.');
    if (mt4 && duration !== 'Not recorded') observations.push(`Recorded holding duration was ${duration}, calculated from the terminal’s open and close timestamps.`);
    if (ratio !== null) observations.push(`Recorded entry, stop, and target imply a ${fmtNumber(ratio, 2)}:1 price-distance ratio. This is a geometric description only; it does not include position sizing, account-currency conversion, or slippage.`);
    if (trade.followedSop === 'no') observations.push('SOP is marked “not followed.” That is a recorded status, not evidence that it caused this trade’s outcome.');
    else if (trade.followedSop === 'yes') observations.push('SOP is marked “followed.” This is self-reported journal data; the offline engine cannot independently verify execution.');
    else observations.push('SOP adherence is not recorded, so this entry cannot support an SOP comparison.');
    if (String(trade.notes || '').trim()) observations.push(`A review note is present (${String(trade.notes).trim().length} characters). The offline engine reports its presence but does not interpret free text.`);
    else observations.push('No review note is recorded for this trade.');
    const stageCounts = aiStageCounts([trade]);
    if (photos.length) observations.push(`${photos.length} selected image${photos.length === 1 ? '' : 's'} are available across ${[...new Set(photos.map(x => x.stage))].map(stage => stageMeta[stage].label).join(', ')}. The offline engine checks stage coverage but does not analyze image pixels.`);
    else observations.push('No images are selected for this review.');
    if (mt4 && !trade.entryPrice && !trade.exitPrice) observations.push('Broker price fields are missing, so execution-price comparisons are unavailable.');
    const question = trade.followedSop === 'no'
      ? 'Which specific process step was marked as missed, and what evidence from your notes explains the context?'
      : trade.exitReason === 'unknown' && mt4
        ? 'What do you know about why this position closed, and what part is confirmed versus uncertain?'
        : 'Which recorded decision in this trade would you repeat or review, and what evidence supports that choice?';
    const experiment = 'For the next five closed records, capture the planned rule before entry and a short evidence-based note after exit; compare completion rates, not just P/L.';
    return {
      kind: 'trade', title: `${trade.symbol || 'Trade'} · evidence-first debrief`, facts, observations,
      question, experiment, tradeIds: [trade.id], imageCount: photos.length,
      analysisVersion: 'evidence-v2', source: 'offline'
    };
  }
  function buildOfflineWeekReview(trades, startKey) {
    const stats = getStats(trades);
    const observations = [];
    const currencyCodes = [...new Set(trades.map(aiCurrencyForTrade))];
    const mixedCurrencies = currencyCodes.length > 1;
    const currencyLabel = mixedCurrencies ? `Multiple currencies · not converted (${currencyCodes.join(', ')})` : currencyCodes[0] || journalCurrency();
    const facts = [
      ['Week', aiWeekLabel(startKey)], ['Closed records', String(stats.total)],
      ['Net P/L', mixedCurrencies ? 'Multiple currencies · no combined total' : money(stats.pnl, false, currencyCodes[0] || journalCurrency())],
      ['P/L currency coverage', currencyLabel],
      ['Wins / losses / breakevens', `${stats.wins} / ${stats.losses} / ${stats.breakevens}`],
      ['Win rate', stats.winRate === null ? '—' : `${fmtNumber(stats.winRate, 1)}% (${stats.wins}/${stats.total}; breakevens included)`]
    ];
    const mt4Trades = trades.filter(trade => isBrokerSource(trade.source));
    const longTrades = trades.filter(trade => aiSideGroup(trade) === 'long');
    const shortTrades = trades.filter(trade => aiSideGroup(trade) === 'short');
    const tpCount = mt4Trades.filter(trade => trade.exitReason === 'tp').length;
    const slCount = mt4Trades.filter(trade => trade.exitReason === 'sl').length;
    const unclassified = mt4Trades.length - tpCount - slCount;
    facts.push(['Long / BUY records', String(longTrades.length)]);
    facts.push(['Short / SELL records', String(shortTrades.length)]);
    facts.push(['Broker closes · TP / SL / unclassified', `${tpCount} / ${slCount} / ${unclassified}`]);
    const knownSop = trades.filter(t => t.followedSop === 'yes' || t.followedSop === 'no');
    const followed = knownSop.filter(t => t.followedSop === 'yes').length;
    const missed = knownSop.filter(t => t.followedSop === 'no').length;
    const unknownSop = trades.length - knownSop.length;
    facts.push(['SOP recorded', `${followed} followed · ${missed} not followed · ${unknownSop} unrecorded`]);
    facts.push(['Trades with review notes', String(trades.filter(t => String(t.notes || '').trim()).length)]);
    const photos = aiSelectedPhotos(trades);
    facts.push(['Selected stage images', String(photos.length)]);

    if (!trades.length) {
      observations.push('No Monday–Friday closed trades were recorded for this week. Weekend records remain in month and overall views but are excluded from this weekly window.');
    } else {
      observations.push(stats.total < 5
        ? `Small sample: ${stats.total} weekday close${stats.total === 1 ? '' : 's'}. Treat all comparisons as descriptive; this sample cannot establish a persistent pattern.`
        : `Win rate is ${fmtNumber(stats.winRate, 1)}%, calculated as ${stats.wins} wins divided by all ${stats.total} closes; breakevens remain in the denominator.`);
      if (mixedCurrencies) observations.push(`This week contains more than one account currency (${currencyCodes.join(', ')}). Individual trade P/L values are shown, but no combined net P/L comparison is valid because this report performs no currency conversion.`);
      if (longTrades.length || shortTrades.length) {
        const longStats = getStats(longTrades);
        const shortStats = getStats(shortTrades);
        observations.push(`Direction split: ${longTrades.length} Long/BUY records${mixedCurrencies ? '' : ` (${money(longStats.pnl, false, currencyCodes[0] || journalCurrency())})`} and ${shortTrades.length} Short/SELL records${mixedCurrencies ? '' : ` (${money(shortStats.pnl, false, currencyCodes[0] || journalCurrency())})`}. These are closed records, not current open positions; each broker partial close counts separately.`);
        if (longTrades.length < 5 || shortTrades.length < 5) observations.push('At least one direction has fewer than five records, so its P/L comparison is especially uncertain and should not be treated as an edge.');
      } else observations.push('Direction is not recorded for the selected trades, so no long/short comparison is available.');
      if (mt4Trades.length) observations.push(`The broker reported ${tpCount} explicit TP and ${slCount} explicit SL exits; ${unclassified} broker close${unclassified === 1 ? '' : 's'} lacked an explicit reason and were not inferred from prices.`);
      else observations.push('No broker close records are in this selected week; TP/SL exit counts therefore do not apply to these records.');
      if (knownSop.length) observations.push(`SOP was marked followed on ${followed} of ${knownSop.length} records with a recorded status; ${unknownSop} status${unknownSop === 1 ? '' : 'es'} are missing. This is descriptive, not causal.`);
      else observations.push('No trades in this week have a recorded SOP status.');
      const symbolGroups = symbolsForFilter(trades).map(symbol => ({ symbol, ...getStats(trades.filter(t => t.symbol === symbol)) })).sort((a, b) => b.pnl - a.pnl);
      if (symbolGroups.length > 1) {
        const top = symbolGroups[0];
        if (mixedCurrencies) observations.push(`${symbolGroups.length} symbols appear this week. Their combined P/L ranking is omitted because account currencies differ and no conversion is applied.`);
        else observations.push(`${top.symbol} had the highest recorded net P/L in this week (${money(top.pnl, false, currencyCodes[0] || journalCurrency())} across ${top.total} closes). This is a descriptive sample comparison, not proof of an edge.`);
      }
      const linkedTrades = trades.filter(t => t.setupId && getSetup(t.setupId));
      const setupGroups = [...new Set(linkedTrades.map(t => t.setupId))].map(id => ({ setup: getSetup(id), ...getStats(linkedTrades.filter(t => t.setupId === id)) })).sort((a, b) => b.pnl - a.pnl);
      if (setupGroups.length) {
        const top = setupGroups[0];
        if (mixedCurrencies) observations.push(`${setupGroups.length} linked playbook setups appear this week. No combined setup P/L ranking is shown because account currencies differ and are not converted.`);
        else observations.push(`Among linked playbook setups, ${top.setup.name} recorded ${money(top.pnl, false, currencyCodes[0] || journalCurrency())} across ${top.total} closes. This does not imply causation.`);
      } else observations.push('No trades this week are linked to an SNR playbook setup.');
      observations.push(`${trades.filter(t => String(t.notes || '').trim()).length} of ${trades.length} weekday close${trades.length === 1 ? '' : 's'} include a written review note. Offline analysis counts note presence but does not interpret free text.`);
      if (photos.length) observations.push(`${photos.length} selected stage image${photos.length === 1 ? ' is' : 's are'} attached. This local engine uses stage coverage only; it does not analyze image pixels.`);
      else observations.push('No stage images are selected for this review.');
    }
    return {
      kind: 'week', title: `Evidence-first week · ${formatDate(startKey, { day: 'numeric', month: 'short', year: 'numeric' })}`,
      facts, observations,
      question: trades.length ? 'Which process decision from this week has the clearest supporting evidence, and what would you verify before repeating it?' : 'What information would make your next weekly review more useful?',
      experiment: 'For the next full Monday–Friday week, log the planned rule, broker-confirmed exit reason when available, and a short post-trade note; compare documentation coverage before comparing performance.',
      tradeIds: trades.map(t => t.id), imageCount: photos.length, analysisVersion: 'evidence-v2', source: 'offline'
    };
  }
  function renderOfflineAiOutput() {
    if(!ui.aiOutput)return '';
    const out=ui.aiOutput;const isCloud=out.source==='cloud';
    return `<section class="ai-output-card"><div class="ai-output-top"><div><span class="pill ${isCloud?'mint':'amber'}">${isCloud?`Cloud AI · ${escapeHtml(out.model||'Gemini')}`:'Offline evidence engine · deterministic rules'}</span><h2>${escapeHtml(out.title)}</h2><p>${isCloud?'AI-generated reflection from the fields and images you explicitly selected. Verify against your original journal; no predictions or trade instructions are provided.':'This report was produced locally from recorded facts and deterministic comparisons. Free-text meaning and image pixels were not interpreted.'}</p></div><button class="icon-button" data-action="ai-clear-output" aria-label="Clear review">${icon('close',15)}</button></div><div class="ai-facts-grid">${(out.facts||[]).map(([label,value])=>`<div class="ai-fact"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}</div><div class="ai-output-section"><h3>${isCloud?'AI process observations':'Recorded observations'}</h3><ul>${(out.observations||[]).map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul></div><div class="ai-reflection-box"><span class="eyebrow">REFLECTION QUESTION</span><p>${escapeHtml(out.question||'')}</p></div><div class="ai-experiment-box"><span class="eyebrow">PROCESS EXPERIMENT</span><p>${escapeHtml(out.experiment||'')}</p></div>${isCloud&&out.limitations?.length?`<div class="ai-output-section"><h3>Model-stated limitations</h3><ul>${out.limitations.map(item=>`<li>${escapeHtml(item)}</li>`).join('')}</ul></div>`:''}<details class="ai-evidence-details"><summary>Evidence included · ${(out.tradeIds||[]).length} trade${(out.tradeIds||[]).length===1?'':'s'} · ${out.imageCount||0} image${out.imageCount===1?'':'s'}</summary><p>Trade IDs: ${(out.tradeIds||[]).length?out.tradeIds.map(escapeHtml).join(', '):'None'}. ${isCloud?'Selected evidence was sent to the configured cloud AI provider after your consent.':'The offline review engine did not send this data externally.'}</p></details>${isCloud?`<div class="cloud-ai-controls"><button class="secondary-button small" data-action="save-ai-review">${icon('check',14)} Save review to journal</button><span class="small-muted">Saving stores the generated reflection in your private journal snapshot.</span></div>`:''}</section>`;
  }
  function renderCloudAiAction(mode,trades) {
    const imageCount=aiSelectedPhotos(trades).length;
    const ready=Boolean(cloud&&cloud.isConfigured&&cloudReady&&isAuthenticated&&ui.aiCloudConsent&&!ui.aiRequesting&&trades.length&&trades.length<=20&&imageCount<=8);
    return `<section class="cloud-ai-consent"><div class="eyebrow">OPTIONAL CLOUD AI · GEMINI 3.8 FLASH</div><label class="cloud-consent-label"><input type="checkbox" data-ai-cloud-consent ${ui.aiCloudConsent?'checked':''} ${ui.aiRequesting?'disabled':''} /><span>I explicitly consent to send the selected ${mode==='trade'?'trade fields':'weekday trade records'}, notes, and ${imageCount} selected image${imageCount===1?'':'s'} to Google Gemini for this review.</span></label><p>Sent through the authenticated Supabase function. This is a cloud request; selected data leaves your devices for processing. No request is made unless you check this box and press the button. The app does not save the AI response unless you choose to save it.</p><div class="cloud-ai-controls"><button class="primary-button" data-action="run-cloud-ai-review" data-mode="${mode}" ${ready?'':'disabled'}>${icon('sparkle',15)} ${ui.aiRequesting?'Generating…':'Generate cloud AI review'}</button>${imageCount>8?'<span class="small-muted">Select at most eight images for one review.</span>':''}${trades.length>20?'<span class="small-muted">A cloud review accepts at most twenty selected trade records.</span>':''}</div></section>`;
  }
  function renderAIReview() {
    const trades=sortTrades(state.trades);const selectedTrade=trades.find(t=>t.id===ui.aiTradeId)||trades[0]||null;
    if(selectedTrade&&ui.aiTradeId!==selectedTrade.id)ui.aiTradeId=selectedTrade.id;
    const weeks=aiWeekOptions();if(!weeks.includes(ui.aiWeek))ui.aiWeek=weeks[0];
    const weekTrades=aiTradesForWeek(ui.aiWeek);
    const mode=ui.aiMode==='week'?'week':'trade';const reviewTrades=mode==='trade'?(selectedTrade?[selectedTrade]:[]):weekTrades;
    const empty=!trades.length;
    return `<div class="ai-review-stack">
      <section class="ai-lab-banner"><div class="ai-lab-icon">${icon('sparkle',21)}</div><div class="ai-lab-copy"><div class="inline-row"><span class="pill amber">${productionMode?'Optional cloud AI · consent required':'Local evidence review · no network'}</span><span class="small-muted">${productionMode&&cloud&&cloud.isConfigured?'Secure endpoint configured':'No AI model connected'}</span></div><h2>Evidence first. Separate recorded facts from interpretation.</h2><p>${productionMode?'The rebuilt evidence-first review combines deterministic facts with optional cloud observations. Cloud AI receives only the trades, notes, and stage images you select after separate consent.':'This local review compares recorded outcomes, direction, explicit broker exit reasons, and process fields. Notes and image pixels stay uninterpreted offline; no journal data is sent anywhere.'}</p></div>${empty?`<button class="secondary-button small" data-action="load-sample">${icon('sparkle',14)} Load fictional sample trades</button>`:''}</section>
      <div class="ai-mode-tabs"><button class="${mode==='trade'?'active':''}" data-action="ai-mode" data-mode="trade">${icon('journal',15)} Trade debrief</button><button class="${mode==='week'?'active':''}" data-action="ai-mode" data-mode="week">${icon('calendar',15)} Weekly review</button></div>
      ${mode==='trade'?`<section class="surface-card ai-review-panel"><div class="ai-panel-heading"><div><div class="eyebrow">SINGLE TRADE</div><h2>Build a trade debrief</h2><p>Choose a closed record and the stage images you want included in your review. The offline engine uses structured facts; cloud interpretation remains optional.</p></div></div>${trades.length?`<div class="ai-select-row"><label class="filter-control"><span>Trade</span><div class="select-wrap"><select data-filter="ai-trade" ${ui.aiRequesting?'disabled':''}>${trades.map(t=>`<option value="${escapeAttr(t.id)}" ${t.id===selectedTrade?.id?'selected':''}>${escapeHtml(t.symbol)} · ${formatDate(t.closedAt,{day:'2-digit',month:'short',year:'numeric'})} · ${escapeHtml(money(t.pnlUsd))}</option>`).join('')}</select></div></label><div class="ai-selected-trade-result">${selectedTrade?resultChip(selectedTrade):''}</div></div>${renderAiStageChoices(selectedTrade?[selectedTrade]:[])}${renderAiStagePreview(selectedTrade?[selectedTrade]:[])}${renderAiInputs(selectedTrade?[selectedTrade]:[],'trade')}<div class="ai-action-row"><button class="primary-button" data-action="run-ai-review" data-mode="trade" ${selectedTrade&&!ui.aiRequesting?'':'disabled'}>${icon('sparkle',15)} Build evidence-first debrief</button><span>Uses structured fields and explicit broker close metadata; offline mode does not interpret notes or image pixels.</span></div>${productionMode?renderCloudAiAction('trade',selectedTrade?[selectedTrade]:[]):''}`:`<div class="ai-empty-state"><div class="empty-visual">${icon('journal',22)}</div><h3>No closed trades yet</h3><p>Load fictional sample trades to try the review workflow. The sample data stays in this browser.</p><button class="primary-button small" data-action="load-sample">${icon('sparkle',14)} Load sample trades</button></div>`}</section>`:`<section class="surface-card ai-review-panel"><div class="ai-panel-heading"><div><div class="eyebrow">WEEKLY PROCESS REVIEW</div><h2>Review a Monday–Friday week</h2><p>Weekly totals use weekday closes only, with breakevens included in win-rate denominator.</p></div></div><div class="ai-select-row"><label class="filter-control"><span>Week</span><div class="select-wrap"><select data-filter="ai-week" ${ui.aiRequesting?'disabled':''}>${weeks.map(key=>`<option value="${key}" ${key===ui.aiWeek?'selected':''}>${escapeHtml(aiWeekLabel(key))}</option>`).join('')}</select></div></label><div class="ai-selected-trade-result"><span class="pill">${weekTrades.length} weekday close${weekTrades.length===1?'':'s'}</span></div></div>${renderAiStageChoices(weekTrades)}${renderAiStagePreview(weekTrades)}${renderAiInputs(weekTrades,'week')}<div class="ai-action-row"><button class="primary-button" data-action="run-ai-review" data-mode="week" ${ui.aiRequesting?'disabled':''}>${icon('sparkle',15)} Build weekday evidence review</button><span>Weekends stay in monthly and overall totals; they are excluded here.</span></div>${productionMode?renderCloudAiAction('week',weekTrades):''}</section>`}
      ${renderOfflineAiOutput()}
      ${renderSavedAiReviews()}
      <section class="ai-connection-grid"><article class="ai-connection-card"><span class="ai-connection-status local">LOCAL CANDIDATE</span><h3>On-device inference</h3><p>No local model is bundled. The synthetic evaluation kit is separate; test text first, then image only if practical on your Android phone and laptop. Deterministic offline summaries remain available.</p></article><article class="ai-connection-card"><span class="ai-connection-status cloud">${productionMode?'SECURE SERVER ROUTE':'CLOUD CANDIDATE'}</span><h3>Gemini · private Edge Function</h3><p>${productionMode?'Authenticated, owner-checked Supabase Edge Function. Each request needs explicit consent; selected data is sent to Google for processing.':'Not connected in this local preview. The separate evaluation kit uses synthetic fixtures only; real data requires server-side auth, RLS, and protected credentials.'}</p></article></section>
      <div class="warning-banner ai-safety-note"><strong>Safety limits.</strong> Reviews are for reflection only—not predictions, buy/sell signals, entry or exit instructions, or position sizing. Verify AI observations against the journal. Never send real journal data before the consent and security path is configured and deployed.</div>
    </div>`;
  }

  function runOfflineAiReview(mode) {
    ui.aiCloudConsent=false;
    if(mode==='trade'){
      const trade=getTrade(ui.aiTradeId)||sortTrades(state.trades)[0];if(!trade){toast('Add or load a trade first.','error');return;}
      ui.aiTradeId=trade.id;ui.aiOutput=buildOfflineTradeReview(trade);
    } else {
      const trades=aiTradesForWeek(ui.aiWeek);ui.aiOutput=buildOfflineWeekReview(trades,ui.aiWeek);
    }
    render();
  }
  async function ensureCloudImagePath(photo,trade,stage) {
    let path=photo.cloudStoragePath||remotePathFromId(photo.id)||cloudImagePathCache.get(photo.id);
    if(path){cloudImagePathCache.set(photo.id,path);return path;}
    const dataUrl=await getPhotoDataUrl(photo.id);if(!dataUrl)throw new Error(`Selected image “${photo.name||stage}” is unavailable.`);
    const blob=await normalizeImageBlobForCloud(dataUrlToBlob(dataUrl));if(blob.size>10*1024*1024)throw new Error('Selected image exceeds the 10 MB cloud limit.');
    const mime=blob.type||'image/jpeg';const safeTrade=String(trade.id||'trade').replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,100);
    path=`${cloudUser.id}/${safeTrade}/${stage}/${uid('img')}.${fileExtensionForMime(mime)}`;
    await cloud.uploadImage(path,blob,mime);photo.cloudStoragePath=path;cloudImagePathCache.set(photo.id,path);return path;
  }
  function aiTradePayload(trade) {
    const optionalNumber=value=>value===null||value===undefined||value===''?null:Number.isFinite(Number(value))?Number(value):null;
    const clip=(value,max)=>String(value||'').slice(0,max);const rawPlan=getPlan(trade.planId);const plan=rawPlan?{symbol:clip(rawPlan.symbol,30).toUpperCase(),timeframe:clip(rawPlan.timeframe,30),entry:clip(rawPlan.entry,80),stop:clip(rawPlan.stop,80),target:clip(rawPlan.target,80),thesis:clip(rawPlan.thesis,2000),riskNotes:clip(rawPlan.riskNotes,2000)}:null;
    const side=aiSideGroup(trade);
    const exitReason=isBrokerSource(trade.source)&&['tp','sl'].includes(String(trade.exitReason||'').toLowerCase())?String(trade.exitReason).toLowerCase():'unknown';
    return {
      tradeId:clip(trade.id,120),source:isBrokerSource(trade.source)?(tradePlatform(trade)||'mt4'):'manual',closedAt:clip(trade.closedAt,20),openedAt:clip(trade.openedAt,32),brokerOpenTime:clip(trade.brokerOpenTime,40),brokerCloseTime:clip(trade.brokerCloseTime,40),
      symbol:clip(trade.symbol,30).toUpperCase(),side,netPnl:optionalNumber(trade.pnlUsd),accountCurrency:aiCurrencyForTrade(trade),outcome:resultType(trade),
      lots:optionalNumber(trade.lots),mt4Ticket:clip(trade.mt4Ticket,40),mt4Login:clip(trade.mt4Login,40),mt4Server:clip(trade.mt4Server,100),
      entryPrice:optionalNumber(trade.entryPrice),exitPrice:optionalNumber(trade.exitPrice),stopLoss:optionalNumber(trade.stopLoss),takeProfit:optionalNumber(trade.takeProfit),exitReason,
      commission:optionalNumber(trade.commission),swap:optionalNumber(trade.swap),brokerProfit:optionalNumber(trade.brokerProfit),
      followedSop:trade.followedSop||'not_recorded',snrTf:clip(trade.snrTf,30),confirmTf:clip(trade.confirmTf,30),targetPips:optionalNumber(trade.targetPips),collectedPips:optionalNumber(trade.collectedPips),setup:clip(getSetup(trade.setupId)?.name,120),plan,notes:clip(trade.notes,6000)
    };
  }
  async function runCloudAiReview(mode) {
    if(!productionMode||!cloud||!cloudReady||!isAuthenticated||cloudConflict){toast('A current authenticated cloud session is required.','error');return;}
    if(!ui.aiCloudConsent){toast('Check the cloud-AI consent box before sending data.','error');return;}
    const normalizedMode=mode==='week'?'week':'trade';
    const selectedWeek=ui.aiWeek;
    const trades=normalizedMode==='trade'?[getTrade(ui.aiTradeId)].filter(Boolean):aiTradesForWeek(selectedWeek);
    if(!trades.length){toast('There are no selected closed trades to review.','error');return;}
    if(trades.length>20){toast('A cloud review accepts at most twenty selected trade records.','error');return;}
    const photos=aiSelectedPhotos(trades);if(photos.length>8){toast('Choose no more than eight images for one review.','error');return;}
    // Freeze all textual fields, metrics, and the chosen evidence before any upload/network await.
    const tradePayload=trades.map(aiTradePayload);
    const validTradeIds=new Set(tradePayload.map(t=>String(t.tradeId)));
    const base=normalizedMode==='trade'?buildOfflineTradeReview(trades[0]):buildOfflineWeekReview(trades,selectedWeek);
    const stats=getStats(trades);const known=trades.filter(t=>t.followedSop==='yes'||t.followedSop==='no');
    const currencyCodes=[...new Set(trades.map(aiCurrencyForTrade))];
    const mt4Trades=trades.filter(t=>isBrokerSource(t.source));
    const longTrades=trades.filter(t=>aiSideGroup(t)==='long');
    const shortTrades=trades.filter(t=>aiSideGroup(t)==='short');
    const mt4TpCount=mt4Trades.filter(t=>t.exitReason==='tp').length;
    const mt4SlCount=mt4Trades.filter(t=>t.exitReason==='sl').length;
    const metrics=normalizedMode==='trade'?{
      closedTradeCount:1,netPnlAmount:Number(Number(trades[0].pnlUsd||0).toFixed(2)),accountCurrency:aiCurrencyForTrade(trades[0]),outcome:resultType(trades[0]),source:isBrokerSource(trades[0].source)?(tradePlatform(trades[0])||'mt4'):'manual',side:aiSideGroup(trades[0]),exitReason:isBrokerSource(trades[0].source)&&['tp','sl'].includes(trades[0].exitReason)?trades[0].exitReason:'unknown',sopStatus:trades[0].followedSop||'not_recorded',targetPips:aiTradePayload(trades[0]).targetPips,collectedPips:aiTradePayload(trades[0]).collectedPips
    }:{
      weekdayCloseCount:stats.total,netPnlAmount:currencyCodes.length>1?null:Number(stats.pnl.toFixed(2)),accountCurrencies:currencyCodes.join(','),mixedCurrencies:currencyCodes.length>1,wins:stats.wins,losses:stats.losses,breakevens:stats.breakevens,winRatePct:stats.winRate===null?null:Number(stats.winRate.toFixed(1)),winRateDenominator:stats.total,breakevensIncludedInWinRateDenominator:true,longRecordCount:longTrades.length,shortRecordCount:shortTrades.length,mt4CloseCount:mt4Trades.length,mt4TakeProfitCount:mt4TpCount,mt4StopLossCount:mt4SlCount,mt4UnclassifiedCloseCount:mt4Trades.length-mt4TpCount-mt4SlCount,sopFollowed:known.filter(t=>t.followedSop==='yes').length,sopNotFollowed:known.filter(t=>t.followedSop==='no').length,sopNotRecorded:trades.length-known.length,notesPresent:trades.filter(t=>String(t.notes||'').trim()).length
    };
    const start=normalizedMode==='week'?selectedWeek:trades[0].closedAt;let end=start;
    if(normalizedMode==='week'){const weekEndDate=new Date(`${selectedWeek}T00:00:00`);weekEndDate.setDate(weekEndDate.getDate()+4);end=localDateString(weekEndDate);}
    const selectedWindow={start,end,rule:normalizedMode==='week'?'Monday–Friday closed records only; weekends excluded. Each partial broker close is a separate record. Win rate is wins divided by all closes, including breakevens. TP/SL counts use only explicit broker exit labels; other closes remain unclassified. Values use recorded account currency and currencies are not converted.':'One selected closed record. Values use the recorded account currency; broker TP/SL reason is explicit metadata only and must not be inferred from close-price proximity.'};
    ui.aiRequesting=true;render();
    try{
      const selectedImages=[];
      for(const entry of photos){
        const path=await ensureCloudImagePath(entry.photo,entry.trade,entry.stage);
        selectedImages.push({tradeId:String(entry.trade.id),stage:entry.stage,path,mimeType:entry.photo.type||'image/jpeg'});
      }
      if(photos.length)persistState();
      const response=await cloud.requestAI({consent:true,mode:normalizedMode,trades:tradePayload,appCalculatedMetrics:metrics,selectedWindow,selectedImages});
      let parsed;try{parsed=JSON.parse(response.reviewText);}catch(_){throw new Error('The cloud model returned an unreadable review. Your journal is unchanged.');}
      if(parsed?.financialActionAdviceGiven===true)throw new Error('The model response failed the no-financial-advice safety check and was not shown.');
      const observations=Array.isArray(parsed.observations)?parsed.observations.slice(0,10).map(item=>{
        const evidenceIds=Array.isArray(item?.evidenceTradeIds)?item.evidenceTradeIds.map(String).filter(id=>validTradeIds.has(id)):[];
        const sources=Array.isArray(item?.evidenceSources)?item.evidenceSources.map(x=>String(x).slice(0,60)).filter(Boolean):[];
        const confidence=typeof item?.confidence==='number'?` · confidence ${Math.round(Math.max(0,Math.min(1,item.confidence))*100)}%`:'';
        const evidence=evidenceIds.length||sources.length?` [Evidence: ${evidenceIds.join(', ')||'selected data'}${sources.length?`; ${sources.join(', ')}`:''}${confidence}]`:'';
        return `${String(item?.text||'').slice(0,1200)}${evidence}`;
      }).filter(Boolean):[];
      const summary=String(parsed.summary||'').slice(0,1200);if(summary)observations.unshift(`Summary: ${summary}`);
      const limitations=Array.isArray(parsed.limitations)?parsed.limitations.slice(0,4).map(x=>String(x).slice(0,300)):[];
      ui.aiOutput={...base,title:normalizedMode==='trade'?`AI trade debrief · ${trades[0].symbol}`:`AI weekly review · ${aiWeekLabel(selectedWeek)}`,facts:base.facts,observations:observations.length?observations:['The model returned no process observations.'],question:String(parsed.reflectionQuestion||base.question).slice(0,700),experiment:String(parsed.processExperiment||base.experiment).slice(0,700),source:'cloud',provider:response.provider||'Google Gemini',model:response.model||'Gemini',limitations,generatedAt:new Date().toISOString()};
      ui.aiCloudConsent=false;ui.aiRequesting=false;render();
    }catch(error){
      ui.aiCloudConsent=false;ui.aiRequesting=false;render();toast(String(error?.message||'Cloud AI request failed.'),'error');
    }
  }
  function saveCurrentAiReview() {
    if(ui.aiOutput?.source!=='cloud'){toast('Only a completed cloud review can be saved.','error');return;}
    state.aiReviews=Array.isArray(state.aiReviews)?state.aiReviews:[];
    state.aiReviews.unshift({...JSON.parse(JSON.stringify(ui.aiOutput)),id:uid('ai-review'),savedAt:new Date().toISOString()});
    state.aiReviews=state.aiReviews.slice(0,50);persistState();render();toast('AI review saved to your private journal.');
  }
  function renderSavedAiReviews() {
    const saved=(Array.isArray(state.aiReviews)?state.aiReviews:[]).filter(review=>review&&typeof review==='object');if(!saved.length)return '';
    return `<section class="surface-card saved-ai-reviews"><div class="section-title-row"><div><h2>Saved cloud reviews</h2><p>Stored in your private journal snapshot.</p></div></div><div class="saved-ai-list">${saved.slice(0,12).map(review=>`<details class="saved-ai-item"><summary><span>${escapeHtml(review.title||'AI reflection')}</span><small>${formatDate((review.savedAt||review.generatedAt||'').slice(0,10),{day:'2-digit',month:'short',year:'numeric'})}</small></summary><p>${escapeHtml((Array.isArray(review.observations)?review.observations:[]).slice(0,2).join(' '))}</p><p><strong>Reflection:</strong> ${escapeHtml(review.question||'—')}</p><button class="text-button danger-text" data-action="delete-saved-ai-review" data-id="${escapeAttr(review.id)}">Delete saved review</button></details>`).join('')}</div></section>`;
  }
  function deleteSavedAiReview(id) {
    state.aiReviews=(state.aiReviews||[]).filter(review=>review.id!==id);persistState();render();toast('Saved review deleted.');
  }

  function renderTools() {
    return `<div class="calc-grid"><section class="surface-card" style="padding:20px"><div class="section-title-row" style="margin:0 0 16px"><div><h2>Position size planner</h2><p>Amount to risk ÷ SL pips ÷ 10 — your standard lot rule.</p></div><span class="setup-symbol">${icon('calculator',17)}</span></div><form id="calculator-form"><div class="form-grid"><div class="form-field"><label for="calc-risk-input">Amount to risk · ${journalCurrency()}</label><input id="calc-risk-input" type="number" min="0" step="0.01" placeholder="e.g. 100" /></div><div class="form-field"><label for="calc-sl-pips">Stop loss · pips</label><input id="calc-sl-pips" type="number" min="0" step="any" placeholder="e.g. 60" /><div class="form-help">Example: ${escapeHtml(journalCurrency())}100 risk on a 60-pip stop → 100 ÷ 60 ÷ 10 = 0.16 lots.</div></div></div></form></section><section class="surface-card calc-results" style="padding:20px"><div><div class="eyebrow">ESTIMATE</div><h2 style="font-size:17px;margin:6px 0 15px">Potential size</h2></div><div class="calc-result"><span>Amount at risk</span><strong id="calc-risk-amount">—</strong></div><div class="calc-result"><span>Stop distance</span><strong id="calc-distance">—</strong></div><div class="calc-result"><span>Estimated lots</span><strong id="calc-lots">—</strong></div><p class="small-muted" style="margin:0">This is a planning calculator, not an order ticket or financial advice.</p></section></div>
      <div class="section-title-row"><div><h2>Daily risk controls</h2><p>Optional dashboard reminders based on your recorded closes.</p></div><button class="text-button" data-action="navigate" data-view="settings">Configure limits ${icon('chevronRight',13)}</button></div><section class="surface-card" style="padding:18px"><div class="two-column"><div class="metric-mini"><div class="label">Daily loss limit</div><div class="value">${Number(state.settings.dailyLossLimit||0)>0?money(state.settings.dailyLossLimit):'Not set'}</div><div class="helper">Current limit is visible on Performance when configured.</div></div><div class="metric-mini"><div class="label">Maximum trades / day</div><div class="value">${Number(state.settings.maxDailyTrades||0)>0?state.settings.maxDailyTrades:'Not set'}</div><div class="helper">These controls are reminders only; they do not connect to a broker.</div></div></div></section>
      <div class="warning-banner" style="margin-top:14px">The planner uses your fixed rule: amount to risk ÷ SL pips ÷ 10, rounded down to 2 decimals. Pip value can differ by broker and instrument — verify before trading.</div>`;
  }
  function updateCalculator() {
    const amount = Number(document.getElementById('calc-risk-input')?.value || 0);
    const slPips = Number(document.getElementById('calc-sl-pips')?.value || 0);
    const lots = amount > 0 && slPips > 0 ? Math.floor((amount / slPips / 10) * 100) / 100 : null;
    const riskNode=document.getElementById('calc-risk-amount');const distNode=document.getElementById('calc-distance');const lotsNode=document.getElementById('calc-lots');
    if(riskNode)riskNode.textContent=amount>0?money(amount):'—';
    if(distNode)distNode.textContent=slPips>0?`${fmtNumber(slPips,2)} pips`:'—';
    if(lotsNode)lotsNode.textContent=lots!==null?`${fmtNumber(lots,2)} lots`:'—';
  }
  function importLocalMt4Trades(rawTrades) {
    if (!localMt4Mode || !Array.isArray(rawTrades)) return 0;
    let previouslyImported = [];
    try {
      const parsed = JSON.parse(localStorage.getItem(LOCAL_MT4_IMPORTED_KEY) || '[]');
      if (Array.isArray(parsed)) previouslyImported = parsed.map(String);
    } catch (_) {}

    const known = new Set([
      ...previouslyImported,
      ...(state.trades || []).map(trade => String(trade.sourceEventId || '')).filter(Boolean),
      ...Object.values(journals).flatMap(journal => (journal?.trades || []).map(trade => String(trade.sourceEventId || ''))).filter(Boolean)
    ]);
    const candidates = rawTrades.filter(trade => trade && trade.sourceEventId && !known.has(String(trade.sourceEventId)));
    if (!candidates.length) return 0;

    const groups = new Map();
    for (const trade of candidates) {
      const platform = String(trade.platform || trade.source || 'mt4').toLowerCase() === 'mt5' ? 'mt5' : 'mt4';
      let login = String(trade.mt4Login || '');
      let server = String(trade.mt4Server || '');
      if ((!login || !server) && mt4Accounts.length === 1) {
        login = login || mt4Accounts[0].account_login;
        server = server || mt4Accounts[0].account_server;
      }
      if ((!login || !server) && activeAccountKey !== MANUAL_JOURNAL_KEY) {
        const parts = journalKeyParts(activeAccountKey);
        if (parts) { login = login || parts.login; server = server || parts.server; }
      }
      const key = login && server ? accountJournalKey(platform, login, server) : activeAccountKey;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push({ ...trade, platform, source: platform });
    }

    const recorded = [];
    let imported = 0;
    for (const [key, rows] of groups) {
      const currencies = new Set(rows.map(trade => String(trade.accountCurrency || '').toUpperCase()).filter(Boolean));
      const isActive = key === activeAccountKey;
      const journalState = isActive ? state : (journals[key] || defaultState());
      const currentCurrency = String(journalState.settings.accountCurrency || '').trim().toUpperCase();
      if (currencies.size > 1) {
        mt4EventsError = 'Local test contains more than one account currency; refusing to mix trade results.';
        continue;
      }
      const importCurrency = [...currencies][0] || '';
      if (currentCurrency && importCurrency && currentCurrency !== importCurrency) {
        mt4EventsError = `${brokerLabel(rows[0]?.platform)} account currency ${importCurrency} does not match the ${key === MANUAL_JOURNAL_KEY ? 'manual' : key} journal's ${currentCurrency} currency; no close rows were imported.`;
        continue;
      }

      const additions = rows.map(trade => ({
        ...trade,
        id: String(trade.id || uid('mt4')),
        sourceEventId: String(trade.sourceEventId),
        isDemo: false
      }));
      if (isActive) {
        const previousState = state;
        const settings = { ...state.settings };
        if (!currentCurrency && importCurrency) settings.accountCurrency = importCurrency;
        state = { ...state, settings, trades: [...(state.trades || []), ...additions] };
        if (!persistState()) {
          state = previousState;
          mt4EventsError = 'Could not save imported demo closes to this browser. Export a backup or free local storage, then retry.';
          continue;
        }
      } else {
        const settings = { ...journalState.settings };
        if (!currentCurrency && importCurrency) settings.accountCurrency = importCurrency;
        const previousJournal = journals[key];
        journals[key] = { ...journalState, settings, trades: [...(journalState.trades || []), ...additions] };
        if (!saveJournalStore()) {
          if (previousJournal) journals[key] = previousJournal; else delete journals[key];
          mt4EventsError = 'Could not save imported demo closes for the non-active account. Export a backup or free local storage, then retry.';
          continue;
        }
      }
      recorded.push(...additions.map(trade => trade.sourceEventId));
      imported += additions.length;
    }

    if (recorded.length) {
      try {
        const merged = [...previouslyImported, ...recorded].slice(-2000);
        localStorage.setItem(LOCAL_MT4_IMPORTED_KEY, JSON.stringify(merged));
      } catch (_) {}
    }
    return imported;
  }

  function normalizeMt4DashboardRow(row) {
    if (!row || typeof row !== 'object') return null;
    const optionalNumber = value => value === null || value === undefined || value === '' ? null : Number.isFinite(Number(value)) ? Number(value) : null;
    const platform = String(row.platform || row.source || 'mt4').toLowerCase() === 'mt5' ? 'mt5' : 'mt4';
    const login = String(row.account_login || row.login || '');
    const server = String(row.account_server || row.server || '');
    if (!login || !server) return null;
    return {
      platform,
      account_key: accountJournalKey(platform, login, server),
      account_login: login,
      account_server: server,
      account_currency: String(row.account_currency || row.currency || state.settings.accountCurrency || 'USD'),
      balance: optionalNumber(row.balance),
      equity: optionalNumber(row.equity),
      floating_pl: optionalNumber(row.floating_pl),
      margin: optionalNumber(row.margin),
      free_margin: optionalNumber(row.free_margin),
      leverage: optionalNumber(row.leverage),
      last_event_id: String(row.last_event_id || row.event_id || ''),
      observed_at: String(row.observed_at || ''),
      updated_at: String(row.updated_at || row.received_at || ''),
      event_count: optionalNumber(row.event_count),
      trade_close_count: optionalNumber(row.trade_close_count),
      long_close_count: optionalNumber(row.long_close_count),
      short_close_count: optionalNumber(row.short_close_count),
      take_profit_count: optionalNumber(row.take_profit_count),
      stop_loss_count: optionalNumber(row.stop_loss_count),
      unclassified_close_count: optionalNumber(row.unclassified_close_count)
    };
  }

  function applyMt4DashboardRows(rows) {
    mt4Accounts = (Array.isArray(rows) ? rows : []).map(normalizeMt4DashboardRow).filter(Boolean);
    syncActiveAccountSnapshot();
  }

  function activityEventFilters() {
    const scope = mt4ActivityScopeRows();
    if (!scope.length || scope.length > 1) return {};
    const parts = journalKeyParts(scope[0].account_key);
    return parts ? { platform: parts.platform, login: parts.login, server: parts.server } : {};
  }

  function canRenderMt4Update() {
    if (ui.modal || ui.aiRequesting || ui.aiCloudConsent) return false;
    const active = document.activeElement;
    return !active?.matches?.('input, textarea, select, [contenteditable="true"]');
  }

  async function loadMt4AccountEvents({ renderAfter = true, notify = false, includeEvents = ui.view === 'mt4-activity' } = {}) {
    if (mt4EventsLoading) return;
    if (!localMt4Mode && (!cloudUser || !cloud || typeof cloud.loadMt4AccountDashboard !== 'function')) {
      mt4EventsError = productionMode ? '' : 'Broker activity appears only in the production cloud app.';
      mt4DashboardError = productionMode ? 'Apply the account dashboard migration and deploy the account-snapshot RPC.' : '';
      mt4AccountEvents = [];
      mt4Accounts = [];
      mt4AccountSnapshot = null;
      if (renderAfter) render();
      return;
    }
    mt4EventsLoading = true;
    updateLocalMt4RefreshStatus();
    try {
      if (localMt4Mode) {
        const response = await fetch('/__local_mt4/events', { cache: 'no-store' });
        if (!response.ok) throw new Error(`Local feed returned HTTP ${response.status}.`);
        const snapshot = await response.json();
        const events = Array.isArray(snapshot.events) ? snapshot.events : [];
        const closeRows = Array.isArray(snapshot.trades) ? snapshot.trades : [];
        const countOrFallback = (value, fallback) => value === undefined || value === null || !Number.isFinite(Number(value)) ? fallback : Math.max(0, Number(value));
        const accountRows = Array.isArray(snapshot.account_snapshots) && snapshot.account_snapshots.length
          ? snapshot.account_snapshots
          : (snapshot.account_snapshot ? [snapshot.account_snapshot] : []);
        applyMt4DashboardRows(accountRows);
        maybeAutoActivateSingleAccountJournal();
        const scopeRows = mt4ActivityScopeRows();
        const narrowed = scopeRows.length < mt4Accounts.length;
        if (narrowed) {
          mt4AccountStats = mt4RowsStats(scopeRows);
        } else {
          mt4AccountStats = {
            eventCount: countOrFallback(snapshot.event_count, events.length),
            tradeCloseCount: countOrFallback(snapshot.trade_close_count, closeRows.length),
            longCloseCount: countOrFallback(snapshot.long_close_count, closeRows.filter(trade => trade.side === 'buy').length),
            shortCloseCount: countOrFallback(snapshot.short_close_count, closeRows.filter(trade => trade.side === 'sell').length),
            takeProfitCount: countOrFallback(snapshot.take_profit_count, closeRows.filter(trade => trade.exitReason === 'tp').length),
            stopLossCount: countOrFallback(snapshot.stop_loss_count, closeRows.filter(trade => trade.exitReason === 'sl').length),
            unclassifiedCloseCount: countOrFallback(snapshot.unclassified_close_count, closeRows.filter(trade => !['tp', 'sl'].includes(trade.exitReason)).length)
          };
        }
        mt4AccountEvents = events.map(event => {
          const account = event.account || {};
          const order = event.order || {};
          return {
            event_id: event.event_id,
            event_type: event.event_type,
            platform: String(event.platform || account.platform || 'mt4').toLowerCase() === 'mt5' ? 'mt5' : 'mt4',
            account_login: account.login || '',
            account_server: account.server || '',
            account_currency: account.currency || 'USD',
            ticket: order.ticket,
            symbol: order.symbol || '',
            broker_time: event.broker_time || '',
            received_at: event.observed_time || '',
            payload: { order }
          };
        });
        mt4EventsError = '';
        mt4DashboardError = '';
        localMt4FeedConnected = true;
        localMt4LastSuccessAt = Date.now();
        importLocalMt4Trades(snapshot.trades);
      } else {
        const dashboardPromise = cloud.loadMt4AccountDashboard()
          .then(data => ({ data, error: '' }))
          .catch(error => ({ data: null, error: String(error?.message || 'Account dashboard could not be loaded.').slice(0, 180) }));
        const eventsPromise = includeEvents && typeof cloud.loadMt4Events === 'function'
          ? cloud.loadMt4Events(200, activityEventFilters()).then(data => ({ data: Array.isArray(data) ? data : [], error: '' }))
              .catch(error => ({ data: null, error: String(error?.message || 'Broker activity could not be loaded.').slice(0, 180) }))
          : Promise.resolve({ data: null, error: '' });
        const [dashboardResult, eventsResult] = await Promise.all([dashboardPromise, eventsPromise]);
        if (!dashboardResult.error) {
          const rows = Array.isArray(dashboardResult.data) ? dashboardResult.data : (dashboardResult.data ? [dashboardResult.data] : []);
          applyMt4DashboardRows(rows);
          maybeAutoActivateSingleAccountJournal();
          mt4AccountStats = mt4RowsStats(mt4ActivityScopeRows());
          mt4AccountStats.eventCount = 0;
          mt4DashboardError = '';
          localMt4FeedConnected = true;
        } else {
          mt4DashboardError = dashboardResult.error;
          localMt4FeedConnected = false;
        }
        if (includeEvents) {
          if (eventsResult.error) mt4EventsError = eventsResult.error;
          else { mt4AccountEvents = eventsResult.data; mt4EventsError = ''; }
        }
        if (!dashboardResult.error || (includeEvents && typeof cloud.loadMt4Events === 'function' && !eventsResult.error)) localMt4LastSuccessAt = Date.now();
      }
    } catch (error) {
      localMt4FeedConnected = false;
      mt4DashboardError = localMt4Mode
        ? `Could not read the loopback feed (${String(error?.message || 'request failed').slice(0, 160)}). Keep the port-80 MT4 test server and local Vite app running.`
        : String(error?.message || 'Account dashboard could not be loaded.').slice(0, 180);
      if (includeEvents) mt4EventsError = mt4DashboardError;
    } finally {
      mt4EventsLoading = false;
      updateLocalMt4RefreshStatus();
    }

    updateMt4AccountStrip();
    const signature = JSON.stringify({
      stats: mt4AccountStats,
      accounts: mt4Accounts.map(row => [row.account_key, row.balance, row.equity, row.floating_pl, row.account_currency, row.updated_at]),
      snapshot: mt4AccountSnapshot ? [mt4AccountSnapshot.balance, mt4AccountSnapshot.equity, mt4AccountSnapshot.floating_pl, mt4AccountSnapshot.account_currency, mt4AccountSnapshot.account_login, mt4AccountSnapshot.account_server] : null,
      eventIds: includeEvents ? mt4AccountEvents.map(event => event.event_id) : [],
      errors: [mt4EventsError, mt4DashboardError]
    });
    const changed = signature !== localMt4FeedSignature;
    localMt4FeedSignature = signature;
    if (changed) pendingMt4Render = true;
    if (notify) toast(mt4EventsError || mt4DashboardError ? 'Account data could not be refreshed.' : 'Account data refreshed.', mt4EventsError || mt4DashboardError ? 'error' : 'success');
    if (renderAfter && pendingMt4Render && canRenderMt4Update()) {
      pendingMt4Render = false;
      render();
    }
  }

  function localMt4RefreshStatusText() {
    const lastSuccess = localMt4LastSuccessAt
      ? new Date(localMt4LastSuccessAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      : '';
    if (mt4EventsLoading) return localMt4FeedConnected ? `Refreshing · last success ${lastSuccess}` : 'Connecting to broker feed…';
    if (localMt4FeedConnected) return `Connected · updated ${lastSuccess} · auto-refresh ${localMt4Mode ? 'instant' : '1s'}`;
    if (lastSuccess) return `Offline · last success ${lastSuccess} · retrying`;
    return mt4DashboardError || mt4EventsError ? `Feed unavailable · retrying every ${localMt4Mode ? 'moment' : 'second'}` : 'Waiting for an account snapshot…';
  }

  function updateLocalMt4RefreshStatus() {
    const status = document.querySelector('[data-local-mt4-refresh-status]');
    if (!status) return;
    status.textContent = localMt4RefreshStatusText();
    status.dataset.state = mt4EventsLoading && !localMt4FeedConnected ? 'checking' : localMt4FeedConnected ? 'online' : 'offline';
  }

  function stopLocalMt4RefreshLoop() {
    mt4SnapshotChainActive = false;
    if (mt4RefreshTimer) window.clearInterval(mt4RefreshTimer);
    mt4RefreshTimer = null;
  }

  async function fetchMt4Snapshot() {
    const response = await fetch('/__local_mt4/snapshot', { cache: 'no-store' });
    if (response.ok) return response.json();
    if (response.status !== 404) throw new Error(`Snapshot feed returned HTTP ${response.status}.`);
    const full = await fetch('/__local_mt4/events', { cache: 'no-store' });
    if (!full.ok) throw new Error(`Feed returned HTTP ${full.status}.`);
    const data = await full.json();
    return {
      account_snapshot: data.account_snapshot,
      account_snapshots: data.account_snapshots,
      event_count: data.event_count,
      trade_close_count: data.trade_close_count,
      long_close_count: data.long_close_count,
      short_close_count: data.short_close_count,
      take_profit_count: data.take_profit_count,
      stop_loss_count: data.stop_loss_count,
      unclassified_close_count: data.unclassified_close_count
    };
  }

  function applyMt4SnapshotData(data) {
    const rows = Array.isArray(data.account_snapshots) && data.account_snapshots.length
      ? data.account_snapshots
      : (data.account_snapshot ? [data.account_snapshot] : []);
    const normalized = rows.map(normalizeMt4DashboardRow).filter(Boolean);
    const signature = normalized.map(row => [row.account_key, row.balance, row.equity, row.floating_pl, row.updated_at]).join('|');
    const currentSignature = mt4Accounts.map(row => [row.account_key, row.balance, row.equity, row.floating_pl, row.updated_at].map(v => v ?? '').join(',')).join('|');
    if (signature && signature !== currentSignature) {
      applyMt4DashboardRows(rows);
      maybeAutoActivateSingleAccountJournal();
    } else if (!normalized.length) {
      mt4AccountSnapshot = null;
    }
    const count = (v) => Math.max(0, Number(v) || 0);
    const scopeRows = mt4ActivityScopeRows();
    const narrowed = scopeRows.length && scopeRows.length < mt4Accounts.length;
    mt4AccountStats = narrowed
      ? mt4RowsStats(scopeRows)
      : {
          eventCount: count(data.event_count),
          tradeCloseCount: count(data.trade_close_count),
          longCloseCount: count(data.long_close_count),
          shortCloseCount: count(data.short_close_count),
          takeProfitCount: count(data.take_profit_count),
          stopLossCount: count(data.stop_loss_count),
          unclassifiedCloseCount: count(data.unclassified_close_count)
        };
    localMt4FeedConnected = true;
    localMt4LastSuccessAt = Date.now();
    mt4DashboardError = '';
  }

  function detectLocalMt4Bridge() {
    if (localMt4Mode || productionMode || typeof fetch !== 'function') return Promise.resolve(false);
    return fetch('/__local_mt4/health', { cache: 'no-store' })
      .then(response => {
        const type = String(response?.headers?.get?.('content-type') || '');
        return response && response.ok && type.includes('application/json') ? response.json() : null;
      })
      .then(payload => {
        if (!payload || payload.service !== 'nketiah-mt4-local-test') return false;
        localMt4Mode = true;
        if (isAuthenticated) {
          loadMt4AccountEvents({ renderAfter: false, includeEvents: false });
          startLocalMt4RefreshLoop();
          render();
        }
        return true;
      })
      .catch(() => false);
  }

  function startLocalMt4RefreshLoop() {
    stopLocalMt4RefreshLoop();
    if (!isAuthenticated || (!localMt4Mode && !productionMode)) return;
    mt4SnapshotChainActive = true;
    if (localMt4Mode) {
      const chain = async () => {
        if (!mt4SnapshotChainActive) return;
        if (document.visibilityState === 'visible' && isAuthenticated && !mt4EventsLoading) {
          try {
            applyMt4SnapshotData(await fetchMt4Snapshot());
            updateMt4AccountStripValues();
            updateLocalMt4RefreshStatus();
          } catch (error) {
            localMt4FeedConnected = false;
            mt4DashboardError = String(error?.message || 'request failed').slice(0, 160);
          }
        }
        await new Promise(r => setTimeout(r, 0));
        if (mt4SnapshotChainActive) chain();
      };
      chain();
    }
    const fullInterval = localMt4Mode ? 2000 : 1000;
    mt4RefreshTimer = window.setInterval(() => {
      if (document.visibilityState !== 'visible' || mt4EventsLoading || !isAuthenticated) return;
      loadMt4AccountEvents({ renderAfter: true, notify: false, includeEvents: ui.view === 'mt4-activity' });
    }, fullInterval);
  }

  function mt4EventLabel(type) {
    const labels = {
      terminal_online: 'Terminal connected', order_baseline: 'Open order at setup', order_opened: 'Order opened',
      pending_order_placed: 'Pending order placed', pending_order_activated: 'Pending order activated',
      order_modified: 'Order changed', pending_order_cancelled: 'Pending order cancelled',
      trade_closed: 'Trade close', balance_adjustment: 'Balance adjustment'
    };
    return labels[type] || String(type || 'Broker event').replaceAll('_', ' ');
  }

  const hiddenMt4ActivityTypes = new Set([
    'order_baseline', 'order_opened', 'pending_order_placed', 'pending_order_activated', 'pending_order_cancelled',
    'terminal_online', 'order_modified', 'balance_adjustment'
  ]);

  function renderMt4Activity() {
    if (!productionMode && !localMt4Mode) return `<div class="warning-banner"><strong>Broker activity is a production feature.</strong> To test locally, open the browser-only preview with <code>?mt4Local=1</code> while the loopback test bridge is running.</div>`;
    const localNotice = localMt4Mode ? `<div class="info-banner local-mt4-notice" style="display:none"><strong>Local-only MT4 test.</strong> The CMS refreshes account data instantly while visible, including on other views. Only trade closes are shown in this feed; connection, order open/change, and balance events stay logged but are hidden here. Closed rows are added to this browser's preview journal only; nothing is sent to Supabase.<div class="mt4-feed-status" data-local-mt4-refresh-status data-state="${mt4EventsLoading && !localMt4FeedConnected ? 'checking' : localMt4FeedConnected ? 'online' : 'offline'}" aria-live="polite">${escapeHtml(localMt4RefreshStatusText())}</div></div>` : '';
    const scopeRows = mt4ActivityScopeRows();
    const scopeKeys = new Set(scopeRows.map(row => row.account_key).filter(Boolean));
    const narrowed = ui.mt4ActivityAccount !== 'all' && scopeKeys.size > 0 && scopeKeys.size < Math.max(mt4Accounts.length, 1);
    const activityEvents = mt4AccountEvents.filter(event => !hiddenMt4ActivityTypes.has(event.event_type))
      .filter(event => !narrowed || scopeKeys.has(mt4EventAccountKey(event)));
    const rows = activityEvents.map(event => {
      const payload = event.payload || {};
      const order = payload.order || {};
      const balanceEvent = event.event_type === 'balance_adjustment';
      const closeEvent = event.event_type === 'trade_closed';
      const amount = balanceEvent ? order.balance_amount : order.net_profit;
      const amountMarkup = Number.isFinite(Number(amount)) && (balanceEvent || closeEvent)
        ? `<strong class="amount ${pnlClass(amount)}">${escapeHtml(money(amount, false, event.account_currency || 'USD'))}</strong>` : '';
      const side = order.side ? `${String(order.side).toUpperCase()} · ` : '';
      const size = Number(order.lots) > 0 ? `${fmtNumber(order.lots, 3)} lot${Number(order.lots) === 1 ? '' : 's'} · ` : '';
      const exitReason = order.close_reason === 'tp' ? 'TP · broker-confirmed' : order.close_reason === 'sl' ? 'SL · broker-confirmed' : 'Exit reason not reported';
      const execution = closeEvent
        ? `${escapeHtml(side)}${escapeHtml(size)}${escapeHtml(order.open_price ?? '—')} → ${escapeHtml(order.close_price ?? '—')} · ${escapeHtml(exitReason)} · open ${escapeHtml(order.open_time || '—')} · close ${escapeHtml(order.close_time || event.broker_time || '—')}`
        : balanceEvent
          ? `Balance entry · ${escapeHtml(order.comment || order.type || 'broker adjustment')} · ${escapeHtml(event.account_currency || '')}`
          : `${escapeHtml(order.symbol || 'Account-wide')} ${order.ticket ? `· ticket ${escapeHtml(order.ticket)}` : ''}${order.stop_loss || order.take_profit ? ` · SL ${escapeHtml(order.stop_loss || '—')} / TP ${escapeHtml(order.take_profit || '—')}` : ''}${order.comment ? ` · ${escapeHtml(order.comment)}` : ''}`;
      const accountHint = `${event.account_server || ''}${event.account_login ? ` · account ${event.account_login}` : ''}`;
      return `<article class="surface-card mt4-event-row"><div class="mt4-event-main"><div><div class="eyebrow">${escapeHtml(mt4EventLabel(event.event_type))}</div><h3>${escapeHtml(order.symbol || (balanceEvent ? 'Account balance' : `${brokerLabel(event.platform)} terminal`))}</h3><p>${execution}</p><small>${escapeHtml(event.broker_time || event.received_at || 'Time unavailable')} · ${escapeHtml(accountHint)}</small></div>${amountMarkup}</div></article>`;
    }).join('');
    const accountFilter = mt4Accounts.length > 1 ? `<label class="filter-control"><span>Account</span><div class="select-wrap"><select data-filter="mt4-account"><option value="active" ${ui.mt4ActivityAccount === 'active' ? 'selected' : ''}>Active journal${activeAccountKey !== MANUAL_JOURNAL_KEY ? '' : ' (all accounts)'}</option><option value="all" ${ui.mt4ActivityAccount === 'all' ? 'selected' : ''}>All connected accounts</option>${journalEntries().filter(entry => entry.key !== MANUAL_JOURNAL_KEY).map(entry => `<option value="${escapeAttr(entry.key)}" ${ui.mt4ActivityAccount === entry.key ? 'selected' : ''}>${escapeHtml(entry.label)}${entry.sub ? ` · ${escapeHtml(entry.sub)}` : ''}</option>`).join('')}</select></div></label>` : '';
    const activityStats = (localMt4Mode || productionMode) ? `<div class="stats-grid mt4-outcome-grid" style="margin:14px 0">
      ${metricCard('CLOSED TRADE RECORDS', String(mt4AccountStats.tradeCloseCount), 'Each partial close counts separately.', 'journal')}
      ${metricCard('LONG · BUY', String(mt4AccountStats.longCloseCount), 'Closed BUY records', 'trend')}
      ${metricCard('SHORT · SELL', String(mt4AccountStats.shortCloseCount), 'Closed SELL records', 'trendDown')}
      ${localMt4Mode ? metricCard('EVENTS LOGGED', String(mt4AccountStats.eventCount), 'Includes ticket events hidden below.', 'bolt') : ''}
    </div>` : '';
    const feedErrorHelp = localMt4Mode
      ? ' Confirm the local mock is running on 127.0.0.1:80 and this preview was started with npm run dev:mt4-local.'
      : ' Apply the account ingest database migration and deploy the secure ingest function before expecting live events.';
    const emptyText = localMt4Mode && mt4AccountStats.eventCount > 0
      ? 'The raw log has events, but none are visible in this feed yet. Only trade-close rows are shown; all other event types stay logged but hidden.'
      : 'Once the publisher is connected, closed trades will appear here. Other event types stay logged but are hidden from this feed.';
    return `<section class="mt4-activity-page">${localNotice}${activityStats}<div class="surface-card mt4-activity-intro"><div><div class="eyebrow">ACCOUNT ACTIVITY FEED</div><h2>Trade and account activity</h2><p>Closed trades also appear in your Trade Journal. Partial closes are separate trade records; deposits, withdrawals, credits, adjustments, and other non-close events stay logged but are hidden from this feed.</p></div><div class="inline-row">${accountFilter}<button class="secondary-button small" data-action="mt4-refresh" ${mt4EventsLoading ? 'disabled' : ''}>${icon('upload',14)} ${mt4EventsLoading ? 'Refreshing…' : localMt4Mode ? 'Refresh now' : 'Refresh feed'}</button></div></div>${mt4DashboardError ? `<div class="warning-banner mt4-activity-error"><strong>Account snapshot not ready.</strong> ${escapeHtml(mt4DashboardError)}${feedErrorHelp}</div>` : ''}${mt4EventsError ? `<div class="warning-banner mt4-activity-error"><strong>Activity feed not ready.</strong> ${escapeHtml(mt4EventsError)}${feedErrorHelp}</div>` : ''}${rows ? `<div class="mt4-event-list">${rows}</div>` : `<div class="surface-card mt4-activity-empty"><div class="empty-state"><div class="empty-visual">${icon('bolt',24)}</div><h3>${mt4EventsLoading ? 'Loading account activity…' : 'No visible activity yet'}</h3><p>${mt4EventsLoading ? 'Checking the local or private activity feed.' : emptyText}</p></div></div>`}<p class="small-muted mt4-activity-footnote">Coverage depends on the terminal being connected and its Account History being loaded. If the terminal was offline, intermediate order changes may not be recoverable.</p>${mt4AccountActivityFooter()}</section>`;
  }
  function mt4AccountActivityFooter() {
    const identity = mt4AccountIdentity();
    if (!identity) return '';
    const detail = [identity.label, identity.name, identity.login ? `login ${identity.login}` : ''].filter(Boolean).join(' · ');
    return `<div class="mt4-activity-footer" data-mt4-account-identity aria-label="Connected MetaTrader account"><span class="dot"></span><strong>${escapeHtml(detail)}</strong></div>`;
  }

  function renderSettings() {
    return `<div class="settings-layout"><nav class="settings-nav"><button class="active" type="button">Account & risk</button><button type="button" data-action="settings-accounts">Connected accounts</button><button type="button" data-action="settings-export">Data & export</button><button type="button" data-action="settings-privacy">Privacy & sync</button></nav><div>
      <section class="surface-card settings-panel"><h2>Account & risk preferences</h2><p>Used for local performance estimates and optional daily reminders.</p><form id="settings-form"><div class="settings-row"><div><strong>Starting balance · ${journalCurrency()}</strong><span>Enables a P/L-only equity estimate. Deposits, withdrawals, and open trades are not modeled.</span></div><input class="input-control" type="number" name="startingBalance" min="0" step="0.01" value="${escapeAttr(state.settings.startingBalance||'')}" placeholder="e.g. 5000" /></div><div class="settings-row"><div><strong>Daily loss limit · ${journalCurrency()}</strong><span>Show a progress indicator using today’s logged closed-trade P/L.</span></div><input class="input-control" type="number" name="dailyLossLimit" min="0" step="0.01" value="${escapeAttr(state.settings.dailyLossLimit||'')}" placeholder="Off" /></div><div class="settings-row"><div><strong>Maximum trades per day</strong><span>Optional reminder on the Performance dashboard.</span></div><input class="input-control" type="number" name="maxDailyTrades" min="0" step="1" value="${escapeAttr(state.settings.maxDailyTrades||'')}" placeholder="Off" /></div><div class="settings-row"><div><strong>Weekly profit goal · ${journalCurrency()}</strong><span>Powers the Weekly goal tab: pace, runway, milestones, and week history (Monday–Friday closes).</span></div><input class="input-control" type="number" name="weeklyGoal" min="0" step="0.01" value="${escapeAttr(state.settings.weeklyGoal||'')}" placeholder="Off" /></div><div class="settings-row"><div><strong>Timezone</strong><span>Used for local date presentation and future time-based analytics.</span></div><input class="input-control" type="text" name="timezone" value="${escapeAttr(state.settings.timezone||'UTC')}" readonly title="Detected from this device" /></div><div class="inline-row" style="justify-content:flex-end;padding-top:15px"><button class="primary-button small" type="submit">Save preferences</button></div></form></section>
      ${renderConnectedAccountsPanel()}
      <section class="surface-card settings-panel" id="settings-export" style="margin-top:15px"><h2>Data & backup</h2><p>${productionMode?'Your production journal syncs to Supabase. Download a portable JSON backup regularly; exports contain private journal information.':'For this prototype, your journal is stored in this browser. Export regularly before clearing browser data.'}</p><div class="settings-row"><div><strong>Download CSV</strong><span>Spreadsheet-friendly trade records. Image binaries are not included in CSV.</span></div><button class="secondary-button small" data-action="export-csv">${icon('download',14)} Export CSV</button></div><div class="settings-row"><div><strong>Download JSON backup</strong><span>Includes trade, setup, plan, and image data where browser storage permits.</span></div><button class="secondary-button small" data-action="export-json">${icon('download',14)} Export JSON</button></div><div class="settings-row"><div><strong>Print performance report</strong><span>Open your browser’s print dialog to save a simple report as PDF.</span></div><button class="secondary-button small" data-action="print-report">${icon('file',14)} Save as PDF</button></div><div class="settings-row"><div><strong>Import CSV / JSON</strong><span>Imports deduplicate matching close date, symbol, and P/L values.</span></div><button class="secondary-button small" data-action="trigger-import">${icon('upload',14)} Import file</button></div><input id="import-file" type="file" accept=".csv,.json,application/json,text/csv" class="hidden-input" /></section>
      <section class="surface-card settings-panel" id="settings-privacy" style="margin-top:15px"><h2>Privacy & sync</h2><p>${productionMode?'Owner-only Supabase session, private image storage, and revision-checked journal sync.':'Preview status and production setup notes.'}</p>${productionMode?`<div class="info-banner"><strong>Production security path.</strong> Google OAuth is checked against the configured owner email in the client; database RLS, private Storage policies, and the AI function’s owner-ID check must also be configured on the server. Browser sign-in alone is not the security boundary.</div><div class="settings-row"><div><strong>Owner account</strong><span>${escapeHtml(cloudUser?.email||'No active owner session')}</span></div><span class="pill mint">${cloudUser?'Google session':'Signed out'}</span></div><div class="settings-row"><div><strong>Cloud journal</strong><span>${escapeHtml(cloudSyncError||'Snapshot revisions prevent silent overwrite from another device.')}</span></div><span class="pill ${cloudSyncStatus==='synced'?'mint':cloudSyncStatus==='conflict'||cloudSyncStatus==='error'?'amber':''}">${cloudSyncStatus==='synced'?'Synced':cloudSyncStatus==='conflict'?'Conflict':cloudSyncStatus==='error'?'Error':cloudSyncStatus==='syncing'?'Syncing':cloudSyncStatus==='pending'?'Queued':'Loading'}</span></div>${cloudSyncStatus==='error'&&!cloudConflict?`<div class="settings-row"><div><strong>Retry cloud sync</strong><span>${escapeHtml(cloudSyncError||'Your most recent sync failed.')}</span></div><button class="secondary-button small" data-action="cloud-retry-sync">${icon('upload',14)} Retry sync</button></div>`:''}${cloudConflict?`<div class="settings-row"><div><strong>Resolve sync conflict</strong><span>Reload the latest cloud snapshot. Current browser state is first retained in a local backup.</span></div><button class="secondary-button small" data-action="cloud-reload">${icon('chevronRight',14)} Reload cloud</button></div>`:''}${localStorage.getItem(CLOUD_BACKUP_KEY)?`<div class="settings-row"><div><strong>Pre-cloud local backup</strong><span>A copy of this browser’s data was retained before cloud initialization.</span></div><button class="secondary-button small" data-action="export-cloud-backup">${icon('download',14)} Download backup</button></div>`:''}<div class="settings-row"><div><strong>Sign out</strong><span>End the Supabase session on this device.</span></div><button class="secondary-button small" data-action="logout">${icon('logout',14)} Sign out</button></div><div class="settings-row"><div><strong>Clear this private journal</strong><span>Remove journal data and synced images. Download a JSON backup first.</span></div><button class="danger-button small" data-action="clear-all">${icon('trash',14)} Clear journal</button></div>`:`<div class="warning-banner"><strong>Local preview only.</strong> This screen uses a client-side preview gate; trade data and images are saved in this browser. It is not production authentication or a cloud backup.</div><div class="settings-row"><div><strong>Preview login</strong><span>Demo credentials are supplied only by index.html and are not a secure authentication system.</span></div><span class="pill mint">Active in preview</span></div><div class="settings-row"><div><strong>Cloud sync</strong><span>Production setup uses Supabase Auth, RLS, and private image storage.</span></div><span class="pill amber">Not configured</span></div><div class="settings-row"><div><strong>Sign out</strong><span>End this browser-tab preview session.</span></div><button class="secondary-button small" data-action="logout">${icon('logout',14)} Sign out</button></div><div class="settings-row"><div><strong>Clear this browser’s journal</strong><span>Remove local trades, setups, plans, and settings. Export a backup first.</span></div><button class="danger-button small" data-action="clear-all">${icon('trash',14)} Clear local data</button></div>`}</section>
    </div></div>`;
  }

  function renderStageGallery(trade, stage) {
    const existing = getStageImages(trade)[stage].filter(item => !ui.removedPhotoIds.has(item.id));
    const pending = ui.pendingPhotos[stage] || [];
    const existingMarkup = existing.map(item => `<div class="stage-photo-item"><img data-photo-id="${escapeAttr(item.id)}" alt="${escapeAttr(stageMeta[stage].label)} screenshot"/><button type="button" class="photo-remove" data-action="remove-stage-photo" data-stage="${stage}" data-photo-id="${escapeAttr(item.id)}" aria-label="Remove image">${icon('close',12)}</button><span title="${escapeAttr(item.name||'Chart image')}">${escapeHtml(item.name||'Chart image')}</span></div>`).join('');
    const pendingMarkup = pending.map(item => `<div class="stage-photo-item pending"><img src="${escapeAttr(item.url)}" alt="${escapeAttr(item.file.name)} preview"/><button type="button" class="photo-remove" data-action="remove-stage-photo" data-stage="${stage}" data-temp-id="${escapeAttr(item.tempId)}" aria-label="Remove image">${icon('close',12)}</button><span title="${escapeAttr(item.file.name)}">${escapeHtml(item.file.name)}</span></div>`).join('');
    return existingMarkup || pendingMarkup ? `${existingMarkup}${pendingMarkup}` : `<div class="stage-empty">No ${stage==='before'?'pre-trade':stage==='during'?'in-trade':'post-trade'} images yet</div>`;
  }
  function renderStageUpload(trade, stage) {
    const meta=stageMeta[stage];
    const count=getStageImages(trade)[stage].filter(item=>!ui.removedPhotoIds.has(item.id)).length+(ui.pendingPhotos[stage]?.length||0);
    return `<section class="stage-upload-card" data-stage="${stage}"><div class="stage-upload-head"><span class="stage-icon">${icon(meta.icon,16)}</span><div><div class="stage-title-row"><h3>${meta.label}</h3><span class="stage-count" data-stage-count="${stage}">${count} image${count===1?'':'s'}</span></div><p>${meta.subtitle}</p></div></div><label class="stage-dropzone"><span class="drop-icon">${icon('image',17)}</span><span class="drop-copy"><strong>Add ${stage==='before'?'before-trade':stage==='during'?'in-trade':'after-trade'} screenshots</strong><small>Select multiple images · PNG, JPG or WebP · up to 10 MB each</small></span><input type="file" accept="image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp" data-photo-stage="${stage}" multiple /></label><div class="stage-gallery" data-stage-gallery="${stage}">${renderStageGallery(trade,stage)}</div></section>`;
  }
  function refreshStageGallery(stage) {
    const form=document.getElementById('trade-form');
    const trade=form?.dataset.id?getTrade(form.dataset.id):null;
    const gallery=modalRoot.querySelector(`[data-stage-gallery="${stage}"]`);
    if(!gallery)return;
    gallery.innerHTML=renderStageGallery(trade,stage);
    const countNode=modalRoot.querySelector(`[data-stage-count="${stage}"]`);
    const count=getStageImages(trade)[stage].filter(item=>!ui.removedPhotoIds.has(item.id)).length+(ui.pendingPhotos[stage]?.length||0);
    if(countNode)countNode.textContent=`${count} image${count===1?'':'s'}`;
    hydrateImages(gallery);
  }
  function renderTradeModal(trade = null) {
    ui.pendingPhotos = { before: [], during: [], after: [] };
    ui.pendingPhotoUrls = new Map();
    ui.removedPhotoIds = new Set();
    const editing = !!trade;
    const p = trade || {};
    const setupOptions = state.setups.map(s=>`<option value="${escapeAttr(s.id)}" ${p.setupId===s.id?'selected':''}>${escapeHtml(s.name)}</option>`).join('');
    const planOptions = state.plans.filter(x=>!x.tradeId||x.tradeId===p.id).map(x=>`<option value="${escapeAttr(x.id)}" ${p.planId===x.id?'selected':''}>${escapeHtml(x.symbol||'Plan')} · ${escapeHtml(x.status)}</option>`).join('');
    const stageUploads = Object.keys(stageMeta).map(stage=>renderStageUpload(p,stage)).join('');
    openModal(`<form id="trade-form" data-id="${escapeAttr(p.id||'')}"><div class="modal-header"><div><div class="eyebrow">CLOSED POSITION</div><h2>${editing?'Edit trade':'Add trade'}</h2><p>Record the outcome and keep chart evidence in sequence.</p></div><button type="button" class="icon-button" data-action="close-modal" aria-label="Close">${icon('close',17)}</button></div><div class="modal-body"><div class="form-grid">
      <div class="form-field"><label for="trade-date">Close date</label><input id="trade-date" name="closedAt" type="date" value="${escapeAttr(p.closedAt||today)}" required /></div>
      <div class="form-field"><label for="trade-symbol">Symbol</label><input id="trade-symbol" name="symbol" type="text" value="${escapeAttr(p.symbol||'')}" placeholder="e.g. XAUUSD" autocomplete="off" required /></div>
      <div class="form-field"><label for="trade-pnl">Net profit / loss · ${journalCurrency()}</label><input id="trade-pnl" name="pnlUsd" type="number" step="0.01" value="${p.pnlUsd===undefined?'':escapeAttr(p.pnlUsd)}" placeholder="e.g. 50 or -20" required /><div class="form-help">After commission & swap. Zero = breakeven.</div></div>
      <div class="form-field"><label for="trade-sop">Followed SOP?</label><select id="trade-sop" name="followedSop"><option value="" ${!p.followedSop?'selected':''}>Not recorded</option><option value="yes" ${p.followedSop==='yes'?'selected':''}>Yes — followed</option><option value="no" ${p.followedSop==='no'?'selected':''}>No — deviated</option></select></div>
      <div class="form-field"><label for="trade-snr">SNR zone timeframe</label><select id="trade-snr" name="snrTf">${timeframeOptions(p.snrTf)}</select></div>
      <div class="form-field"><label for="trade-confirm">Confirmation timeframe</label><select id="trade-confirm" name="confirmTf">${timeframeOptions(p.confirmTf)}</select></div>
      <div class="form-field"><label for="trade-target-pips">Target pips <span class="optional">optional</span></label><input id="trade-target-pips" name="targetPips" type="number" step="0.1" value="${p.targetPips==null?'':escapeAttr(p.targetPips)}" placeholder="e.g. 100" /></div>
      <div class="form-field"><label for="trade-collected-pips">Collected pips <span class="optional">optional</span></label><input id="trade-collected-pips" name="collectedPips" type="number" step="0.1" value="${p.collectedPips==null?'':escapeAttr(p.collectedPips)}" placeholder="e.g. 65 or -20" /></div>
      <div class="form-field"><label for="trade-setup">SNR setup <span class="optional">optional</span></label><select id="trade-setup" name="setupId"><option value="">Not linked</option>${setupOptions}</select></div>
      <div class="form-field"><label for="trade-plan">Trade plan <span class="optional">optional</span></label><select id="trade-plan" name="planId"><option value="">Not linked</option>${planOptions}</select></div>
      <div class="form-field full"><label for="trade-notes">Setup / review notes <span class="optional">optional</span></label><textarea id="trade-notes" name="notes" placeholder="What happened? Why did you enter or close? What went well, and what can you improve?">${escapeHtml(p.notes||'')}</textarea></div>
      <div class="modal-section-title">Trade images <span class="optional">optional</span></div><div class="modal-section-help">Add one or more screenshots at each stage. Each image is stored with its phase so you can compare your plan, execution, and outcome.</div>
      <div class="form-field full"><div class="stage-upload-list">${stageUploads}</div></div>
      <div class="warning-banner form-field full">Manual entries represent a closed position. Partial exits from the broker are separate records. Exclude deposits and withdrawals; enter the net result in ${journalCurrency()}. </div>
    </div></div><div class="modal-footer"><button type="button" class="secondary-button" data-action="close-modal">Cancel</button><button type="submit" class="primary-button">${icon('check',15)} ${editing?'Save changes':'Save trade'}</button></div></form>`, 'wide');
    hydrateImages(modalRoot);
  }
  function timeframeOptions(selected='') {
    const options=['M1','M5','M15','M30','H1','H2','H4','D1','W1','MN1'];
    return `<option value="" ${!selected?'selected':''}>Not recorded</option>${options.map(x=>`<option value="${x}" ${selected===x?'selected':''}>${x}</option>`).join('')}`;
  }
  function openModal(html, size = '') { ui.modal = true; modalRoot.innerHTML = `<div class="modal-backdrop"><section class="modal-panel ${size==='wide'?'wide':size==='small'?'small-modal':''}" role="dialog" aria-modal="true">${html}</section></div>`; document.body.style.overflow='hidden'; hydrateImages(modalRoot); }
  function closeModal() {
    ui.modal=false;
    modalRoot.innerHTML='';
    document.body.style.overflow='';
    for(const url of ui.pendingPhotoUrls.values()) URL.revokeObjectURL(url);
    ui.pendingPhotoUrls=new Map();
    ui.pendingPhotos={before:[],during:[],after:[]};
    ui.removedPhotoIds=new Set();
  }

  function renderTradeDetail(trade) {
    if(!trade)return;
    const setup=getSetup(trade.setupId);const plan=getPlan(trade.planId);
    const stages=getStageImages(trade);
    const stats=resultType(trade);
    const evidence=Object.keys(stageMeta).map(stage=>{
      const photos=stages[stage];const meta=stageMeta[stage];
      return `<section class="detail-stage-section"><div class="detail-stage-head"><div><span class="stage-icon">${icon(meta.icon,15)}</span><strong>${meta.label}</strong></div><span class="stage-count">${photos.length} image${photos.length===1?'':'s'}</span></div>${photos.length?`<div class="detail-stage-gallery">${photos.map(photo=>`<figure class="detail-stage-photo"><img data-photo-id="${escapeAttr(photo.id)}" alt="${escapeAttr(meta.label)} screenshot"/><figcaption>${escapeHtml(photo.name||'Chart image')}</figcaption></figure>`).join('')}</div>`:`<div class="detail-stage-empty">No ${stage==='before'?'pre-trade':stage==='during'?'in-trade':'post-trade'} images attached.</div>`}</section>`;
    }).join('');
    openModal(`<div class="modal-header"><div><div class="eyebrow">${escapeHtml(trade.symbol)} · ${formatDate(trade.closedAt,{day:'numeric',month:'long',year:'numeric'})}</div><h2>Trade review</h2><p>${stats==='win'?'Positive close':stats==='loss'?'Negative close':'Breakeven close'} · ${escapeHtml(trade.followedSop==='yes'?'SOP followed':trade.followedSop==='no'?'SOP not followed':'SOP not recorded')}</p></div><button class="icon-button" data-action="close-modal" aria-label="Close">${icon('close',17)}</button></div><div class="modal-body"><div class="detail-grid"><div class="detail-item"><span>Net P/L · ${journalCurrency()}</span><strong class="amount ${pnlClass(trade.pnlUsd)}">${money(trade.pnlUsd)}</strong></div>${isBrokerSource(trade.source)?`<div class="detail-item"><span>${escapeHtml(brokerLabel(tradePlatform(trade)))} open → close</span><strong>${escapeHtml(trade.openedAt||'—')} → ${escapeHtml(trade.brokerCloseTime||trade.closedAt||'—')}</strong></div><div class="detail-item"><span>Side / lots / ticket</span><strong>${escapeHtml(String(trade.side||'—').toUpperCase())} / ${escapeHtml(trade.lots??'—')} / ${escapeHtml(trade.mt4Ticket||'—')}</strong></div><div class="detail-item"><span>Entry → exit</span><strong>${escapeHtml(trade.entryPrice??'—')} → ${escapeHtml(trade.exitPrice??'—')}</strong></div><div class="detail-item"><span>Commission / swap</span><strong>${escapeHtml(money(Number(trade.commission||0)+Number(trade.swap||0)))}</strong></div>`:''}<div class="detail-item"><span>Result</span><strong>${resultChip(trade)}</strong></div><div class="detail-item"><span>Followed SOP?</span><strong>${trade.followedSop==='yes'?'Yes':trade.followedSop==='no'?'No':'Not recorded'}</strong></div><div class="detail-item"><span>SNR / confirmation</span><strong>${escapeHtml(trade.snrTf||'—')} / ${escapeHtml(trade.confirmTf||'—')}</strong></div><div class="detail-item"><span>Target / collected pips</span><strong>${trade.targetPips??'—'} / ${trade.collectedPips??'—'}</strong></div><div class="detail-item"><span>Linked setup / plan</span><strong>${escapeHtml(setup?.name||'—')} / ${escapeHtml(plan?.symbol||'—')}</strong></div></div>${trade.notes?`<div class="detail-notes">${escapeHtml(trade.notes)}</div>`:''}<div class="section-title-row"><div><h2>Trade evidence</h2><p>Review the visual story from setup to outcome.</p></div></div><div class="trade-evidence-board">${evidence}</div></div><div class="modal-footer"><button class="danger-button" data-action="delete-trade" data-id="${escapeAttr(trade.id)}">${icon('trash',14)} Delete</button><button class="secondary-button" data-action="close-modal">Close</button><button class="secondary-button" data-action="review-trade-ai" data-id="${escapeAttr(trade.id)}">${icon('sparkle',14)} Review</button><button class="primary-button" data-action="edit-trade" data-id="${escapeAttr(trade.id)}">${icon('edit',14)} Edit trade</button></div>`, 'wide');
  }
  function renderSetupModal(setup=null) {
    const s=setup||{};
    openModal(`<form id="setup-form" data-id="${escapeAttr(s.id||'')}"><div class="modal-header"><div><div class="eyebrow">SNR PLAYBOOK</div><h2>${setup?'Edit setup':'Add SNR setup'}</h2><p>Define the idea you want to recognize and repeat.</p></div><button type="button" class="icon-button" data-action="close-modal">${icon('close',17)}</button></div><div class="modal-body"><div class="form-grid"><div class="form-field full"><label for="setup-name">Setup name</label><input id="setup-name" name="name" value="${escapeAttr(s.name||'')}" placeholder="e.g. SNR rejection" required /></div><div class="form-field full"><label for="setup-description">Short description</label><textarea id="setup-description" name="description" placeholder="What market condition does this setup look for?">${escapeHtml(s.description||'')}</textarea></div><div class="form-field full"><label for="setup-trigger">Entry trigger / confirmation</label><textarea id="setup-trigger" name="entryTrigger" placeholder="What must happen before you enter?">${escapeHtml(s.entryTrigger||'')}</textarea></div><div class="form-field"><label for="setup-timeframes">Preferred timeframes</label><input id="setup-timeframes" name="timeframes" value="${escapeAttr(s.timeframes||'')}" placeholder="e.g. H1, M15" /></div><div class="form-field"><label for="setup-symbols">Preferred symbols</label><input id="setup-symbols" name="symbols" value="${escapeAttr(s.symbols||'')}" placeholder="e.g. XAUUSD, EURUSD" /></div><div class="form-field full"><label for="setup-invalidation">Invalidation / exit rules</label><textarea id="setup-invalidation" name="invalidation" placeholder="What proves the setup is no longer valid?">${escapeHtml(s.invalidation||'')}</textarea></div><div class="form-field full"><label for="setup-notes">Process notes</label><textarea id="setup-notes" name="notes" placeholder="Rules, common mistakes, or review prompts">${escapeHtml(s.notes||'')}</textarea></div></div></div><div class="modal-footer"><button type="button" class="secondary-button" data-action="close-modal">Cancel</button><button type="submit" class="primary-button">${icon('check',15)} Save setup</button></div></form>`,'wide');
  }
  function renderSetupDetail(setup) {
    if(!setup)return;
    const trades=sortTrades(state.trades.filter(t=>t.setupId===setup.id));const stats=getStats(trades);
    openModal(`<div class="modal-header"><div><div class="eyebrow">SNR PLAYBOOK · ${stats.total} LINKED TRADES</div><h2>${escapeHtml(setup.name)}</h2><p>${escapeHtml(setup.description||'A documented trading setup.')}</p></div><button class="icon-button" data-action="close-modal">${icon('close',17)}</button></div><div class="modal-body"><div class="three-column"><div class="metric-mini"><div class="label">Net P/L</div><div class="value amount ${pnlClass(stats.pnl)}">${money(stats.pnl)}</div></div><div class="metric-mini"><div class="label">Win rate</div><div class="value">${stats.winRate===null?'—':`${fmtNumber(stats.winRate,1)}%`}</div><div class="helper">Breakevens are in denominator</div></div><div class="metric-mini"><div class="label">Wins / loss / BE</div><div class="value">${stats.wins} / ${stats.losses} / ${stats.breakevens}</div></div></div><div class="detail-notes" style="margin-top:14px"><strong>Entry trigger</strong><br>${escapeHtml(setup.entryTrigger||'Not recorded')}<br><br><strong>Invalidation / exit</strong><br>${escapeHtml(setup.invalidation||'Not recorded')}<br><br><strong>Process notes</strong><br>${escapeHtml(setup.notes||'Not recorded')}</div><div class="section-title-row"><h2>Linked trades</h2></div>${renderTradeTable(trades,{compact:true})}</div><div class="modal-footer"><button class="secondary-button" data-action="edit-setup" data-id="${escapeAttr(setup.id)}">${icon('edit',14)} Edit setup</button><button class="primary-button" data-action="new-trade-setup" data-id="${escapeAttr(setup.id)}">${icon('plus',14)} Log trade</button></div>`,'wide');
  }
  function renderPlanModal(plan=null) {
    const p=plan||{};
    openModal(`<form id="plan-form" data-id="${escapeAttr(p.id||'')}"><div class="modal-header"><div><div class="eyebrow">PRE-TRADE PLAN</div><h2>${plan?'Edit plan':'New trade plan'}</h2><p>Record your thesis and levels before the outcome is known.</p></div><button type="button" class="icon-button" data-action="close-modal">${icon('close',17)}</button></div><div class="modal-body"><div class="form-grid"><div class="form-field"><label for="plan-symbol">Symbol</label><input id="plan-symbol" name="symbol" value="${escapeAttr(p.symbol||'')}" placeholder="e.g. XAUUSD" required /></div><div class="form-field"><label for="plan-timeframe">Timeframe</label><select id="plan-timeframe" name="timeframe">${timeframeOptions(p.timeframe)}</select></div><div class="form-field"><label for="plan-entry">Planned entry</label><input id="plan-entry" name="entry" type="number" step="any" value="${escapeAttr(p.entry||'')}" placeholder="Price or zone" /></div><div class="form-field"><label for="plan-stop">Stop / invalidation</label><input id="plan-stop" name="stop" type="number" step="any" value="${escapeAttr(p.stop||'')}" placeholder="Planned stop level" /></div><div class="form-field"><label for="plan-target">Target</label><input id="plan-target" name="target" type="number" step="any" value="${escapeAttr(p.target||'')}" placeholder="Planned target" /></div><div class="form-field"><label for="plan-status">Plan status</label><select id="plan-status" name="status"><option value="pending" ${!p.status||p.status==='pending'?'selected':''}>Pending</option><option value="executed" ${p.status==='executed'?'selected':''}>Executed</option><option value="missed" ${p.status==='missed'?'selected':''}>Missed</option><option value="cancelled" ${p.status==='cancelled'?'selected':''}>Cancelled</option></select></div><div class="form-field full"><label for="plan-thesis">Thesis / context</label><textarea id="plan-thesis" name="thesis" placeholder="Why does this setup interest you? What needs to happen?">${escapeHtml(p.thesis||'')}</textarea></div><div class="form-field full"><label for="plan-risk">Planned risk or R:R notes</label><textarea id="plan-risk" name="riskNotes" placeholder="What is the risk and what would invalidate the idea?">${escapeHtml(p.riskNotes||'')}</textarea></div></div></div><div class="modal-footer"><button type="button" class="secondary-button" data-action="close-modal">Cancel</button><button type="submit" class="primary-button">${icon('check',15)} Save plan</button></div></form>`,'wide');
  }

  function renderConfirm(title, message, action, id, dangerous=true) {
    openModal(`<div class="modal-header"><div><div class="eyebrow">CONFIRM ACTION</div><h2>${escapeHtml(title)}</h2><p>${escapeHtml(message)}</p></div><button class="icon-button" data-action="close-modal">${icon('close',17)}</button></div><div class="modal-body"><div class="warning-banner">This action can’t be undone in this browser preview. Export your journal backup first if you need a copy.</div></div><div class="modal-footer"><button class="secondary-button" data-action="close-modal">Cancel</button><button class="${dangerous?'danger-button':'primary-button'}" data-action="confirm-${action}" data-id="${escapeAttr(id||'')}">${icon('trash',14)} Confirm</button></div>`,'small');
  }
  function renderDayModal(date) {
    const trades=sortTrades(state.trades.filter(t=>t.closedAt===date&&(ui.calendarSymbol==='all'||t.symbol===ui.calendarSymbol)));
    const stats=getStats(trades);
    openModal(`<div class="modal-header"><div><div class="eyebrow">DAY REVIEW</div><h2>${formatDate(date,{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</h2><p><span class="amount ${pnlClass(stats.pnl)}">${money(stats.pnl)}</span> · ${stats.total} closed trade${stats.total===1?'':'s'}</p></div><button class="icon-button" data-action="close-modal">${icon('close',17)}</button></div><div class="modal-body">${trades.length?renderTradeTable(trades,{compact:true}):'<div class="table-empty">No closed trades on this day.</div>'}</div><div class="modal-footer"><button class="secondary-button" data-action="close-modal">Close</button><button class="primary-button" data-action="new-trade-date" data-date="${escapeAttr(date)}">${icon('plus',14)} Add trade on this date</button></div>`,'wide');
  }

  function selectedFileValid(file) {
    if (!file) return 'Choose an image file.';
    const allowed = ['image/png','image/jpeg','image/webp'];
    if (!allowed.includes(file.type)) return 'Use a PNG, JPG, or WebP image.';
    if (file.size > 10*1024*1024) return 'Each chart image must be 10 MB or smaller.';
    return '';
  }

  async function handleTradeSubmit(form) {
    const fd=new FormData(form);const id=form.dataset.id;const existing=id?getTrade(id):null;
    const symbol=String(fd.get('symbol')||'').trim().toUpperCase();const closedAt=String(fd.get('closedAt')||'');const pnl=Number(fd.get('pnlUsd'));
    if(!symbol||!closedAt||!Number.isFinite(pnl)){toast('Add a close date, symbol, and numeric P/L.','error');return;}
    for(const files of Object.values(ui.pendingPhotos))for(const item of files){const error=selectedFileValid(item.file);if(error){toast(error,'error');return;}}
    const previous=getStageImages(existing);const stages={before:[],during:[],after:[]};const savedNow=[];
    try {
      for(const stage of Object.keys(stages)){
        for(const photo of previous[stage]){
          if(!ui.removedPhotoIds.has(photo.id))stages[stage].push(photo);
        }
        for(const item of (ui.pendingPhotos[stage]||[])){
          const saved=await savePhoto(item.file);savedNow.push(saved.id);stages[stage].push({id:saved.id,name:saved.name||item.file.name,type:saved.type||item.file.type});
        }
      }
    } catch(err){for(const photoId of savedNow)await deletePhoto(photoId);console.warn(err);toast('Could not store an image. Please try a smaller file.','error');return;}
    const now=new Date().toISOString();
    const trade={
      id:existing?.id||uid('trade'), createdAt:existing?.createdAt||now, updatedAt:now,
      closedAt, symbol, pnlUsd:Number(pnl.toFixed(2)), followedSop:String(fd.get('followedSop')||''),
      snrTf:String(fd.get('snrTf')||''), confirmTf:String(fd.get('confirmTf')||''),
      targetPips:fd.get('targetPips')===''?null:Number(fd.get('targetPips')),
      collectedPips:fd.get('collectedPips')===''?null:Number(fd.get('collectedPips')),
      setupId:String(fd.get('setupId')||''), planId:String(fd.get('planId')||''),
      notes:String(fd.get('notes')||'').trim(), stages,
      isDemo:false
    };
    const retainedIds=new Set(getAllPhotoIds(trade));
    for(const oldId of getAllPhotoIds(existing))if(!retainedIds.has(oldId))await deletePhoto(oldId);
    const oldPlan=existing?.planId?getPlan(existing.planId):null;
    if(existing)state.trades=state.trades.map(t=>t.id===existing.id?trade:t);else state.trades.push(trade);
    if(oldPlan&&oldPlan.id!==trade.planId&&oldPlan.tradeId===trade.id){oldPlan.tradeId='';oldPlan.status='pending';}
    const linkedPlan=trade.planId?getPlan(trade.planId):null;
    if(linkedPlan){linkedPlan.tradeId=trade.id;linkedPlan.status='executed';}
    state.sampleWorkspace=state.trades.some(t=>t.isDemo);
    persistState();closeModal();render();toast(existing?'Trade updated.':'Trade saved.');
  }
  function handleSetupSubmit(form) {
    const fd=new FormData(form);const id=form.dataset.id;const name=String(fd.get('name')||'').trim();if(!name){toast('Give this setup a name.','error');return;}
    const setup={id:id||uid('setup'),name,description:String(fd.get('description')||'').trim(),entryTrigger:String(fd.get('entryTrigger')||'').trim(),timeframes:String(fd.get('timeframes')||'').trim(),symbols:String(fd.get('symbols')||'').trim(),invalidation:String(fd.get('invalidation')||'').trim(),notes:String(fd.get('notes')||'').trim(),updatedAt:new Date().toISOString(),isDemo:false};
    if(id)state.setups=state.setups.map(s=>s.id===id?{...s,...setup}:s);else state.setups.push({...setup,createdAt:new Date().toISOString()});
    persistState();closeModal();render();toast(id?'Setup updated.':'SNR setup added.');
  }
  function handlePlanSubmit(form) {
    const fd=new FormData(form);const id=form.dataset.id;const symbol=String(fd.get('symbol')||'').trim().toUpperCase();if(!symbol){toast('Add a symbol for this plan.','error');return;}
    const plan={id:id||uid('plan'),symbol,timeframe:String(fd.get('timeframe')||''),entry:String(fd.get('entry')||''),stop:String(fd.get('stop')||''),target:String(fd.get('target')||''),status:String(fd.get('status')||'pending'),thesis:String(fd.get('thesis')||'').trim(),riskNotes:String(fd.get('riskNotes')||'').trim(),updatedAt:new Date().toISOString(),createdAt:id?getPlan(id)?.createdAt:new Date().toISOString(),tradeId:id?getPlan(id)?.tradeId||'':'' ,isDemo:false};
    if(id)state.plans=state.plans.map(p=>p.id===id?plan:p);else state.plans.push(plan);
    persistState();closeModal();render();toast(id?'Plan updated.':'Trade plan saved.');
  }
  function handleSettingsSubmit(form) {
    const fd=new FormData(form);
    state.settings={...state.settings,startingBalance:fd.get('startingBalance')||'',dailyLossLimit:fd.get('dailyLossLimit')||'',maxDailyTrades:fd.get('maxDailyTrades')||'',weeklyGoal:fd.get('weeklyGoal')||'',timezone:state.settings.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC'};
    persistState();render();toast('Preferences saved.');
  }

  function csvEscape(value) { const s=String(value??'');return /[",\n\r]/.test(s)?`"${s.replace(/"/g,'""')}"`:s; }
  function download(content, filename, type) {
    const blob=content instanceof Blob?content:new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
  function exportCsv() {
    const headers=['closed_at','symbol',`net_pnl_${journalCurrency().toLowerCase()}`,'result','followed_sop','snr_timeframe','confirmation_timeframe','target_pips','collected_pips','setup_name','notes','before_trade_images','during_trade_images','after_trade_images'];
    const rows=state.trades.map(t=>{const stages=getStageImages(t);return [t.closedAt,t.symbol,t.pnlUsd,resultType(t),t.followedSop,t.snrTf,t.confirmTf,t.targetPips,t.collectedPips,getSetup(t.setupId)?.name||'',t.notes,...['before','during','after'].map(stage=>stages[stage].map(photo=>photo.name||'image').join(' | '))];});
    download([headers,...rows].map(row=>row.map(csvEscape).join(',')).join('\r\n'),`nketiah-journal-trades-${today}.csv`,'text/csv;charset=utf-8');toast('CSV export downloaded.');
  }
  async function exportStateBackup(source,filename,message) {
    toast('Preparing complete JSON backup…');
    const backup={app:'Nketiah Journal',version:3,exportedAt:new Date().toISOString(),settings:source.settings||{},trades:[],setups:source.setups||[],plans:source.plans||[],aiReviews:source.aiReviews||[]};
    for(const trade of source.trades||[])for(const list of Object.values(getStageImages(trade)))for(const photo of list){const path=photo.cloudStoragePath||remotePathFromId(photo.id);if(path)cloudImagePathCache.set(photo.id,path);}
    for(const t of source.trades||[]){
      const copy={...t,stages:{before:[],during:[],after:[]}};delete copy.images;
      for(const stage of Object.keys(copy.stages))for(const photo of getStageImages(t)[stage]){
        const dataUrl=await getPhotoDataUrl(photo.id);
        copy.stages[stage].push(dataUrl?{dataUrl,name:photo.name||`${stage}.image`,type:photo.type||''}:{id:photo.id,name:photo.name||`${stage}.image`,missing:true});
      }
      backup.trades.push(copy);
    }
    download(JSON.stringify(backup,null,2),filename,'application/json');toast(message);
  }
  async function exportJson() { await exportStateBackup(state,`nketiah-journal-backup-${today}.json`,'JSON backup downloaded.'); }
  async function exportCloudBackup() {
    let backup=null;try{backup=JSON.parse(localStorage.getItem(CLOUD_BACKUP_KEY)||'null');}catch(_){}
    if(!backup){toast('No pre-cloud browser backup was found.','error');return;}
    await exportStateBackup(normalizeStatePayload(backup),`nketiah-journal-pre-cloud-backup-${today}.json`,'Pre-cloud browser backup downloaded.');
  }
  function parseCsv(text) {
    const rows=[];let row=[];let cell='';let quoted=false;
    for(let i=0;i<text.length;i++){const c=text[i];if(quoted){if(c==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(c==='"'){quoted=false;}else{cell+=c;}}else if(c==='"'){quoted=true;}else if(c===','){row.push(cell);cell='';}else if(c==='\n'){row.push(cell);rows.push(row);row=[];cell='';}else if(c!=='\r'){cell+=c;}}
    if(cell.length||row.length){row.push(cell);rows.push(row);}return rows;
  }
  function normalizeHeader(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();}
  function headerIndex(headers, candidates){return headers.findIndex(h=>candidates.includes(normalizeHeader(h)));}
  async function importFile(file) {
    if(!file)return;
    try {
      const text=await file.text();
      if(file.name.toLowerCase().endsWith('.json')){
        const data=JSON.parse(text);const incoming=Array.isArray(data)?data:data.trades;
        if(!Array.isArray(incoming))throw new Error('This JSON file does not contain a trade list.');
        const setupMap=new Map();const planMap=new Map();const tradeMap=new Map();
        for(const setup of (data.setups||[])){
          let destination=state.setups.find(x=>x.name.toLowerCase()===String(setup.name||'').toLowerCase());
          if(!destination){destination={...setup,id:uid('setup'),isDemo:false};state.setups.push(destination);}
          if(setup.id)setupMap.set(setup.id,destination.id);
        }
        const importedPlans=[];
        for(const plan of (data.plans||[])){
          const destination={...plan,id:uid('plan'),tradeId:'',isDemo:false};state.plans.push(destination);importedPlans.push({source:plan,destination});if(plan.id)planMap.set(plan.id,destination.id);
        }
        let added=0,duplicates=0;
        async function importPhotoEntry(rawPhoto,fallbackName){
          if(!rawPhoto||rawPhoto.missing)return null;
          let dataUrl='';let name=fallbackName;let mime='image/jpeg';
          if(typeof rawPhoto==='string'){
            if(rawPhoto.startsWith('data:'))dataUrl=rawPhoto;
            else return {id:rawPhoto,name};
          } else if(rawPhoto.dataUrl){dataUrl=rawPhoto.dataUrl;name=rawPhoto.name||name;mime=rawPhoto.type||mime;}
          else if(rawPhoto.id)return {id:rawPhoto.id,name:rawPhoto.name||name,type:rawPhoto.type||''};
          if(!dataUrl)return null;
          const blob=dataUrlToBlob(dataUrl);const type=blob.type||mime;const file=new File([blob],name,{type});const saved=await savePhoto(file);return {id:saved.id,name,type};
        }
        for(const raw of incoming){
          const normalized={...raw};normalized.closedAt=raw.closedAt||raw.closed_at||raw.close_date||raw.date||'';normalized.symbol=String(raw.symbol||raw.ticker||'').trim().toUpperCase();normalized.pnlUsd=Number(raw.pnlUsd??raw.net_pnl_usd??raw.pnl??raw.profit??0);
          if(!normalized.closedAt||!normalized.symbol||!Number.isFinite(normalized.pnlUsd))continue;
          const duplicate=state.trades.find(t=>t.closedAt===normalized.closedAt&&t.symbol===normalized.symbol&&Number(t.pnlUsd)===normalized.pnlUsd);
          if(duplicate){duplicates++;if(raw.id)tradeMap.set(raw.id,duplicate.id);continue;}
          const stages={before:[],during:[],after:[]};
          const sourceStages=raw.stages&&typeof raw.stages==='object'?raw.stages:{before:[raw.images?.snr,raw.images?.confirmation].filter(Boolean),during:[raw.images?.price].filter(Boolean),after:[raw.images?.after].filter(Boolean)};
          for(const stage of Object.keys(stages)){
            const entries=Array.isArray(sourceStages[stage])?sourceStages[stage]:sourceStages[stage]?[sourceStages[stage]]:[];
            for(let index=0;index<entries.length;index++){const image=await importPhotoEntry(entries[index],`${stage}-${index+1}.image`);if(image)stages[stage].push(image);}
          }
          const tradeId=uid('trade');
          state.trades.push({id:tradeId,createdAt:new Date().toISOString(),closedAt:normalized.closedAt,symbol:normalized.symbol,pnlUsd:normalized.pnlUsd,followedSop:raw.followedSop||'',snrTf:raw.snrTf||raw.snr_timeframe||'',confirmTf:raw.confirmTf||raw.confirmation_timeframe||'',targetPips:raw.targetPips??raw.target_pips??null,collectedPips:raw.collectedPips??raw.collected_pips??null,setupId:setupMap.get(raw.setupId)||'',planId:planMap.get(raw.planId)||'',notes:raw.notes||'',stages,isDemo:false});
          if(raw.id)tradeMap.set(raw.id,tradeId);added++;
        }
        for(const {source,destination} of importedPlans){destination.tradeId=tradeMap.get(source.tradeId)||'';if(destination.tradeId)destination.status='executed';}
        if(data.settings)state.settings={...state.settings,...data.settings};
        persistState();render();toast(`Imported ${added} trade${added===1?'':'s'}${duplicates?` · skipped ${duplicates} duplicate${duplicates===1?'':'s'}`:''}.`);return;
      }
      const rows=parseCsv(text);if(rows.length<2)throw new Error('This CSV has no trade rows.');
      const headers=rows[0];const dateIndex=headerIndex(headers,['closed at','close date','closed date','close date utc','date','closed_at','close_date']);const symbolIndex=headerIndex(headers,['symbol','ticker','instrument','asset']);const pnlIndex=headerIndex(headers,['net pnl usd','net pnl','net profit loss usd','profit loss','p l','pnl','profit','net profit']);
      if(dateIndex<0||symbolIndex<0||pnlIndex<0)throw new Error('CSV needs columns for close date, symbol, and P/L.');
      let added=0,duplicates=0;
      for(const cells of rows.slice(1)){
        if(!cells.length)continue;let closedAt=String(cells[dateIndex]||'').trim();const symbol=String(cells[symbolIndex]||'').trim().toUpperCase();const pnl=Number(String(cells[pnlIndex]||'').replace(/[$,]/g,''));
        if(!closedAt||!symbol||!Number.isFinite(pnl))continue;
        const dateObj=new Date(closedAt);if(!/^\d{4}-\d{2}-\d{2}$/.test(closedAt)&&!Number.isNaN(dateObj.getTime()))closedAt=localDateString(dateObj);
        if(state.trades.some(t=>t.closedAt===closedAt&&t.symbol===symbol&&Number(t.pnlUsd)===pnl)){duplicates++;continue;}
        const idx=name=>headerIndex(headers,[name]);
        state.trades.push({id:uid('trade'),createdAt:new Date().toISOString(),closedAt,symbol,pnlUsd:pnl,followedSop:idx('followed sop')>=0?String(cells[idx('followed sop')]||''):'',snrTf:idx('snr timeframe')>=0?String(cells[idx('snr timeframe')]||''):'',confirmTf:idx('confirmation timeframe')>=0?String(cells[idx('confirmation timeframe')]||''):'',targetPips:null,collectedPips:null,setupId:'',planId:'',notes:idx('notes')>=0?String(cells[idx('notes')]||''):'',images:{},isDemo:false});added++;
      }
      persistState();render();toast(`Imported ${added} trade${added===1?'':'s'}${duplicates?` · skipped ${duplicates} duplicate${duplicates===1?'':'s'}`:''}.`);
    } catch(err) { console.warn(err);toast(err.message||'Could not import this file.','error'); }
  }

  function loadSampleWorkspace() {
    if(state.trades.some(t=>t.isDemo)){state.sampleWorkspace=true;persistState();render();return;}
    const setupId=uid('setup');const now=new Date();
    const setup={id:setupId,name:'SNR rejection',description:'Price rejects a marked support or resistance zone with a clear confirmation.',entryTrigger:'Wait for price to test the zone, then require a clean rejection and lower-timeframe confirmation.',timeframes:'H1, M15',symbols:'XAUUSD, EURUSD',invalidation:'The setup is invalid if price accepts beyond the zone or the planned structure breaks.',notes:'Example setup only. Refine these rules to match your own method.',createdAt:new Date().toISOString(),isDemo:true};
    state.setups.push(setup);
    const sampleRows=[
      [-17,'XAUUSD',54.8,'yes','H1','M15',68,'Clean rejection at a well-marked zone. Waited for confirmation before entry.'],
      [-14,'EURUSD',-22.4,'yes','H4','M30',-18,'Direction was right, but the exit was late. Review partials.'],
      [-12,'XAUUSD',0,'no','H1','M5',0,'Breakeven. Entry was early; I did not wait for the planned trigger.'],
      [-9,'GBPUSD',38.25,'yes','H4','M15',51,'Good patience. The setup matched the playbook and the risk stayed controlled.'],
      [-7,'XAUUSD',-31.6,'no','H1','M15',-39,'Ignored the invalidation level. Revisit discipline before the next session.'],
      [-4,'EURUSD',72.1,'yes','H4','M30',86,'Strong follow-through. Captured the planned move without chasing.'],
      [-2,'XAUUSD',21.75,'yes','H1','M15',33,'Reduced size into resistance; reasonable management.'],
      [-1,'XAUUSD',-13.4,'yes','H1','M5',-16,'Small loss within plan. No rule break.']
    ];
    const created=sampleRows.map(([offset,symbol,pnl,sop,snr,confirm,pips,notes],i)=>{
      const d=new Date(now);d.setDate(d.getDate()+offset);if(i===4)d.setDate(d.getDate()-1); // one example can land on a weekend
      return {id:uid('trade'),createdAt:new Date().toISOString(),closedAt:localDateString(d),symbol,pnlUsd:pnl,followedSop:sop,snrTf:snr,confirmTf:confirm,targetPips:100,collectedPips:pips,setupId:(symbol==='XAUUSD'||symbol==='EURUSD')?setupId:'',planId:'',notes,stages:{before:[],during:[],after:[]},isDemo:true};
    });
    const sampleChart=(caption,points,color)=>{
      const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="720" height="405" viewBox="0 0 720 405"><rect width="720" height="405" rx="24" fill="#101416"/><path d="M0 80H720M0 145H720M0 210H720M0 275H720M0 340H720" stroke="#273037" stroke-width="1"/><path d="M55 38V352M55 352H680" stroke="#657078" stroke-width="2"/><rect x="55" y="128" width="625" height="22" fill="#39dda0" fill-opacity=".12"/><path d="${points}" fill="none" stroke="${color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><text x="56" y="30" fill="#e5e9e8" font-family="Arial,sans-serif" font-size="20" font-weight="700">${caption}</text><text x="680" y="380" fill="#718078" font-family="Arial,sans-serif" font-size="12" text-anchor="end">FICTIONAL TEST IMAGE · XAUUSD H1</text></svg>`;
      return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
    };
    created[created.length-1].stages.before=[{id:sampleChart('BEFORE TRADE','M70 265 L120 245 L170 260 L220 205 L270 225 L320 172 L370 195 L420 143 L470 165 L520 142 L570 166 L620 135','#65a9ff'),name:'Fictional sample chart · before'}];
    created[created.length-1].stages.during=[{id:sampleChart('TRADE RUNNING','M70 265 L120 240 L170 256 L220 207 L270 224 L320 170 L370 192 L420 146 L470 160 L520 118 L570 132 L620 82','#f0c76a'),name:'Fictional sample chart · during'}];
    created[created.length-1].stages.after=[{id:sampleChart('AFTER TRADE','M70 265 L120 240 L170 256 L220 207 L270 224 L320 170 L370 192 L420 146 L470 160 L520 118 L570 132 L620 84','#39dda0'),name:'Fictional sample chart · after'}];
    state.trades.push(...created);
    const planId=uid('plan');state.plans.push({id:planId,symbol:'XAUUSD',timeframe:'H1',entry:'2674.50',stop:'2669.50',target:'2686.00',status:'pending',thesis:'Sample idea: wait for a clear rejection from the marked zone before considering entry.',riskNotes:'Keep risk fixed and invalidate the idea if price accepts below structure.',createdAt:new Date().toISOString(),tradeId:'',isDemo:true});
    state.sampleWorkspace=true;ui.year='all';ui.symbol='all';persistState();render();toast('Fictional sample workspace loaded.');
  }
  async function clearSampleWorkspace() {
    const demoTrades=state.trades.filter(t=>t.isDemo);const keep=state.trades.filter(t=>!t.isDemo);
    for(const t of demoTrades)for(const photo of getAllPhotoIds(t))await deletePhoto(photo);
    state.trades=keep;state.setups=state.setups.filter(s=>!s.isDemo);state.plans=state.plans.filter(p=>!p.isDemo);state.sampleWorkspace=false;persistState();render();toast('Sample data cleared.');
  }

  function showExportAnchor() { document.getElementById('settings-export')?.scrollIntoView({behavior:'smooth',block:'start'}); }
  function confirmDeleteTrade(id) { const t=getTrade(id);if(!t)return;renderConfirm('Delete this trade?',`Delete ${t.symbol} closed ${formatDate(t.closedAt)}? ${productionMode?'This removes the entry from your private cloud journal.':'This removes its journal entry from this browser.'}`,'delete-trade',id,true); }
  function confirmDeleteSetup(id) { const s=getSetup(id);if(!s)return;renderConfirm('Delete this setup?',`Delete “${s.name}”? Linked trades will remain in your journal but will no longer count toward this setup.`,'delete-setup',id,true); }
  function confirmClearAll() { renderConfirm(productionMode?'Clear private journal?':'Clear local journal?',productionMode?'This permanently removes synced trades, setups, plans, saved reviews, and cloud images from your owner account and this browser. Download a JSON backup first.':'This removes all trades, setups, plans, and local preferences from this browser.','clear-all','',true); }
  async function executeConfirmed(action,id) {
    if(action==='delete-trade'){
      const t=getTrade(id);if(t){for(const photo of getAllPhotoIds(t))await deletePhoto(photo);state.trades=state.trades.filter(x=>x.id!==id);state.plans.forEach(p=>{if(p.tradeId===id){p.tradeId='';p.status='pending';}});} 
    } else if(action==='delete-setup'){
      state.trades.forEach(t=>{if(t.setupId===id)t.setupId='';});state.setups=state.setups.filter(s=>s.id!==id);
    } else if(action==='clear-all'){
      for(const t of state.trades)for(const photo of getAllPhotoIds(t))await deletePhoto(photo);state=defaultState();ui.year=String(currentYear);ui.symbol='all';ui.search='';try{localStorage.removeItem(AGENT_MEMORY_KEY);}catch(_){}
    }
    persistState();closeModal();render();toast('Done.');
  }

  function renderMonthCalendar() { /* calendar is rendered from state on route change */ }

  function handleClick(event) {
    const actionable=event.target.closest('[data-action]');
    if(!actionable)return;
    const action=actionable.dataset.action;
    if(action==='sign-in-google'){if(!cloud||!cloud.isConfigured){ui.loginError=window.NketiahProductionError||'Production auth is not configured.';render();return;}cloud.signInWithGoogle().catch(error=>{ui.loginError=String(error?.message||'Google sign-in could not be started.');render();});return;}
    if(action==='cloud-reload'){if(window.confirm('Reload the latest private cloud snapshot? Unsynced browser changes will be saved as a local backup before reload.'))reloadCloudSnapshot();return;}
    if(action==='cloud-retry-load'){if(cloudUser)handleCloudAuthState(cloudUser);return;}
    if(action==='cloud-retry-sync'){scheduleCloudSync();return;}
    if(action==='run-cloud-ai-review'){runCloudAiReview(actionable.dataset.mode||ui.aiMode);return;}
    if(action==='save-ai-review'){saveCurrentAiReview();return;}
    if(action==='delete-saved-ai-review'){deleteSavedAiReview(actionable.dataset.id);return;}
    if(action==='export-cloud-backup'){exportCloudBackup();return;}
    if(action==='toggle-password'){
      ui.showPassword=!ui.showPassword;const input=document.getElementById('login-password');if(input){input.type=ui.showPassword?'text':'password';actionable.textContent=ui.showPassword?'Hide':'Show';input.focus();}return;
    }
    if(action==='logout'){signOut();return;}
    if(action==='ai-mode'){ui.aiMode=actionable.dataset.mode==='week'?'week':'trade';ui.aiOutput=null;ui.aiCloudConsent=false;render();return;}
    if(action==='run-ai-review'){runOfflineAiReview(actionable.dataset.mode||ui.aiMode);return;}
    if(action==='ai-clear-output'){ui.aiOutput=null;render();return;}
    if(action==='review-trade-ai'){
      const trade=getTrade(actionable.dataset.id);if(!trade)return;closeModal();ui.aiTradeId=trade.id;ui.aiMode='trade';ui.aiOutput=null;ui.view='ai';render();return;
    }
    if(action==='navigate'){if(ui.view==='ai'&&actionable.dataset.view!=='ai')ui.aiCloudConsent=false;ui.goalEquity=false;ui.agentOpen=false;ui.view=actionable.dataset.view;ui.moreOpen=false;ui.search='';render();if(ui.view==='mt4-activity'&&(productionMode||localMt4Mode))loadMt4AccountEvents({includeEvents:true});else if(ui.view==='connect'&&(productionMode||localMt4Mode))loadMt4AccountEvents({includeEvents:false});return;}
    if(action==='mt4-refresh'){loadMt4AccountEvents({notify:true,includeEvents:true});return;}
    if(action==='risk-acknowledge'){state.settings={...state.settings,riskHaltAcknowledgedDate:today};persistState();render();toast('Acknowledged. Journal stays review-only until the daily reset.');return;}
    if(action==='risk-review-today'){ui.view='journal';ui.moreOpen=false;ui.search='';render();return;}
    if(action==='toggle-goal-equity'){ui.goalEquity=!ui.goalEquity;render();return;}
    if(action==='goal-day'){ui.goalDay=ui.goalDay===actionable.dataset.date?'':(actionable.dataset.date||'');render();if(ui.goalDay){const det=document.getElementById('goal-day-detail');if(det)det.scrollIntoView({behavior:'smooth',block:'nearest'});}return;}
    if(action==='goal-day-close'){ui.goalDay='';render();return;}
    if(action==='coach-ask'){submitCoachMessage(actionable.dataset.prompt||'');return;}
    if(action==='coach-thumb'){coachThumb(Number(actionable.dataset.ts), Number(actionable.dataset.vote)||1);return;}
    if(action==='agent-toggle'){ui.agentOpen=!ui.agentOpen;ui.coachTyping=false;render();return;}
    if(action==='agent-chips'){ui.chipsOpen=!ui.chipsOpen;render();return;}
    if(action==='agent-new-chat'){state.goalCoach={weekKey:weekKeyFor(0),messages:[{role:'coach',text:coachGreeting(),ts:Date.now()}]};persistState();ui.coachTyping=false;render();toast('New chat started.');return;}
    if(action==='close-goal-equity'){if(event.target===actionable||actionable.classList.contains('equity-close')){ui.goalEquity=false;render();}return;}
    if(action==='toggle-more'){ui.moreOpen=!ui.moreOpen;render();return;}
    if(action==='new-trade'){if(!confirmRiskHalt())return;renderTradeModal();return;}
    if(action==='new-trade-date'){const date=actionable.dataset.date;if(!confirmRiskHalt())return;closeModal();renderTradeModal();const input=document.getElementById('trade-date');if(input)input.value=date;return;}
    if(action==='edit-trade'){const t=getTrade(actionable.dataset.id);if(t)renderTradeModal(t);return;}
    if(action==='trade-detail'){const t=getTrade(actionable.dataset.id);if(t)renderTradeDetail(t);return;}
    if(action==='close-modal'){
      if(event.target?.classList?.contains('modal-backdrop')||actionable.closest('.modal-panel')||actionable===event.target){closeModal();}
      return;
    }
    if(action==='delete-trade'){confirmDeleteTrade(actionable.dataset.id);return;}
    if(action==='confirm-delete-trade'){executeConfirmed('delete-trade',actionable.dataset.id);return;}
    if(action==='confirm-delete-setup'){executeConfirmed('delete-setup',actionable.dataset.id);return;}
    if(action==='confirm-clear-all'){executeConfirmed('clear-all','');return;}
    if(action==='set-period'){ui.period=actionable.dataset.period;render();return;}
    if(action==='new-setup'){renderSetupModal();return;}
    if(action==='edit-setup'){const s=getSetup(actionable.dataset.id);if(s)renderSetupModal(s);return;}
    if(action==='setup-detail'){const s=getSetup(actionable.dataset.id);if(s)renderSetupDetail(s);return;}
    if(action==='setup-menu'){const s=getSetup(actionable.dataset.id);if(s)renderConfirm('Delete this setup?',`Delete “${s.name}”? Existing trades will remain unassigned.`,'delete-setup',s.id,true);return;}
    if(action==='delete-setup'){confirmDeleteSetup(actionable.dataset.id);return;}
    if(action==='new-trade-setup'){const setupId=actionable.dataset.id;renderTradeModal();const select=document.getElementById('trade-setup');if(select)select.value=setupId;return;}
    if(action==='new-plan'){renderPlanModal();return;}
    if(action==='plan-menu'){const p=getPlan(actionable.dataset.id);if(p){openModal(`<div class="modal-header"><div><div class="eyebrow">PLAN ACTIONS</div><h2>${escapeHtml(p.symbol)} plan</h2><p>Choose what to do with this plan.</p></div><button class="icon-button" data-action="close-modal">${icon('close',17)}</button></div><div class="modal-body" style="display:grid;gap:9px"><button class="secondary-button" data-action="edit-plan" data-id="${escapeAttr(p.id)}">${icon('edit',14)} Edit plan</button>${p.status==='pending'?`<button class="secondary-button" data-action="plan-status" data-id="${escapeAttr(p.id)}" data-status="missed">Mark missed</button><button class="secondary-button" data-action="plan-status" data-id="${escapeAttr(p.id)}" data-status="cancelled">Cancel plan</button>`:''}<button class="danger-button" data-action="delete-plan" data-id="${escapeAttr(p.id)}">${icon('trash',14)} Delete plan</button></div>`,'small');}return;}
    if(action==='edit-plan'){const p=getPlan(actionable.dataset.id);if(p)renderPlanModal(p);return;}
    if(action==='plan-status'){const p=getPlan(actionable.dataset.id);if(p){p.status=actionable.dataset.status;persistState();closeModal();render();toast(`Plan marked ${p.status}.`);}return;}
    if(action==='delete-plan'){const p=getPlan(actionable.dataset.id);if(p){state.plans=state.plans.filter(x=>x.id!==p.id);persistState();closeModal();render();toast('Plan deleted.');}return;}
    if(action==='calendar-move'){ui.calendarMonth=new Date(ui.calendarMonth.getFullYear(),ui.calendarMonth.getMonth()+Number(actionable.dataset.delta),1);render();return;}
    if(action==='calendar-today'){ui.calendarMonth=new Date(new Date().getFullYear(),new Date().getMonth(),1);render();return;}
    if(action==='calendar-day'){renderDayModal(actionable.dataset.date);return;}
    if(action==='export-csv'){exportCsv();return;}
    if(action==='export-json'){exportJson();return;}
    if(action==='trigger-import'){document.getElementById('import-file')?.click();return;}
    if(action==='load-sample'){loadSampleWorkspace();return;}
    if(action==='clear-sample'){clearSampleWorkspace();return;}
    if(action==='clear-all'){confirmClearAll();return;}
    if(action==='settings-export'){showExportAnchor();return;}
    if(action==='settings-accounts'){document.getElementById('settings-accounts')?.scrollIntoView({behavior:'smooth',block:'start'});return;}
    if(action==='switch-journal'){switchJournal(actionable.dataset.accountKey||MANUAL_JOURNAL_KEY);return;}
    if(action==='settings-privacy'){document.getElementById('settings-privacy')?.scrollIntoView({behavior:'smooth',block:'start'});return;}
    if(action==='clear-search'){ui.search='';ui.year=String(currentYear);ui.symbol='all';render();return;}
    if(action==='remove-stage-photo'){
      const stage=actionable.dataset.stage;const tempId=actionable.dataset.tempId;const photoId=actionable.dataset.photoId;
      if(tempId){const item=(ui.pendingPhotos[stage]||[]).find(x=>x.tempId===tempId);if(item){URL.revokeObjectURL(item.url);ui.pendingPhotoUrls.delete(tempId);}ui.pendingPhotos[stage]=(ui.pendingPhotos[stage]||[]).filter(x=>x.tempId!==tempId);}
      else if(photoId)ui.removedPhotoIds.add(photoId);
      refreshStageGallery(stage);return;
    }
    if(action==='print-report'){ui.view='performance';render();window.setTimeout(()=>window.print(),250);return;}
  }
  function signOut() {
    stopLocalMt4RefreshLoop();
    if(productionMode&&cloud){cloud.signOut().catch(()=>toast('Could not sign out.','error'));return;}
    isAuthenticated=false;ui.loginError='';ui.showPassword=false;ui.loginUsername='nketiah';
    try { if(typeof sessionStorage!=='undefined')sessionStorage.removeItem(AUTH_KEY); } catch (_) {}
    closeModal();render();
  }
  function handleLoginSubmit(form) {
    const fd=new FormData(form);const username=String(fd.get('username')||'').trim();const password=String(fd.get('password')||'');
    const expectedUsername=String(demoAuth?.username||'');const expectedPassword=String(demoAuth?.password||'');
    if(!productionMode&&expectedUsername&&expectedPassword&&username===expectedUsername&&password===expectedPassword){
      isAuthenticated=true;ui.loginError='';ui.loginUsername=username;ui.showPassword=false;
      try { if(typeof sessionStorage!=='undefined')sessionStorage.setItem(AUTH_KEY,'active'); } catch (_) {}
      ui.view='performance';render();startRiskClock();if(localMt4Mode){loadMt4AccountEvents({renderAfter:false,includeEvents:false});startLocalMt4RefreshLoop();}toast('Welcome back, Nketiah.');return;
    }
    ui.loginUsername=username;ui.loginError=productionMode?'Use the configured Google account to sign in.':'That username or password did not match.';ui.showPassword=false;render();
    window.setTimeout(()=>document.getElementById('login-password')?.focus(),0);
  }
  function handleSubmit(event) {
    const form=event.target;
    if(form.id==='login-form'){event.preventDefault();handleLoginSubmit(form);}
    else if(form.id==='trade-form'){event.preventDefault();handleTradeSubmit(form);}
    else if(form.id==='setup-form'){event.preventDefault();handleSetupSubmit(form);}
    else if(form.id==='plan-form'){event.preventDefault();handlePlanSubmit(form);}
    else if(form.id==='settings-form'){event.preventDefault();handleSettingsSubmit(form);}
    else if(form.id==='goal-form'){event.preventDefault();handleGoalSubmit(form);}
    else if(form.id==='goal-coach-form'){event.preventDefault();const input=form.querySelector('input[name="coachMessage"]');const value=input?input.value:'';if(input)input.value='';submitCoachMessage(value);}
  }
  function handleGoalSubmit(form) {
    const fd=new FormData(form);
    state.settings={...state.settings,weeklyGoal:fd.get('weeklyGoal')||''};
    persistState();render();
    toast(Number(state.settings.weeklyGoal)>0?'Weekly goal saved.':'Weekly goal cleared.');
  }
  function handleChange(event) {
    const target=event.target;
    if(target.matches('[data-filter="account-journal"]')){switchJournal(target.value);return;}
    if(target.matches('[data-filter="mt4-account"]')){ui.mt4ActivityAccount=target.value;render();loadMt4AccountEvents({renderAfter:true,includeEvents:true});return;}
    if(target.matches('[data-filter="year"]')){ui.year=target.value;render();return;}
    if(target.matches('[data-filter="symbol"]')){ui.symbol=target.value;render();return;}
    if(target.matches('[data-filter="calendar-symbol"]')){ui.calendarSymbol=target.value;render();return;}
    if(target.matches('[data-ai-cloud-consent]')){ui.aiCloudConsent=target.checked;render();return;}
    if(target.matches('[data-filter="ai-trade"]')){ui.aiTradeId=target.value;ui.aiOutput=null;ui.aiCloudConsent=false;render();return;}
    if(target.matches('[data-filter="ai-week"]')){ui.aiWeek=target.value;ui.aiOutput=null;ui.aiCloudConsent=false;render();return;}
    if(target.matches('[data-ai-stage]')){ui.aiStages[target.dataset.aiStage]=target.checked;ui.aiOutput=null;ui.aiCloudConsent=false;render();return;}
    if(target.matches('[data-photo-stage]')){
      const files=[...(target.files||[])];if(!files.length)return;const stage=target.dataset.photoStage;
      for(const file of files){const error=selectedFileValid(file);if(error){toast(`${file.name}: ${error}`,'error');target.value='';return;}}
      ui.pendingPhotos[stage]=ui.pendingPhotos[stage]||[];
      for(const file of files){const tempId=uid('pendingphoto');const url=URL.createObjectURL(file);ui.pendingPhotoUrls.set(tempId,url);ui.pendingPhotos[stage].push({file,tempId,url});}
      target.value='';refreshStageGallery(stage);return;
    }
    if(target.id==='import-file'){
      const file=target.files?.[0];if(file)importFile(file);target.value='';return;
    }
  }
  function handleInput(event) {
    const target=event.target;
    if(target.id==='journal-search'){
      ui.search=target.value;const cursor=target.selectionStart;const main=document.querySelector('.main-content');if(main){main.innerHTML=`<div class="page-heading"><div><div class="eyebrow">NKETIAH JOURNAL · SEE THE UNSEEN</div><h1>${viewMeta.journal[0]}</h1><p class="page-subtitle">${viewMeta.journal[1]}</p></div><div class="page-actions"><button class="secondary-button" data-action="export-csv">${icon('download',15)} Export</button><button class="primary-button" data-action="new-trade">${icon('plus')} Add trade</button></div></div>${renderJournal()}`;const input=document.getElementById('journal-search');if(input){input.focus();input.setSelectionRange(cursor,cursor);} }return;
    }
    if(target.closest('#calculator-form')){updateCalculator();return;}
  }
  function handleKeydown(event) { if(event.key==='Escape'&&ui.agentOpen){ui.agentOpen=false;render();return;} if(event.key==='Escape'&&ui.goalEquity){ui.goalEquity=false;render();return;} if(event.key==='Escape'&&ui.modal)closeModal(); }
  appRoot.addEventListener('click',handleClick);
  modalRoot.addEventListener('click',(event)=>{
    if(event.target.classList.contains('modal-backdrop')){closeModal();return;}
    handleClick(event);
  });
  document.addEventListener('submit',handleSubmit);
  document.addEventListener('change',handleChange);
  document.addEventListener('input',handleInput);
  document.addEventListener('keydown',handleKeydown);
  render();
  if(localMt4Mode&&isAuthenticated){loadMt4AccountEvents({renderAfter:false,includeEvents:false});startLocalMt4RefreshLoop();}
  detectLocalMt4Bridge();
  if(isAuthenticated)startRiskClock();
  if(productionMode&&cloud&&cloud.isConfigured){cloud.onAuthStateChange(user=>handleCloudAuthState(user));}
})();
