# Production setup — Nketiah Journal

This guide configures the production entry point. **This source checkout contains no live Supabase credentials.** The owner reports the hosted app and basic cloud save/reload are working; the MT4/MT5 migrations and functions described below are new and have not been deployed. Verify owner-only access and backups in the live project before importing real broker activity.

## 1. Install and set frontend-safe project values

```bash
npm install
cp .env.example .env.local
```

Edit `.env.local` with your own project values:

```dotenv
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_YOUR_KEY
VITE_OWNER_EMAIL=your-google-email@example.com
```

The publishable key and owner email are visible in the browser bundle. This is expected; RLS and the server-side owner allowlist are the security boundary. **Never use a service-role/secret key as a `VITE_` variable. Never put the Gemini API key in `.env.local` or frontend code.** `.env.local` is ignored by Git.

For local UI development, `npm run dev -- --open /production.html` serves the production entry. The root `index.html` is a separate client-side demo shell and is not a production login.

## 2. Configure Supabase Auth and Google OAuth

1. Create a Supabase project and note its project URL, project reference, and publishable key.
2. In Google Cloud Console, create a **Web application** OAuth client. Add the Supabase Auth callback URL as an authorized redirect URI:

   ```text
   https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback
   ```

3. In Supabase Dashboard → Authentication → Providers → Google, enable Google and enter the OAuth client ID and client secret. Keep the client secret in Supabase, not in this repository.
4. In Supabase Dashboard → Authentication → URL Configuration, set the Site URL and add the exact production redirect URL, for example:

   ```text
   https://journal.example.com/production.html
   ```

   For local development, also allow `http://localhost:5173/production.html` (and only if needed, `http://127.0.0.1:5173/production.html`).
5. Disable public signups in the hosted project's Auth settings. Invite/create only the intended owner account using the Supabase Dashboard. With signup disabled, the owner must already exist in Supabase Auth before Google sign-in.
6. Copy the owner's Supabase Auth **user UUID**. You will use it in the next steps and as `OWNER_USER_ID` for the Edge Function.

`supabase/config.toml` sets `auth.enable_signup = false` for local Supabase development. Hosted Dashboard Auth settings are separate; verify them explicitly.

## 3. Apply the database and private Storage migration

Install and authenticate the Supabase CLI, then link the repository to your own project and apply the migration:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Alternatively, run `supabase/migrations/202610120001_private_journal.sql` once in the Supabase SQL Editor.

After the owner's Auth user exists and the migration is applied, seed the single-owner allowlist with the UUID from step 2:

```sql
insert into private.journal_owner (singleton, owner_id)
values (true, 'YOUR_OWNER_AUTH_USER_UUID')
on conflict (singleton) do update set owner_id = excluded.owner_id;
```

This row is required. Until it is present, authenticated users cannot read or write the journal table or image bucket. The migration creates:

- `private.journal_owner` plus a narrowly granted `public.is_journal_owner()` check;
- RLS-protected `public.journal_snapshots` and a revision-checked save RPC;
- a **non-public** `journal-images` Storage bucket with owner-folder policies.

Do not remove `FORCE ROW LEVEL SECURITY`, the owner policies, or the private bucket setting. Verify that another authenticated test account cannot select/insert a snapshot or access an owner's storage path.

## 4. Configure and deploy the AI Edge Function (optional)

The deterministic offline summaries do not call a model. The optional cloud route is unavailable until the function is configured and deployed.

1. Obtain a Gemini API key and review Google's current pricing, data-use, and retention terms for the account/tier you choose. The user-selected fields, notes, and images are sent to Google for processing only after the per-review consent checkbox and action.
2. Set Edge Function secrets for your project. Use the project publishable key (not a service-role key) for the function's user-scoped Supabase client:

   ```bash
   supabase secrets set --project-ref YOUR_PROJECT_REF \
     GEMINI_API_KEY='YOUR_GEMINI_API_KEY' \
     GEMINI_MODEL='gemini-3.8-flash' \
     OWNER_USER_ID='YOUR_OWNER_AUTH_USER_UUID' \
     APP_ALLOWED_ORIGINS='https://journal.example.com' \
     SUPABASE_PUBLISHABLE_KEY='sb_publishable_YOUR_KEY'
   ```

   For local testing, include the dev origin as a comma-separated value, for example `https://journal.example.com,http://localhost:5173`. Use exact origins (scheme + host + optional port; no route path). Do not allow `*`.
3. Deploy the function:

   ```bash
   supabase functions deploy ai-review --project-ref YOUR_PROJECT_REF
   ```

   `supabase/config.toml` requires JWT verification. The function also verifies the bearer session, owner UUID, per-request consent, selected owner-scoped image paths, file types, and request limits. It does not log the provider request body or key.

The default model is configured in the function source as `gemini-3.8-flash`; it can be overridden with `GEMINI_MODEL`. If provider model availability or terms change, update and retest before use.

## 5. Build and deploy the production static site

With `.env.local` configured:

```bash
npm run build
```

Vite builds **only** `production.html` to `dist/`; the demo `index.html` and its prototype credentials are not included in the production build. Deploy `dist/` to your chosen static host. Ensure the hosted URL is one of Supabase Auth's allowed redirect URLs and that `APP_ALLOWED_ORIGINS` contains the site's exact origin.

Open `https://journal.example.com/production.html`. The app requires the owner email and project configuration. The frontend email check is only a usability check; RLS and the Edge Function owner check enforce access server-side.

## 6. Verify with fictional data before real data

1. Sign in with the invited owner Google account. Confirm an unauthorized account is rejected and signed out.
2. Load the app's fictional sample workspace. Verify trades and images sync across two owner devices. Confirm image objects are private and stored under the owner's UUID folder.
3. Test a second-device revision conflict: make changes on both devices, sync the first, then ensure the second reports a conflict instead of silently overwriting. Reload the cloud snapshot and verify the local state was retained as a downloadable pre-cloud backup where applicable.
4. Review [`ai-evaluation/README.md`](./ai-evaluation/README.md). Run its fictional fixture dry run, then evaluate the cloud and local candidates using **synthetic fixtures only**. Confirm weekday-only aggregation, breakevens in the win-rate denominator, evidence citations, and no financial-action advice.
5. Only after that, test the deployed cloud review with fictional sample trades and explicitly select the fields/images. Confirm the request button is disabled until consent is checked, no request is made from the offline review, and an AI review is saved only after selecting **Save review**.
6. Verify export, import, image deletion, sign-out, and account recovery. Keep independent JSON backups.

## 6. MT4/MT5 broker account logging (optional; test on demo first)

The publishers (`NketiahAccountLogger.mq4` and `NketiahAccountLogger.mq5`) and full acceptance checklist are in [`mt4-integration/README.md`](./mt4-integration/README.md). This adds owner-only broker activity and live account snapshots, recurring Balance/Floating P/L/Equity data, explicit TP/SL/unclassified counters, an atomic closed-trade append to the revisioned journal snapshot, and a **Broker activity** view. Every event carries a `platform` field (`mt4`/`mt5`), and each connected account gets its own switchable journal (`platform:login@server`) — only the active journal syncs, switched from the Journal selector in the top bar. The UI refreshes once per second while visible; the EA sends a snapshot on its timer (five-second default).

**Required local gate:** before any broker cloud migration, secret, function, or site deployment, complete the loopback-only local demo pass in `mt4-integration/README.md`, including compiling and running the EA(s) under the user's Linux/Wine terminal. Use only the temporary local token and a demo account. Do not continue to the cloud steps until that local pass succeeds.

1. Confirm `private.journal_owner` contains the intended owner row and check migration status. Apply `202610130001_mt4_account_ingest.sql` if missing, followed by `202610130002_mt4_dashboard.sql`, then `202610160001_multi_account_platform.sql` (platform column + multi-account snapshots/journals):

   ```bash
   supabase migration list --project-ref YOUR_PROJECT_REF
   supabase db push --project-ref YOUR_PROJECT_REF
   ```

2. Generate a 32-byte random terminal token locally, keep it private, and set it as an Edge Function secret. Never add it to a browser variable or Git:

   ```bash
   TOKEN="$(openssl rand -hex 32)"
   supabase secrets set --project-ref YOUR_PROJECT_REF MT4_INGEST_TOKEN="$TOKEN"
   printf '%s\n' "$TOKEN"
   ```

   Copy the value directly into either EA's `DeviceToken` input (the same token covers MT4 and MT5 accounts). The token can append events only; rotating the Edge Function secret revokes it. Do not send it to me.

3. Deploy the broker ingest function (unchanged name `mt4-ingest` — it now accepts both platforms). Account snapshots route to a separate bounded upsert RPC; other events append through the owner-bound event RPC, keyed per account. The Edge Function uses server-side Supabase credentials, never terminal credentials:

   ```bash
   supabase functions deploy mt4-ingest --project-ref YOUR_PROJECT_REF
   ```

4. Deploy the rebuilt AI-review function so its updated evidence-first rules and sanitization match the new broker fields, then rebuild and deploy the updated static site. The owner reads per-account snapshots across views and the `mt4_account_events` table on the Broker activity page through RLS.
5. After the local gate has passed, switch each EA from the local URL/token to the cloud values: allow only `https://YOUR_PROJECT_REF.supabase.co` under **Tools → Options → Expert Advisors**, set `IngestEndpoint` to `https://YOUR_PROJECT_REF.supabase.co/functions/v1/mt4-ingest`, and set `DeviceToken` to the **fresh cloud token**, never the local test token. Keep **Account History → All History** selected and attach one copy to a chart on each **cloud demo account** (repeat per account you want connected). The EAs snapshot every 5 seconds by default (five-second minimum) and have no trade-execution calls. The production CMS itself polls the account snapshot and journal revision once per visible second; expect recurring database reads while it is open, with event rows fetched while Broker activity is visible.
6. Complete the cloud demo scenarios in [`mt4-integration/README.md`](./mt4-integration/README.md) before any live-account rollout — including at least one MT5 demo account if you plan to use MT5. Closed history can catch up after a terminal reconnect; intermediate order edits while the terminal was offline may be lost.

`supabase/config.toml` deliberately disables platform JWT verification only for `mt4-ingest`; the function instead validates the separate random `MT4_INGEST_TOKEN`. Keep the token and any service-role credential out of MQL4/MQL5 source, EA inputs other than the device token, browser code, and screenshots.

## Data and service boundaries

- Journal snapshots and chart images sync to your Supabase project. The JSON pre-cloud backup is stored locally in browser storage until downloaded or cleared.
- Each cloud-AI request sends the selected record fields/notes and selected image bytes from Supabase Storage to Google's Gemini API. AI output is not persisted unless the user presses **Save review**. Provider-side processing/retention is governed by the account's current terms; assess those terms before enabling real-data use.
- The AI system is designed for reflection and process observations only. It must not be used for predictions, buy/sell signals, entry/exit instructions, or position sizing.
- The local model remains an evaluation candidate, not an integrated runtime. No performance guarantee is made for the 4 GB Android phone or 8 GB laptop.
- This scaffold has not been deployed or audited. Before production use, review current Supabase, Google OAuth, Gemini API, hosting, privacy, and backup requirements for your jurisdiction and risk profile.
