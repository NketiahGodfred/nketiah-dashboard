# Start here — local MT4 test (Nketiah Journal)

This guide is for the **loopback-only local test**. The EA sends demo observations to a mock server on your own computer; the journal UI reads them through a local Vite proxy. This flow does **not** connect to Supabase or Cloudflare and does not upload journal or MT4 data. Cloud setup is intentionally not covered here.

> Shortcut: `./start.sh` does steps 1–2 and 5 for you — it reuses a healthy mock (keeping the EA's device token), starts the Vite bridge, verifies the account snapshot end-to-end, and prints the ready URL. Use `./start.sh status | restart | stop | test` as needed. The manual steps below remain the source of truth.

## Requirements

- Linux with your MT4 terminal running under Wine.
- MetaEditor to compile the EA on your MT4 installation.
- Node.js 20+ and npm.
- Python 3.10+.
- Local HTTP port 80 available. The MT4 `WebRequest` test must use the default HTTP port; do not change it to `8787`.

## 1. Extract and install project dependencies

Extract `Nketiah_Journal_Local_Test.zip`, open a terminal in the extracted `nketiah-journal` folder, and run:

```bash
npm ci
npm test
npm run test:local
```

The test suites validate the local contracts and mock behavior; they do not compile MetaTrader code or replace the demo run below.

## 2. Start the local MT4 mock server

Open a terminal in the project folder and run:

```bash
touch mt4-integration/local-test-events.jsonl
chmod 600 mt4-integration/local-test-events.jsonl
sudo env NJ_MT4_TEST_PORT=80 NJ_MT4_TEST_LOG="$PWD/mt4-integration/local-test-events.jsonl" python3 mt4-integration/local_test_server.py
```

Keep this terminal running. It listens only on `127.0.0.1` and prints a temporary random device token. Copy that token directly into the EA inputs on this computer; **do not post or reuse it**. If port 80 is occupied, identify the service first—do not stop an unknown process.

## 3. Compile and configure the EA in MT4/Wine

1. In MT4, select **File → Open Data Folder**, then open `MQL4/Experts`.
2. Copy `mt4-integration/NketiahAccountLogger.mq4` there.
3. Open the file in MetaEditor and compile with **F7**. Resolve compiler errors before continuing. The `.ex4` must be produced by the MetaEditor that matches your MT4 terminal; it is not included in this ZIP.
4. Use a **demo account** and attach one EA copy to one chart.
5. In the EA inputs set:
   - `IngestEndpoint`: `http://127.0.0.1/functions/v1/mt4-ingest`
   - `DeviceToken`: the temporary token printed by the running local mock server
   - `PollSeconds`: `5` (default)
6. In MT4, open **Tools → Options → Expert Advisors**, enable **Allow WebRequest for listed URL**, and add exactly `http://127.0.0.1` (no port).
7. Keep **Account History → All History** selected. Confirm the Experts tab reports a successful connection.

**MT5 terminals:** copy `mt4-integration/NketiahAccountLogger.mq5` into `MQL5/Experts` instead and compile there; the inputs and mock endpoint are identical (it reports `platform: mt5`). The local mock keys each account separately, so connecting a second account (MT4 or MT5) adds a second journal — switch between them from the journal selector in the top bar, or with the switch buttons under Settings → Connected accounts. The **Connect** sidebar tab shows all connected accounts and the exact steps to connect another one.

## 4. Start the local Journal UI bridge

Open a **second terminal** in the project folder and run:

```bash
npm run dev:mt4-local
```

Open `http://127.0.0.1:5173/?mt4Local=1` in the same computer's browser. Sign in to the local preview with:

- Username: `nketiah`
- Password: `nketiah@123`

This login is browser-only demo authentication. The app polls the local account snapshot every second across views; the EA itself sends fresh account snapshots on its five-second timer. The **Broker activity** view shows explicit TP/SL and unclassified close counts. Each partial close is a separate record. The browser bridge binds to loopback and proxies its MT4 reads to the local mock.

Keep both terminals and MT4 running during the test. Stop the Vite server and Python mock with **Ctrl+C** when finished. The raw event viewer is `http://127.0.0.1/events`; the JSONL log is at `mt4-integration/local-test-events.jsonl`.

## 5. What to test

Use the one-pass local demo checklist in [`mt4-integration/README.md`](./mt4-integration/README.md): connection/auth, account-wide event capture, close and partial-close records, pending-order lifecycle, balance activity if the demo broker supports it, reconnect catch-up, idempotency, and account snapshot values. Verify that close comments count as TP/SL only when the broker/terminal explicitly labels them; ambiguous reasons must remain unclassified.

## Local UI only (without MT4)

To inspect the browser-only demo without starting the mock or EA, run `npm run dev:loopback` and open the URL printed by Vite, normally `http://127.0.0.1:5173/`. Use fictional data only.

## Important boundary

The mock and Vite preview stay on loopback. Do not expose either server to your LAN or the internet. Do not enter Supabase credentials, cloud tokens, or real-account data in this local pass. No cloud steps are needed now; handle those separately only when you decide you are ready.
