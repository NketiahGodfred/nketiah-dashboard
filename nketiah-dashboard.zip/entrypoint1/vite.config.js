import { defineConfig } from 'vite';
import { resolve } from 'node:path';

const localTarget = new URL(process.env.NKJ_LOCAL_MT4_TARGET || 'http://127.0.0.1');
if (localTarget.protocol !== 'http:' || !['127.0.0.1', 'localhost'].includes(localTarget.hostname)) {
  throw new Error('The local MT4 proxy target must be an HTTP loopback address.');
}

export default defineConfig({
  server: {
    host: '0.0.0.0',
    allowedHosts: true,
    proxy: {
      '/__local_mt4': {
        target: localTarget.origin,
        changeOrigin: false,
        rewrite: (path) => path.replace(/^\/__local_mt4/, '')
      }
    }
  },
  preview: {
    host: '0.0.0.0',
    allowedHosts: true
  },
  build: {
    rollupOptions: {
      input: {
        production: resolve(import.meta.dirname, 'production.html')
      }
    }
  }
});
