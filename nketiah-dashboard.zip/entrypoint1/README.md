# Nketiah Journal

Mobile-first trading journal for recording closed trade results, reviewing process, and comparing outcomes. Broker partial exits (MT4 and MT5) are recorded as separate realized-close entries, and every connected account keeps its own switchable journal. This repository contains both a browser-only prototype and a production-oriented Supabase integration scaffold. The owner reports the frontend is deployed and a basic cloud-save/reload test works; this source checkout contains no live project credentials, and the new broker service is not yet deployed.

## Current local-only test

For the current MT4 local-server run, follow [START_HERE.md](./START_HERE.md). It starts the mock and browser bridge on loopback only; this test does not use Supabase or send data to the cloud. The MT4 EA itself must be compiled in MetaEditor under your terminal/Wine installation.

One command that starts everything in the right order (healthy mock reuse, device-token file, Vite bridge, then verifies the account snapshot end-to-end):

```bash
./start.sh          # also: ./start.sh status | restart | stop | test
```

It prints the ready URL (`http://127.0.0.1:5173/?mt4Local=1`) and demo sign-in (`nketiah` / `nketiah@123`). Logs live in `.run/`.

For a browser-only UI check without MT4, install dependencies and run:

```bash
npm ci
npm run dev:loopback
```

Open the local URL printed in the terminal. The root `index.html` is a browser-only demo shell with prototype credentials `nketiah` / `nketiah@123`. This is not authentication or a security boundary; use fictional data only. `Nketiah_Journal.html` is an older standalone prototype and must not be deployed as the production app.

## Run the production shell locally

Follow [PRODUCTION_SETUP.md](./PRODUCTION_SETUP.md) to configure Supabase and `.env.local`, then run:

```bash
npm run dev:loopback -- --open /production.html
```

The production shell signs in with Google, checks the configured owner email, and uses Supabase Auth, owner-restricted RLS, a private Storage bucket, and an authenticated Edge Function. Build with:

```bash
npm run build
```

The build entry point is **only** `production.html`; the demo shell and its demo credentials are not included in `dist/`. Deploy `dist/` as a static site and serve `/production.html`. Live project credentials are intentionally absent from this checkout. The owner reports that the deployed app's cloud save/reload works; AI remains optional and unverified here.

## Product behavior

- Manual journal entries represent a closed position. The MT4 importer creates a separate entry for each partial or final realized close, retaining both original entry details and that exit's details; evidence images may be attached before, during, or after.
- Win rate is wins divided by all closed trades, with breakevens included in the denominator.
- Weekly reviews include Monday–Friday closes only. Weekend trades remain in monthly, yearly, and overall results.
- The rebuilt deterministic offline review is evidence-first: it compares direction, SOP status, notes/images coverage, recorded MT4 execution fields, account currency, and explicit TP/SL labels. It never infers an MT4 exit reason from close-price proximity; ambiguous or missing reasons remain unclassified. Offline mode does not interpret free-text notes or chart pixels.
- Optional cloud AI can review a selected trade or Monday–Friday week. Each request requires its own explicit consent and sends only selected trade fields, notes, and selected stage images through the authenticated Edge Function. The provider receives selected content for processing. The model is instructed not to infer TP/SL, combine unlike currencies, claim causation, or provide predictions, buy/sell signals, entry/exit instructions, or position-sizing advice. A generated review is not saved unless you choose **Save review**.
- The local model remains an evaluation candidate, not a bundled feature. Benchmark text first and images only if practical on your Android phone and laptop; do not assume multimodal inference will run well on the 4 GB RAM Android device or 8 GB laptop.
- SNR playbook, plans, calendar, analytics, risk reminders, exports, and synthetic-only AI evaluation tools are included.
- When a daily loss or trade-count limit is configured, a sticky risk bar sits under the header on every view (warn at 75%, halt at 100%). Reaching the limit shows a one-per-day halt overlay ("Step away from the chart.") with a live midnight-reset countdown; after acknowledging, the journal stays visibly marked review-only until the day rolls over. Adding a trade prompts a confirmation while halted.
- The Weekly goal tab tracks one profit number per Monday–Friday week: progress ring (draws once when the tab loads), per-session runway bars, pace vs expected, milestone chips (25/50/75/100%), and the last four weeks measured against the same target. Once the goal is covered, the REMAINING stat flips to the spare above the goal as a positive figure (e.g. `+$6.04`, "Spare above goal"). The goal is edited on the tab itself or in Settings. An **Equity curve** toggle opens a mini window (blurred backdrop) showing the cumulative Monday–Friday equity curve with line-draw/dot-pop animations; hovering any point shows a tooltip with that session's win/loss, running equity, and closes logged. A floating **Agent Nketiah** chat widget (bottom-right on the Weekly goal tab only) is an offline, deterministic assistant that holds the whole journal — week, month, all-time stats, setups, streaks, weekday edges, biggest win/loss, totals, and risk rules. It answers a numbered menu (1 goal report · 2 recent closes, auto-generated · 3 week autopsy · 4 discipline · 5 risk check · 6 weekly focus), plain-English questions (“who are you”, “total accumulated loss”, “my setups”, “compare last week”, “what did I trade on XAUUSD”) and commands like `set goal 300`; period-scoped asks (“what my total profit for today”, “how much did I lose yesterday”) answer with that period's totals card, not all-time. The agent learns: every reply has 👍/👎 — 👍 remembers your phrasing so later similar questions get the same answer, 👎 unlearns it, and the quick-reply chips + greeting adapt to what you ask most (memory in localStorage, survives New Chat, wiped by “Clear local data”). New Chat resets the thread each time. The widget lives on the Weekly goal tab only: the round button sits bottom-right, the chat stays closed until you open it, and navigating away closes it. Quick-reply chips are hidden by default — the ✦ header button toggles them.

## Security and data handling

- Frontend configuration contains only the Supabase URL, publishable key, and owner email. Never put a service-role key or Gemini key in browser code or `.env.local`.
- Owner-only access is enforced by the `private.journal_owner` table, RLS policies, owner-folder Storage policies, and an owner UUID check in the Edge Function. The UI email check is not the security boundary.
- The first production sign-in with no cloud snapshot asks whether to upload existing browser data. A local pre-cloud copy is retained and can be exported in Settings. Review the prompt before consenting.
- Snapshot writes use revisions; a second-device conflict stops further sync until you reload the cloud snapshot. Keep separate JSON backups.
- Real journal data is never sent to a model by the demo or offline summaries. Do not request a cloud-AI review until you have set up the provider, reviewed its current terms/retention, and tested the end-to-end flow with the fictional fixtures first.

## Broker account logging (MT4 & MT5, multi-account)

A read-only publisher for MT4 (`NketiahAccountLogger.mq4`) and MT5 (`NketiahAccountLogger.mq5`) plus a private Supabase ingestion path are in [`mt4-integration/README.md`](./mt4-integration/README.md). Both EAs capture account-wide order changes, closed trades, balance/credit entries, and recurring account snapshots; events carry a `platform` field (`mt4`/`mt5`) so each account is ingested into its own journal. The app shows Balance, Floating P/L, and Equity across authenticated views, with explicit TP/SL and unclassified close counts on the **Broker activity** view. The CMS polls once per second while visible; the EA default snapshot interval is five seconds, so displayed broker values update at the EA's cadence. Partial closes remain separate trade records. The EAs use a revocable write-only device token; no Supabase service-role key or terminal password is placed in the terminal.

**Multiple accounts, one app.** Every connected account gets its own journal (`mt4:login@server` / `mt5:login@server` keys) holding its trades, setups, plans, settings, and sync revision — only the active journal syncs to the cloud. The app auto-activates the first connected account's journal. Journals are switched from the compact **Journal selector** in the top bar (or the switch buttons under **Settings → Connected accounts**). The **Connect** sidebar tab lists every connected account with its live Balance/Equity/status and walks through connecting another MT4 or MT5 account (compile the EA, set the ingest endpoint and device token, allow WebRequest, attach to a chart). The legacy **Manual journal** is hidden: it only appears in the selector once it holds hand-entered trades, and EA closes imported into it before per-account keying existed are automatically migrated into the matching account journal on load. The live Balance/Floating/Equity strip only appears while an account journal is active — the manual journal never shows another account's numbers. The Broker activity view also gains an account filter (active journal / all accounts / a specific account) once more than one account is connected.

This integration is **not yet deployed or validated on the user's Wine terminal/broker**. Before any cloud deployment, first compile the EA and pass the loopback-only local demo test in [`mt4-integration/README.md`](./mt4-integration/README.md); the local token and server stay separate from cloud. Only after that local gate, apply `202610130001_mt4_account_ingest.sql`, `202610130002_mt4_dashboard.sql`, and `202610160001_multi_account_platform.sql`, configure a fresh Edge Function token, deploy the updated `mt4-ingest` and `ai-review` functions, and pass the cloud demo test matrix before any live-account rollout. One-second cloud polling checks the account snapshot and journal revision every visible second, so it creates recurring database reads. Automated tests do not replace Wine/MetaEditor or broker-demo validation.

## Evaluation kit

See [`ai-evaluation/README.md`](./ai-evaluation/README.md) for the synthetic-only comparison between cloud inference and local inference. Its default dry run makes no network request. It does not read the journal app's data.

## Known validation status

Workspace checks pass: 24 Node tests (including local and production-mode app runtime smokes, MT4/MT5 contract cases, and an MT5 EA static check), 7 Python local-server tests (multi-account + platform), JavaScript/TypeScript syntax transforms, a Vite production build, and both synthetic AI dry runs (no network calls). The owner reports the frontend is deployed at `https://nketiah-journal.pages.dev` and that basic cloud save/reload works. This workspace has no project credentials, so it cannot independently verify the live Supabase project. The MT4/MT5 migrations and Edge Functions added here have not been applied or deployed; the EAs have not been compiled in the user's Wine/MetaEditor environment or tested against a demo broker. The live AI Edge Function and real-data model call remain unverified.
