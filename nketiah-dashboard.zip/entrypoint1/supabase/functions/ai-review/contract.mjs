const allowedString = (value, max = 4000) => typeof value === 'string' ? value.slice(0, max) : '';
const numeric = value => typeof value === 'number' && Number.isFinite(value) ? value : null;

export function sanitizeAiTrade(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const rawPlan = raw.plan && typeof raw.plan === 'object' && !Array.isArray(raw.plan) ? raw.plan : null;
  const plan = rawPlan ? {
    symbol: allowedString(rawPlan.symbol, 30).toUpperCase(),
    timeframe: allowedString(rawPlan.timeframe, 30),
    entry: allowedString(rawPlan.entry, 80),
    stop: allowedString(rawPlan.stop, 80),
    target: allowedString(rawPlan.target, 80),
    thesis: allowedString(rawPlan.thesis, 2000),
    riskNotes: allowedString(rawPlan.riskNotes, 2000)
  } : null;
  const source = ['mt4', 'mt5'].includes(String(raw.source)) ? raw.source : 'manual';
  const rawReason = String(raw.exitReason || '').toLowerCase();
  return {
    tradeId: allowedString(raw.tradeId, 120),
    source,
    closedAt: allowedString(raw.closedAt, 20),
    openedAt: allowedString(raw.openedAt, 32),
    brokerOpenTime: allowedString(raw.brokerOpenTime, 40),
    brokerCloseTime: allowedString(raw.brokerCloseTime, 40),
    symbol: allowedString(raw.symbol, 30).toUpperCase(),
    side: ['long', 'short'].includes(String(raw.side)) ? raw.side : '',
    netPnl: numeric(raw.netPnl),
    accountCurrency: /^[A-Z]{3}$/.test(String(raw.accountCurrency || '').toUpperCase()) ? String(raw.accountCurrency).toUpperCase() : '',
    outcome: allowedString(raw.outcome, 20),
    lots: numeric(raw.lots),
    mt4Ticket: allowedString(raw.mt4Ticket, 40),
    mt4Login: allowedString(raw.mt4Login, 40),
    mt4Server: allowedString(raw.mt4Server, 100),
    entryPrice: numeric(raw.entryPrice),
    exitPrice: numeric(raw.exitPrice),
    stopLoss: numeric(raw.stopLoss),
    takeProfit: numeric(raw.takeProfit),
    exitReason: source !== 'manual' && ['tp', 'sl'].includes(rawReason) ? rawReason : 'unknown',
    commission: numeric(raw.commission),
    swap: numeric(raw.swap),
    brokerProfit: numeric(raw.brokerProfit),
    followedSop: ['yes', 'no', 'not_recorded'].includes(String(raw.followedSop)) ? raw.followedSop : 'not_recorded',
    snrTf: allowedString(raw.snrTf, 30),
    confirmTf: allowedString(raw.confirmTf, 30),
    targetPips: numeric(raw.targetPips),
    collectedPips: numeric(raw.collectedPips),
    setup: allowedString(raw.setup, 120),
    plan,
    notes: allowedString(raw.notes, 6000)
  };
}

export function sanitizeAppCalculatedMetrics(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  return Object.fromEntries(Object.entries(raw)
    .filter(([key, value]) => /^[a-zA-Z0-9_]{1,60}$/.test(key)
      && (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean' || value === null))
    .slice(0, 40));
}

export function sanitizeSelectedWindow(raw) {
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  return {
    start: allowedString(source.start, 20),
    end: allowedString(source.end, 20),
    rule: allowedString(source.rule, 400)
  };
}
