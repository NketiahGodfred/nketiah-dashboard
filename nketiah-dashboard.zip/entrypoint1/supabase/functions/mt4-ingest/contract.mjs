export const MT4_EVENT_TYPES = new Set([
  'terminal_online',
  'order_baseline',
  'order_opened',
  'pending_order_placed',
  'pending_order_activated',
  'order_modified',
  'pending_order_cancelled',
  'trade_closed',
  'balance_adjustment',
  'account_snapshot'
]);

const text = (value, max = 240) => (typeof value === 'string' ? value.trim().slice(0, max) : '');
const finite = (value) => typeof value === 'number' && Number.isFinite(value) ? value : null;
const safeInteger = (value) => Number.isSafeInteger(value) && value >= 0 ? value : null;
function explicitCloseReason(rawReason, comment) {
  const reason = text(rawReason, 20).toLowerCase();
  const normalizedComment = text(comment, 120).toLowerCase();
  const mentionsTp = /(?:^|[^a-z0-9])(?:\[tp\]|tp|take[ -]+profit)(?=$|[^a-z0-9])/.test(normalizedComment);
  const mentionsSl = /(?:^|[^a-z0-9])(?:\[sl\]|sl|stop[ -]+loss)(?=$|[^a-z0-9])/.test(normalizedComment);
  if ((mentionsTp && mentionsSl) || (reason === 'tp' && mentionsSl) || (reason === 'sl' && mentionsTp)) return 'unknown';
  if (reason === 'tp' || reason === 'sl') return reason;
  if (/^(?:\[tp\]|tp|take[ -]+profit)(?:[\s:]|$)/.test(normalizedComment)) return 'tp';
  if (/^(?:\[sl\]|sl|stop[ -]+loss)(?:[\s:]|$)/.test(normalizedComment)) return 'sl';
  return 'unknown';
}

export function normalizeMt4Event(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new TypeError('Event must be a JSON object.');

  const eventId = text(raw.event_id, 200);
  if (!/^[A-Za-z0-9_.:-]{8,200}$/.test(eventId)) throw new TypeError('Invalid event_id.');

  const eventType = text(raw.event_type, 40);
  if (!MT4_EVENT_TYPES.has(eventType)) throw new TypeError('Unsupported event_type.');

  const accountRaw = raw.account && typeof raw.account === 'object' && !Array.isArray(raw.account) ? raw.account : {};
  const platform = text(accountRaw.platform || raw.platform || 'mt4', 8).toLowerCase() || 'mt4';
  if (!['mt4', 'mt5'].includes(platform)) throw new TypeError('Unsupported platform; expected mt4 or mt5.');
  const account = {
    platform,
    login: text(accountRaw.login, 32),
    server: text(accountRaw.server, 120),
    currency: text(accountRaw.currency, 3).toUpperCase(),
    balance: finite(accountRaw.balance),
    equity: finite(accountRaw.equity),
    floating_pl: finite(accountRaw.floating_pl),
    margin: finite(accountRaw.margin),
    free_margin: finite(accountRaw.free_margin),
    leverage: safeInteger(accountRaw.leverage)
  };
  if (!/^[0-9]{1,32}$/.test(account.login)) throw new TypeError('Invalid account login.');
  if (!account.server) throw new TypeError('Account server is required.');
  if (!/^[A-Z]{3}$/.test(account.currency)) throw new TypeError('Invalid account currency.');

  const rawOrder = raw.order && typeof raw.order === 'object' && !Array.isArray(raw.order) ? raw.order : {};
  const ticket = safeInteger(rawOrder.ticket);
  const order = {
    ticket,
    type: text(rawOrder.type, 24).toUpperCase(),
    symbol: text(rawOrder.symbol, 30).toUpperCase(),
    side: text(rawOrder.side, 8).toUpperCase(),
    lots: finite(rawOrder.lots),
    open_time: text(rawOrder.open_time, 40),
    close_time: text(rawOrder.close_time, 40),
    open_price: finite(rawOrder.open_price),
    close_price: finite(rawOrder.close_price),
    stop_loss: finite(rawOrder.stop_loss),
    take_profit: finite(rawOrder.take_profit),
    profit: finite(rawOrder.profit),
    swap: finite(rawOrder.swap),
    commission: finite(rawOrder.commission),
    net_profit: finite(rawOrder.net_profit),
    balance_amount: finite(rawOrder.balance_amount),
    magic: safeInteger(rawOrder.magic),
    comment: text(rawOrder.comment, 120),
    close_reason: eventType === 'trade_closed' ? explicitCloseReason(rawOrder.close_reason, rawOrder.comment) : 'unknown',
    expiration: text(rawOrder.expiration, 40)
  };

  if (!['terminal_online', 'account_snapshot'].includes(eventType) && ticket === null) throw new TypeError('A non-zero order ticket is required.');
  if (order.lots !== null && order.lots < 0) throw new TypeError('lots must be non-negative.');
  for (const [key, value] of Object.entries(order)) {
    if (typeof value === 'number' && !Number.isFinite(value)) throw new TypeError(`${key} must be finite.`);
  }
  if (eventType === 'trade_closed') {
    if (!order.symbol || !['BUY', 'SELL'].includes(order.side)) throw new TypeError('Closed trade requires symbol and BUY/SELL side.');
    if (!order.open_time || !order.close_time) throw new TypeError('Closed trade requires open_time and close_time.');
    if (order.lots === null || order.lots <= 0 || order.open_price === null || order.close_price === null || order.net_profit === null) {
      throw new TypeError('Closed trade requires lots, open/close prices, and net_profit.');
    }
  }
  if (eventType === 'balance_adjustment' && order.balance_amount === null) {
    throw new TypeError('Balance adjustment requires balance_amount.');
  }
  if (eventType === 'account_snapshot') {
    if (account.balance === null || account.equity === null || account.floating_pl === null) {
      throw new TypeError('Account snapshot requires balance, equity, and floating_pl.');
    }
  }

  const brokerTime = text(raw.broker_time, 40);
  const observedTime = text(raw.observed_time, 40);
  if (!brokerTime) throw new TypeError('broker_time is required.');

  return {
    event_id: eventId,
    event_type: eventType,
    broker_time: brokerTime,
    observed_time: observedTime,
    platform,
    account,
    order
  };
}

export function buildJournalTrade(event, receivedAt = new Date().toISOString()) {
  if (event.event_type !== 'trade_closed') throw new TypeError('Only closed trades create journal records.');
  const closeDate = event.order.close_time.slice(0, 10).replaceAll('.', '-');
  const tradeId = `mt4_${event.event_id}`.replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 180);
  return {
    id: tradeId,
    createdAt: receivedAt,
    updatedAt: receivedAt,
    closedAt: closeDate,
    openedAt: event.order.open_time,
    brokerCloseTime: event.order.close_time,
    brokerOpenTime: event.order.open_time,
    symbol: event.order.symbol,
    side: event.order.side.toLowerCase(),
    pnlUsd: Number(event.order.net_profit.toFixed(2)),
    accountCurrency: event.account.currency,
    lots: event.order.lots,
    entryPrice: event.order.open_price,
    exitPrice: event.order.close_price,
    stopLoss: event.order.stop_loss,
    takeProfit: event.order.take_profit,
    exitReason: event.order.close_reason,
    commission: event.order.commission,
    swap: event.order.swap,
    brokerProfit: event.order.profit,
    mt4Ticket: String(event.order.ticket),
    mt4Server: event.account.server,
    mt4Login: event.account.login,
    source: event.platform,
    platform: event.platform,
    sourceEventId: event.event_id,
    followedSop: '',
    snrTf: '',
    confirmTf: '',
    targetPips: null,
    collectedPips: null,
    setupId: '',
    planId: '',
    notes: '',
    stages: { before: [], during: [], after: [] },
    isDemo: false
  };
}
