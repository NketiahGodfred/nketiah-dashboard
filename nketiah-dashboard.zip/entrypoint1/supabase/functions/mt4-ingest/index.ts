import { createClient } from 'npm:@supabase/supabase-js@2';
import { createMt4Handler } from './handler.mjs';

const url = Deno.env.get('SUPABASE_URL') || '';
const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const token = Deno.env.get('MT4_INGEST_TOKEN') || '';
const configured = Boolean(url && serviceKey && token.length >= 24);
const supabase = configured ? createClient(url, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false }
}) : null;

Deno.serve(createMt4Handler({
  expectedToken: token,
  configured,
  async ingest(event) {
    if (!supabase) throw new Error('MT4 ingestion service is not configured.');
    const { data, error } = await supabase.rpc('ingest_mt4_event', { p_event: event });
    if (error) throw error;
    return data;
  },
  async ingestSnapshot(event) {
    if (!supabase) throw new Error('MT4 ingestion service is not configured.');
    const { data, error } = await supabase.rpc('ingest_mt4_account_snapshot', { p_event: event });
    if (error) throw error;
    return data;
  }
}));
