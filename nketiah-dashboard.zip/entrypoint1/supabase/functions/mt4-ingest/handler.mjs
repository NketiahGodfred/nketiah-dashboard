import { normalizeMt4Event } from './contract.mjs';

const MAX_BODY_BYTES = 32 * 1024;
const MAX_EVENTS = 1;

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff'
    }
  });
}

async function equalSecret(supplied, expected) {
  if (!supplied || !expected) return false;
  const encoder = new TextEncoder();
  const [left, right] = await Promise.all([
    crypto.subtle.digest('SHA-256', encoder.encode(supplied)),
    crypto.subtle.digest('SHA-256', encoder.encode(expected))
  ]);
  const a = new Uint8Array(left);
  const b = new Uint8Array(right);
  let diff = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a[i] || 0) ^ (b[i] || 0);
  return diff === 0;
}

export function createMt4Handler({ expectedToken = '', configured = true, ingest, ingestSnapshot = ingest }) {
  if (typeof ingest !== 'function' || typeof ingestSnapshot !== 'function') throw new TypeError('Ingest callbacks are required.');
  return async function handleMt4Request(req) {
    if (req.method === 'GET') return json({ service: 'nketiah-mt4-ingest', status: configured ? 'ready' : 'not-configured' });
    if (req.method !== 'POST') return json({ error: 'Method not allowed.' }, 405);
    if (!configured) return json({ error: 'MT4 ingestion service is not configured.' }, 503);

    const suppliedToken = req.headers.get('x-mt4-token') || '';
    if (!(await equalSecret(suppliedToken, expectedToken))) return json({ error: 'Unauthorized terminal.' }, 401);

    const contentLength = Number(req.headers.get('content-length') || 0);
    if (contentLength > MAX_BODY_BYTES) return json({ error: 'Request is too large.' }, 413);

    let raw;
    try {
      const bytes = new Uint8Array(await req.arrayBuffer());
      if (bytes.byteLength > MAX_BODY_BYTES) return json({ error: 'Request is too large.' }, 413);
      raw = JSON.parse(new TextDecoder().decode(bytes));
    } catch {
      return json({ error: 'Invalid JSON.' }, 400);
    }

    const events = Array.isArray(raw) ? raw : [raw];
    if (!events.length || events.length > MAX_EVENTS) return json({ error: 'Send exactly one event per request.' }, 400);

    let event;
    try {
      event = normalizeMt4Event(events[0]);
    } catch (error) {
      return json({ error: error instanceof Error ? error.message : 'Invalid MT4 event.' }, 400);
    }

    try {
      const result = event.event_type === 'account_snapshot' ? await ingestSnapshot(event) : await ingest(event);
      return json({ ok: true, result: result || null }, 200);
    } catch (error) {
      console.error('MT4 ingest RPC failed:', error?.code || 'unknown', error?.message || 'unknown');
      return json({ error: 'Event could not be saved.' }, 500);
    }
  };
}
