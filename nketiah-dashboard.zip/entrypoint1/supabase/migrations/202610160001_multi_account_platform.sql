-- Multi-account journals and the universal MT4/MT5 platform dimension.
--
-- 1) public.journal_snapshots gains account_key so every connected account owns its
--    own journal (trades, setups, plans, settings, revisions). The existing row is
--    migrated to account_key = 'manual' and keeps serving manual entries.
--    Journal keys are built identically in SQL and the webapp:
--      'manual'  ·  '<platform>:<login>@<server>'   e.g. 'mt4:1234567@Broker-Demo'
-- 2) public.mt4_account_events and public.mt4_account_snapshots gain platform
--    ('mt4' | 'mt5'); snapshot uniqueness becomes (owner, platform, login, server)
--    because MT4 and MT5 brokers can hand out the same login number.
-- 3) Ingest appends closed trades into the account's own journal instead of the
--    single owner journal, so accounts with different currencies can coexist.
--
-- Existing rows keep platform = 'mt4' (column default), which is correct: only the
-- MT4 EA existed before this migration.

-- ---------------------------------------------------------------------------
-- 1. Per-account journal snapshots
-- ---------------------------------------------------------------------------

alter table public.journal_snapshots
  add column if not exists account_key text not null default 'manual';

update public.journal_snapshots
   set account_key = 'manual'
 where account_key is null or account_key = '';

alter table public.journal_snapshots alter column account_key set not null;

alter table public.journal_snapshots drop constraint if exists journal_snapshots_account_key_format;
alter table public.journal_snapshots
  add constraint journal_snapshots_account_key_format check (char_length(account_key) between 1 and 200);

alter table public.journal_snapshots drop constraint if exists journal_snapshots_pkey;
alter table public.journal_snapshots add primary key (owner_id, account_key);

create index if not exists journal_snapshots_owner_updated_idx
  on public.journal_snapshots (owner_id, updated_at desc);

-- Owner-scoped revision-checked save, now per account journal.
drop function if exists public.save_journal_snapshot(bigint, jsonb);
drop function if exists public.save_journal_snapshot(bigint, jsonb, text);

create function public.save_journal_snapshot(
  p_expected_revision bigint,
  p_payload jsonb,
  p_account_key text default 'manual'
)
returns table (revision bigint, updated_at timestamptz)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_owner uuid := (select auth.uid());
  v_key text := nullif(btrim(coalesce(p_account_key, 'manual')), '');
  v_revision bigint;
  v_updated_at timestamptz;
begin
  if v_owner is null then
    raise exception 'Authentication required' using errcode = '28000';
  end if;
  if not public.is_journal_owner() then
    raise exception 'Owner access required' using errcode = '42501';
  end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'Journal payload must be a JSON object' using errcode = '22023';
  end if;
  if pg_column_size(p_payload) >= 8388608 then
    raise exception 'Journal payload exceeds the 8 MB limit' using errcode = '22001';
  end if;
  if v_key is null or char_length(v_key) > 200 then
    raise exception 'Invalid account journal key' using errcode = '22023';
  end if;

  select s.revision into v_revision
  from public.journal_snapshots as s
  where s.owner_id = v_owner
    and s.account_key = v_key
  for update;

  if not found then
    if coalesce(p_expected_revision, -1) <> 0 then
      raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
    end if;
    insert into public.journal_snapshots as inserted (owner_id, account_key, payload, revision, updated_at)
    values (v_owner, v_key, p_payload, 1, now())
    returning inserted.revision, inserted.updated_at into v_revision, v_updated_at;
  else
    if v_revision <> p_expected_revision then
      raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
    end if;
    update public.journal_snapshots as s
       set payload = p_payload,
           revision = s.revision + 1,
           updated_at = now()
     where s.owner_id = v_owner
       and s.account_key = v_key
       and s.revision = p_expected_revision
    returning s.revision, s.updated_at into v_revision, v_updated_at;
    if not found then
      raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
    end if;
  end if;

  return query select v_revision, v_updated_at;
exception
  when unique_violation then
    raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
end;
$$;

revoke all on function public.save_journal_snapshot(bigint, jsonb, text) from public, anon;
grant execute on function public.save_journal_snapshot(bigint, jsonb, text) to authenticated;

-- ---------------------------------------------------------------------------
-- 2. Platform column on the event ledger and the live dashboard
-- ---------------------------------------------------------------------------

alter table public.mt4_account_events
  add column if not exists platform text not null default 'mt4';
alter table public.mt4_account_events drop constraint if exists mt4_account_events_platform;
alter table public.mt4_account_events
  add constraint mt4_account_events_platform check (platform in ('mt4', 'mt5'));

create index if not exists mt4_account_events_owner_platform_idx
  on public.mt4_account_events (owner_id, platform, received_at desc);

alter table public.mt4_account_snapshots
  add column if not exists platform text not null default 'mt4';
alter table public.mt4_account_snapshots drop constraint if exists mt4_account_snapshots_platform;
alter table public.mt4_account_snapshots
  add constraint mt4_account_snapshots_platform check (platform in ('mt4', 'mt5'));

-- The same numeric login can exist on an MT4 and an MT5 server, so platform joins
-- the uniqueness key before any MT5 EA writes its first row.
alter table public.mt4_account_snapshots drop constraint if exists mt4_snapshot_owner_account_unique;
alter table public.mt4_account_snapshots
  add constraint mt4_snapshot_owner_account_unique unique (owner_id, platform, account_login, account_server);

create index if not exists mt4_account_snapshots_owner_platform_idx
  on public.mt4_account_snapshots (owner_id, platform, updated_at desc);

-- ---------------------------------------------------------------------------
-- 3. Per-account counters trigger (platform-aware conflict target)
-- ---------------------------------------------------------------------------

create or replace function private.bump_mt4_dashboard_counts()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_reason text := lower(coalesce(new.payload #>> '{order,close_reason}', 'unknown'));
  v_comment text := lower(coalesce(new.payload #>> '{order,comment}', ''));
  v_platform text := coalesce(nullif(btrim(coalesce(new.platform, '')), ''), 'mt4');
  v_tp boolean;
  v_sl boolean;
begin
  if new.event_type <> 'trade_closed' then
    return new;
  end if;
  v_tp := v_reason = 'tp' or v_comment ~ '^(\[tp\]([[:space:]:]|$)|tp([[:space:]:]|$)|take[[:space:]-]+profit([[:space:]:]|$))';
  v_sl := v_reason = 'sl' or v_comment ~ '^(\[sl\]([[:space:]:]|$)|sl([[:space:]:]|$)|stop[[:space:]-]+loss([[:space:]:]|$))';
  if (v_comment ~ '(^|[^[:alnum:]])(tp|take[[:space:]-]+profit)([^[:alnum:]]|$)'
      and v_comment ~ '(^|[^[:alnum:]])(sl|stop[[:space:]-]+loss)([^[:alnum:]]|$)')
     or (v_reason = 'tp' and v_comment ~ '(^|[^[:alnum:]])(sl|stop[[:space:]-]+loss)([^[:alnum:]]|$)')
     or (v_reason = 'sl' and v_comment ~ '(^|[^[:alnum:]])(tp|take[[:space:]-]+profit)([^[:alnum:]]|$)') then
    v_tp := false;
    v_sl := false;
  end if;

  insert into public.mt4_account_snapshots (
    owner_id, platform, account_login, account_server, account_currency,
    trade_close_count, long_close_count, short_close_count,
    take_profit_count, stop_loss_count, unclassified_close_count
  ) values (
    new.owner_id, v_platform, new.account_login, new.account_server, new.account_currency,
    1,
    case when lower(coalesce(new.payload #>> '{order,side}', '')) = 'buy' then 1 else 0 end,
    case when lower(coalesce(new.payload #>> '{order,side}', '')) = 'sell' then 1 else 0 end,
    case when v_tp then 1 else 0 end,
    case when v_sl then 1 else 0 end,
    case when v_tp or v_sl then 0 else 1 end
  ) on conflict (owner_id, platform, account_login, account_server) do update
    set account_currency = excluded.account_currency,
        trade_close_count = public.mt4_account_snapshots.trade_close_count + 1,
        long_close_count = public.mt4_account_snapshots.long_close_count + excluded.long_close_count,
        short_close_count = public.mt4_account_snapshots.short_close_count + excluded.short_close_count,
        take_profit_count = public.mt4_account_snapshots.take_profit_count + excluded.take_profit_count,
        stop_loss_count = public.mt4_account_snapshots.stop_loss_count + excluded.stop_loss_count,
        unclassified_close_count = public.mt4_account_snapshots.unclassified_close_count + excluded.unclassified_close_count;
  return new;
end;
$$;

revoke all on function private.bump_mt4_dashboard_counts() from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- 4. Platform-aware account snapshot upsert
-- ---------------------------------------------------------------------------

create or replace function public.ingest_mt4_account_snapshot(p_event jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_owner uuid;
  v_event_id text;
  v_platform text;
  v_login text;
  v_server text;
  v_currency text;
  v_observed_at text;
  v_balance numeric;
  v_equity numeric;
  v_floating_pl numeric;
  v_margin numeric;
  v_free_margin numeric;
  v_leverage integer;
  v_rows integer;
begin
  if p_event is null or jsonb_typeof(p_event) <> 'object'
     or p_event->>'event_type' <> 'account_snapshot'
     or jsonb_typeof(p_event->'account') <> 'object' then
    raise exception 'Invalid MT4 account snapshot' using errcode = '22023';
  end if;

  select owner_record.owner_id into v_owner
    from private.journal_owner as owner_record
   where owner_record.singleton = true;
  if v_owner is null then
    raise exception 'Private journal owner is not configured' using errcode = '55000';
  end if;

  v_event_id := btrim(coalesce(p_event->>'event_id', ''));
  v_platform := lower(coalesce(nullif(btrim(coalesce(p_event #>> '{account,platform}', p_event->>'platform', '')), ''), 'mt4'));
  v_login := btrim(coalesce(p_event #>> '{account,login}', ''));
  v_server := btrim(coalesce(p_event #>> '{account,server}', ''));
  v_currency := upper(btrim(coalesce(p_event #>> '{account,currency}', '')));
  v_observed_at := btrim(coalesce(p_event->>'observed_time', p_event->>'broker_time', ''));
  if v_event_id !~ '^[A-Za-z0-9_.:-]{8,200}$'
     or v_platform not in ('mt4', 'mt5')
     or v_login !~ '^[0-9]{1,32}$' or v_server = ''
     or v_currency !~ '^[A-Z]{3}$' or v_observed_at = '' then
    raise exception 'Invalid MT4 account snapshot metadata' using errcode = '22023';
  end if;
  if jsonb_typeof(p_event #> '{account,balance}') <> 'number'
     or jsonb_typeof(p_event #> '{account,equity}') <> 'number'
     or jsonb_typeof(p_event #> '{account,floating_pl}') <> 'number' then
    raise exception 'Balance, equity, and floating P/L are required' using errcode = '22023';
  end if;

  v_balance := (p_event #>> '{account,balance}')::numeric;
  v_equity := (p_event #>> '{account,equity}')::numeric;
  v_floating_pl := (p_event #>> '{account,floating_pl}')::numeric;
  v_margin := nullif(p_event #>> '{account,margin}', '')::numeric;
  v_free_margin := nullif(p_event #>> '{account,free_margin}', '')::numeric;
  v_leverage := nullif(p_event #>> '{account,leverage}', '')::integer;

  insert into public.mt4_account_snapshots (
    owner_id, platform, account_login, account_server, account_currency,
    balance, equity, floating_pl, margin, free_margin, leverage,
    last_event_id, observed_at, updated_at
  ) values (
    v_owner, v_platform, v_login, v_server, v_currency,
    v_balance, v_equity, v_floating_pl, v_margin, v_free_margin, v_leverage,
    v_event_id, v_observed_at, now()
  ) on conflict (owner_id, platform, account_login, account_server) do update
    set account_currency = excluded.account_currency,
        balance = excluded.balance,
        equity = excluded.equity,
        floating_pl = excluded.floating_pl,
        margin = excluded.margin,
        free_margin = excluded.free_margin,
        leverage = excluded.leverage,
        last_event_id = excluded.last_event_id,
        observed_at = excluded.observed_at,
        updated_at = now()
    where public.mt4_account_snapshots.last_event_id is distinct from excluded.last_event_id;

  get diagnostics v_rows = row_count;
  return jsonb_build_object(
    'accepted', true,
    'duplicate', v_rows = 0,
    'event_id', v_event_id
  );
end;
$$;

revoke all on function public.ingest_mt4_account_snapshot(jsonb) from public, anon, authenticated;
grant execute on function public.ingest_mt4_account_snapshot(jsonb) to service_role;

-- ---------------------------------------------------------------------------
-- 5. Platform-aware event ingest that appends into the account's own journal
-- ---------------------------------------------------------------------------

create or replace function public.ingest_mt4_event(p_event jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_owner uuid;
  v_event_id text;
  v_event_type text;
  v_platform text;
  v_login text;
  v_server text;
  v_currency text;
  v_account_key text;
  v_ticket bigint;
  v_symbol text;
  v_broker_time text;
  v_order jsonb;
  v_row_count integer;
  v_payload jsonb;
  v_revision bigint;
  v_updated_at timestamptz;
  v_trade jsonb;
  v_close_text text;
  v_close_date text;
  v_old_currency text;
  v_now timestamptz := now();
begin
  if p_event is null or jsonb_typeof(p_event) <> 'object' then
    raise exception 'MT4 event must be a JSON object' using errcode = '22023';
  end if;

  select owner_record.owner_id into v_owner
    from private.journal_owner as owner_record where owner_record.singleton = true;
  if v_owner is null then
    raise exception 'Private journal owner is not configured' using errcode = '55000';
  end if;

  v_event_id := btrim(coalesce(p_event->>'event_id', ''));
  v_event_type := btrim(coalesce(p_event->>'event_type', ''));
  v_platform := lower(coalesce(nullif(btrim(coalesce(p_event #>> '{account,platform}', p_event->>'platform', '')), ''), 'mt4'));
  v_login := btrim(coalesce(p_event #>> '{account,login}', ''));
  v_server := btrim(coalesce(p_event #>> '{account,server}', ''));
  v_currency := upper(btrim(coalesce(p_event #>> '{account,currency}', '')));
  v_broker_time := btrim(coalesce(p_event->>'broker_time', ''));
  v_order := coalesce(p_event->'order', '{}'::jsonb);
  v_ticket := nullif(v_order->>'ticket', '')::bigint;
  v_symbol := upper(btrim(coalesce(v_order->>'symbol', '')));

  if v_event_id !~ '^[A-Za-z0-9_.:-]{8,200}$' then
    raise exception 'Invalid MT4 event id' using errcode = '22023';
  end if;
  if v_event_type not in (
    'terminal_online', 'order_baseline', 'order_opened', 'pending_order_placed',
    'pending_order_activated', 'order_modified', 'pending_order_cancelled',
    'trade_closed', 'balance_adjustment'
  ) then
    raise exception 'Unsupported MT4 event type' using errcode = '22023';
  end if;
  if v_platform not in ('mt4', 'mt5') then
    raise exception 'Unsupported trading platform' using errcode = '22023';
  end if;
  if v_login !~ '^[0-9]{1,32}$' or v_server = '' or v_currency !~ '^[A-Z]{3}$' or v_broker_time = '' then
    raise exception 'Invalid MT4 account metadata' using errcode = '22023';
  end if;
  if v_event_type <> 'terminal_online' and (v_ticket is null or v_ticket < 0) then
    raise exception 'MT4 ticket is required' using errcode = '22023';
  end if;
  if char_length(v_platform || ':' || v_login || '@' || v_server) > 200 then
    raise exception 'Account journal key is too long' using errcode = '22023';
  end if;
  v_account_key := v_platform || ':' || v_login || '@' || v_server;

  if v_event_type = 'trade_closed' then
    if v_symbol = '' or upper(coalesce(v_order->>'side', '')) not in ('BUY', 'SELL')
       or coalesce(v_order->>'open_time', '') = ''
       or coalesce(v_order->>'close_time', '') = ''
       or nullif(v_order->>'lots', '') is null
       or (v_order->>'lots')::numeric <= 0
       or nullif(v_order->>'open_price', '') is null
       or nullif(v_order->>'close_price', '') is null
       or nullif(v_order->>'net_profit', '') is null then
      raise exception 'Closed trade is missing required order data' using errcode = '22023';
    end if;
    if lower(coalesce(v_order->>'close_reason', 'unknown')) not in ('tp', 'sl', 'unknown') then
      raise exception 'Invalid MT4 close reason' using errcode = '22023';
    end if;
    v_close_text := v_order->>'close_time';
    v_close_date := replace(substr(v_close_text, 1, 10), '.', '-');
    if v_close_date !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then
      raise exception 'Invalid MT4 close date' using errcode = '22023';
    end if;
  elsif v_event_type = 'balance_adjustment' then
    if nullif(v_order->>'balance_amount', '') is null then
      raise exception 'Balance adjustment amount is required' using errcode = '22023';
    end if;
  end if;

  insert into public.mt4_account_events (
    owner_id, event_id, event_type, platform, account_login, account_server,
    account_currency, ticket, symbol, broker_time, payload
  ) values (
    v_owner, v_event_id, v_event_type, v_platform, v_login, v_server,
    v_currency, v_ticket, nullif(v_symbol, ''), v_broker_time, p_event
  ) on conflict (owner_id, event_id) do nothing;
  get diagnostics v_row_count = row_count;
  if v_row_count = 0 then
    return jsonb_build_object('accepted', true, 'duplicate', true, 'event_id', v_event_id);
  end if;

  if v_event_type = 'trade_closed' then
    -- Each connected account owns its own journal row, so accounts with different
    -- base currencies never share a payload or a revision counter.
    select snapshot.payload, snapshot.revision into v_payload, v_revision
      from public.journal_snapshots as snapshot
     where snapshot.owner_id = v_owner
       and snapshot.account_key = v_account_key
     for update;
    if not found then
      v_payload := '{"version":1,"trades":[],"setups":[],"plans":[],"aiReviews":[],"settings":{}}'::jsonb;
      v_revision := 0;
    end if;
    if jsonb_typeof(v_payload->'trades') is distinct from 'array' then
      v_payload := jsonb_set(v_payload, '{trades}', '[]'::jsonb, true);
    end if;
    if jsonb_typeof(v_payload->'settings') is distinct from 'object' then
      v_payload := jsonb_set(v_payload, '{settings}', '{}'::jsonb, true);
    end if;

    v_old_currency := upper(coalesce(nullif(v_payload #>> '{settings,accountCurrency}', ''), ''));
    if v_old_currency <> '' and v_old_currency <> v_currency then
      raise exception 'MT4 account currency does not match the journal currency' using errcode = '22023';
    end if;
    if v_old_currency = '' then
      v_payload := jsonb_set(v_payload, '{settings,accountCurrency}', to_jsonb(v_currency), true);
    end if;

    v_trade := jsonb_build_object(
      'id', 'mt4_' || left(regexp_replace(v_event_id, '[^A-Za-z0-9_-]', '_', 'g'), 176),
      'createdAt', v_now,
      'updatedAt', v_now,
      'closedAt', v_close_date,
      'openedAt', v_order->>'open_time',
      'brokerOpenTime', v_order->>'open_time',
      'brokerCloseTime', v_order->>'close_time',
      'symbol', v_symbol,
      'side', lower(v_order->>'side'),
      'pnlUsd', round((v_order->>'net_profit')::numeric, 2),
      'accountCurrency', v_currency,
      'lots', (v_order->>'lots')::numeric,
      'entryPrice', (v_order->>'open_price')::numeric,
      'exitPrice', (v_order->>'close_price')::numeric,
      'stopLoss', nullif(v_order->>'stop_loss', '')::numeric,
      'takeProfit', nullif(v_order->>'take_profit', '')::numeric,
      'exitReason', lower(coalesce(v_order->>'close_reason', 'unknown')),
      'commission', nullif(v_order->>'commission', '')::numeric,
      'swap', nullif(v_order->>'swap', '')::numeric,
      'brokerProfit', nullif(v_order->>'profit', '')::numeric,
      'mt4Ticket', coalesce(v_order->>'ticket', ''),
      'mt4Server', v_server,
      'mt4Login', v_login,
      'source', v_platform,
      'platform', v_platform,
      'sourceEventId', v_event_id,
      'followedSop', '',
      'snrTf', '',
      'confirmTf', '',
      'targetPips', null,
      'collectedPips', null,
      'setupId', '',
      'planId', '',
      'notes', '',
      'stages', '{"before":[],"during":[],"after":[]}'::jsonb,
      'isDemo', false
    );
    v_payload := jsonb_set(v_payload, '{trades}', (v_payload->'trades') || jsonb_build_array(v_trade), true);

    if v_revision = 0 and not exists (
      select 1 from public.journal_snapshots as snapshot
       where snapshot.owner_id = v_owner and snapshot.account_key = v_account_key
    ) then
      insert into public.journal_snapshots (owner_id, account_key, payload, revision, updated_at)
      values (v_owner, v_account_key, v_payload, 1, v_now);
      v_revision := 1;
    else
      update public.journal_snapshots as snapshot
         set payload = v_payload,
             revision = snapshot.revision + 1,
             updated_at = v_now
       where snapshot.owner_id = v_owner
         and snapshot.account_key = v_account_key
      returning snapshot.revision, snapshot.updated_at into v_revision, v_updated_at;
      if not found then
        raise exception 'MT4 journal append failed' using errcode = '40001';
      end if;
    end if;
  end if;

  return jsonb_build_object(
    'accepted', true,
    'duplicate', false,
    'event_id', v_event_id,
    'event_type', v_event_type,
    'platform', v_platform,
    'account_key', v_account_key,
    'journal_revision', v_revision
  );
end;
$$;

revoke all on function public.ingest_mt4_event(jsonb) from public, anon, authenticated;
grant execute on function public.ingest_mt4_event(jsonb) to service_role;
