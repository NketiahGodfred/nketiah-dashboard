-- Nketiah Journal private sync foundation.
-- Apply with Supabase CLI/db push or paste into the SQL Editor.
-- The browser receives only the publishable key. Never ship a secret/service-role key.
-- After the owner's Google user exists, seed private.journal_owner once with that auth.users UUID.

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create table if not exists private.journal_owner (
  singleton boolean primary key default true check (singleton),
  owner_id uuid not null unique references auth.users (id) on delete cascade
);
revoke all on private.journal_owner from public, anon, authenticated;

create or replace function public.is_journal_owner()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from private.journal_owner as owner_record
    where owner_record.owner_id = (select auth.uid())
  );
$$;
revoke all on function public.is_journal_owner() from public, anon;
grant execute on function public.is_journal_owner() to authenticated;

create table if not exists public.journal_snapshots (
  owner_id uuid primary key references auth.users (id) on delete cascade,
  payload jsonb not null default '{"version":1,"trades":[],"setups":[],"plans":[],"settings":{}}'::jsonb,
  revision bigint not null default 0 check (revision >= 0),
  updated_at timestamptz not null default now(),
  constraint journal_snapshots_payload_object check (jsonb_typeof(payload) = 'object'),
  constraint journal_snapshots_payload_size check (pg_column_size(payload) < 8388608)
);

alter table public.journal_snapshots enable row level security;
alter table public.journal_snapshots force row level security;

grant select, insert, update on public.journal_snapshots to authenticated;
revoke all on public.journal_snapshots from anon;

create policy "journal snapshot owner select"
on public.journal_snapshots for select to authenticated
using (public.is_journal_owner() and (select auth.uid()) = owner_id);

create policy "journal snapshot owner insert"
on public.journal_snapshots for insert to authenticated
with check (public.is_journal_owner() and (select auth.uid()) = owner_id);

create policy "journal snapshot owner update"
on public.journal_snapshots for update to authenticated
using (public.is_journal_owner() and (select auth.uid()) = owner_id)
with check (public.is_journal_owner() and (select auth.uid()) = owner_id);

-- Optimistic revision check prevents one device silently overwriting newer cloud data.
create or replace function public.save_journal_snapshot(
  p_expected_revision bigint,
  p_payload jsonb
)
returns table (revision bigint, updated_at timestamptz)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_owner uuid := (select auth.uid());
  v_revision bigint;
  v_updated_at timestamptz;
begin
  if v_owner is null then
    raise exception 'Authentication required' using errcode = '28000';
  end if;
  if not public.is_journal_owner() then
    raise exception 'Owner access required' using errcode = '42501';
  end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'Journal payload must be a JSON object' using errcode = '22023';
  end if;
  if pg_column_size(p_payload) >= 8388608 then
    raise exception 'Journal payload exceeds the 8 MB limit' using errcode = '22001';
  end if;

  select s.revision into v_revision
  from public.journal_snapshots as s
  where s.owner_id = v_owner
  for update;

  if not found then
    if coalesce(p_expected_revision, -1) <> 0 then
      raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
    end if;
    insert into public.journal_snapshots as inserted (owner_id, payload, revision, updated_at)
    values (v_owner, p_payload, 1, now())
    returning inserted.revision, inserted.updated_at into v_revision, v_updated_at;
  else
    if v_revision <> p_expected_revision then
      raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
    end if;
    update public.journal_snapshots as s
       set payload = p_payload,
           revision = s.revision + 1,
           updated_at = now()
     where s.owner_id = v_owner
       and s.revision = p_expected_revision
    returning s.revision, s.updated_at into v_revision, v_updated_at;
    if not found then
      raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
    end if;
  end if;

  return query select v_revision, v_updated_at;
exception
  when unique_violation then
    raise exception 'JOURNAL_CONFLICT' using errcode = '40001';
end;
$$;

revoke all on function public.save_journal_snapshot(bigint, jsonb) from public, anon;
grant execute on function public.save_journal_snapshot(bigint, jsonb) to authenticated;

-- Private chart image bucket. Object names must start with the authenticated user's UUID.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('journal-images', 'journal-images', false, 10485760, array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set
  public = false,
  file_size_limit = 10485760,
  allowed_mime_types = array['image/png','image/jpeg','image/webp'];

create policy "journal images owner select"
on storage.objects for select to authenticated
using (
  bucket_id = 'journal-images'
  and public.is_journal_owner()
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "journal images owner insert"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'journal-images'
  and public.is_journal_owner()
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "journal images owner update"
on storage.objects for update to authenticated
using (
  bucket_id = 'journal-images'
  and public.is_journal_owner()
  and (storage.foldername(name))[1] = (select auth.uid())::text
)
with check (
  bucket_id = 'journal-images'
  and public.is_journal_owner()
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "journal images owner delete"
on storage.objects for delete to authenticated
using (
  bucket_id = 'journal-images'
  and public.is_journal_owner()
  and (storage.foldername(name))[1] = (select auth.uid())::text
);
