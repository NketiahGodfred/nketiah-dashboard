-- MT4 account-wide event ingestion.
-- The EA never receives a Supabase database key. Only the mt4-ingest Edge Function
-- may call ingest_mt4_event; authenticated owner sessions may read their own event ledger.

create table if not exists public.mt4_account_events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users (id) on delete cascade,
  event_id text not null,
  event_type text not null check (event_type in (
    'terminal_online', 'order_baseline', 'order_opened', 'pending_order_placed',
    'pending_order_activated', 'order_modified', 'pending_order_cancelled',
    'trade_closed', 'balance_adjustment'
  )),
  account_login text not null,
  account_server text not null,
  account_currency text not null check (account_currency ~ '^[A-Z]{3}$'),
  ticket bigint,
  symbol text,
  broker_time text not null,
  received_at timestamptz not null default now(),
  payload jsonb not null,
  constraint mt4_event_id_length check (length(event_id) between 8 and 200),
  constraint mt4_payload_object check (jsonb_typeof(payload) = 'object'),
  constraint mt4_event_dedupe unique (owner_id, event_id)
);

create index if not exists mt4_account_events_owner_time_idx
  on public.mt4_account_events (owner_id, received_at desc);
create index if not exists mt4_account_events_owner_type_idx
  on public.mt4_account_events (owner_id, event_type, received_at desc);

alter table public.mt4_account_events enable row level security;
alter table public.mt4_account_events force row level security;
revoke all on public.mt4_account_events from public, anon;
grant select on public.mt4_account_events to authenticated;

create policy "MT4 activity is visible only to the journal owner"
on public.mt4_account_events for select to authenticated
using (public.is_journal_owner() and (select auth.uid()) = owner_id);

create or replace function public.ingest_mt4_event(p_event jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_owner uuid;
  v_event_id text;
  v_event_type text;
  v_login text;
  v_server text;
  v_currency text;
  v_ticket bigint;
  v_symbol text;
  v_broker_time text;
  v_order jsonb;
  v_row_count integer;
  v_payload jsonb;
  v_revision bigint;
  v_updated_at timestamptz;
  v_trade jsonb;
  v_close_text text;
  v_close_date text;
  v_old_currency text;
  v_now timestamptz := now();
begin
  if p_event is null or jsonb_typeof(p_event) <> 'object' then
    raise exception 'MT4 event must be a JSON object' using errcode = '22023';
  end if;

  select owner_record.owner_id
    into v_owner
    from private.journal_owner as owner_record
   where owner_record.singleton = true;
  if v_owner is null then
    raise exception 'Private journal owner is not configured' using errcode = '55000';
  end if;

  v_event_id := btrim(coalesce(p_event->>'event_id', ''));
  v_event_type := btrim(coalesce(p_event->>'event_type', ''));
  v_login := btrim(coalesce(p_event #>> '{account,login}', ''));
  v_server := btrim(coalesce(p_event #>> '{account,server}', ''));
  v_currency := upper(btrim(coalesce(p_event #>> '{account,currency}', '')));
  v_broker_time := btrim(coalesce(p_event->>'broker_time', ''));
  v_order := coalesce(p_event->'order', '{}'::jsonb);
  v_ticket := nullif(v_order->>'ticket', '')::bigint;
  v_symbol := upper(btrim(coalesce(v_order->>'symbol', '')));

  if v_event_id !~ '^[A-Za-z0-9_.:-]{8,200}$' then
    raise exception 'Invalid MT4 event id' using errcode = '22023';
  end if;
  if v_event_type not in (
    'terminal_online', 'order_baseline', 'order_opened', 'pending_order_placed',
    'pending_order_activated', 'order_modified', 'pending_order_cancelled',
    'trade_closed', 'balance_adjustment'
  ) then
    raise exception 'Unsupported MT4 event type' using errcode = '22023';
  end if;
  if v_login !~ '^[0-9]{1,32}$' or v_server = '' or v_currency !~ '^[A-Z]{3}$' or v_broker_time = '' then
    raise exception 'Invalid MT4 account metadata' using errcode = '22023';
  end if;
  if v_event_type <> 'terminal_online' and (v_ticket is null or v_ticket < 0) then
    raise exception 'MT4 ticket is required' using errcode = '22023';
  end if;

  if v_event_type = 'trade_closed' then
    if v_symbol = '' or upper(coalesce(v_order->>'side', '')) not in ('BUY', 'SELL')
       or coalesce(v_order->>'open_time', '') = ''
       or coalesce(v_order->>'close_time', '') = ''
       or nullif(v_order->>'lots', '') is null
       or (v_order->>'lots')::numeric <= 0
       or nullif(v_order->>'open_price', '') is null
       or nullif(v_order->>'close_price', '') is null
       or nullif(v_order->>'net_profit', '') is null then
      raise exception 'Closed trade is missing required order data' using errcode = '22023';
    end if;
    v_close_text := v_order->>'close_time';
    v_close_date := replace(substr(v_close_text, 1, 10), '.', '-');
    if v_close_date !~ '^\d{4}-\d{2}-\d{2}$' then
      raise exception 'Invalid MT4 close date' using errcode = '22023';
    end if;
  elsif v_event_type = 'balance_adjustment' then
    if nullif(v_order->>'balance_amount', '') is null then
      raise exception 'Balance adjustment amount is required' using errcode = '22023';
    end if;
  end if;

  insert into public.mt4_account_events (
    owner_id, event_id, event_type, account_login, account_server,
    account_currency, ticket, symbol, broker_time, payload
  ) values (
    v_owner, v_event_id, v_event_type, v_login, v_server,
    v_currency, v_ticket, nullif(v_symbol, ''), v_broker_time, p_event
  ) on conflict (owner_id, event_id) do nothing;

  get diagnostics v_row_count = row_count;
  if v_row_count = 0 then
    return jsonb_build_object('accepted', true, 'duplicate', true, 'event_id', v_event_id);
  end if;

  if v_event_type = 'trade_closed' then
    select snapshot.payload, snapshot.revision
      into v_payload, v_revision
      from public.journal_snapshots as snapshot
     where snapshot.owner_id = v_owner
     for update;

    if not found then
      v_payload := '{"version":1,"trades":[],"setups":[],"plans":[],"aiReviews":[],"settings":{}}'::jsonb;
      v_revision := 0;
    end if;

    if jsonb_typeof(v_payload->'trades') is distinct from 'array' then
      v_payload := jsonb_set(v_payload, '{trades}', '[]'::jsonb, true);
    end if;
    if jsonb_typeof(v_payload->'settings') is distinct from 'object' then
      v_payload := jsonb_set(v_payload, '{settings}', '{}'::jsonb, true);
    end if;

    v_old_currency := upper(coalesce(nullif(v_payload #>> '{settings,accountCurrency}', ''), ''));
    if v_old_currency <> '' and v_old_currency <> v_currency then
      raise exception 'MT4 account currency does not match the journal currency' using errcode = '22023';
    end if;
    if v_old_currency = '' then
      v_payload := jsonb_set(v_payload, '{settings,accountCurrency}', to_jsonb(v_currency), true);
    end if;

    v_trade := jsonb_build_object(
      'id', 'mt4_' || left(regexp_replace(v_event_id, '[^A-Za-z0-9_-]', '_', 'g'), 176),
      'createdAt', v_now,
      'updatedAt', v_now,
      'closedAt', v_close_date,
      'openedAt', v_order->>'open_time',
      'brokerOpenTime', v_order->>'open_time',
      'brokerCloseTime', v_order->>'close_time',
      'symbol', v_symbol,
      'side', lower(v_order->>'side'),
      'pnlUsd', round((v_order->>'net_profit')::numeric, 2),
      'accountCurrency', v_currency,
      'lots', (v_order->>'lots')::numeric,
      'entryPrice', (v_order->>'open_price')::numeric,
      'exitPrice', (v_order->>'close_price')::numeric,
      'stopLoss', nullif(v_order->>'stop_loss', '')::numeric,
      'takeProfit', nullif(v_order->>'take_profit', '')::numeric,
      'commission', nullif(v_order->>'commission', '')::numeric,
      'swap', nullif(v_order->>'swap', '')::numeric,
      'brokerProfit', nullif(v_order->>'profit', '')::numeric,
      'mt4Ticket', coalesce(v_order->>'ticket', ''),
      'mt4Server', v_server,
      'mt4Login', v_login,
      'source', 'mt4',
      'sourceEventId', v_event_id,
      'followedSop', '',
      'snrTf', '',
      'confirmTf', '',
      'targetPips', null,
      'collectedPips', null,
      'setupId', '',
      'planId', '',
      'notes', '',
      'stages', '{"before":[],"during":[],"after":[]}'::jsonb,
      'isDemo', false
    );

    v_payload := jsonb_set(
      v_payload,
      '{trades}',
      (v_payload->'trades') || jsonb_build_array(v_trade),
      true
    );

    if v_revision = 0 and not exists (
      select 1 from public.journal_snapshots as snapshot where snapshot.owner_id = v_owner
    ) then
      insert into public.journal_snapshots (owner_id, payload, revision, updated_at)
      values (v_owner, v_payload, 1, v_now);
      v_revision := 1;
    else
      update public.journal_snapshots as snapshot
         set payload = v_payload,
             revision = snapshot.revision + 1,
             updated_at = v_now
       where snapshot.owner_id = v_owner
      returning snapshot.revision, snapshot.updated_at into v_revision, v_updated_at;
      if not found then
        raise exception 'MT4 journal append failed' using errcode = '40001';
      end if;
    end if;
  end if;

  return jsonb_build_object(
    'accepted', true,
    'duplicate', false,
    'event_id', v_event_id,
    'event_type', v_event_type,
    'journal_revision', v_revision
  );
end;
$$;

revoke all on function public.ingest_mt4_event(jsonb) from public, anon, authenticated;
grant execute on function public.ingest_mt4_event(jsonb) to service_role;
