-- Live MT4 account snapshot and compact close-outcome counters.
-- Snapshots are overwritten in place; they do not create an unbounded event stream.
-- Only the private ingestion functions may write. The authenticated journal owner may read.

create table if not exists public.mt4_account_snapshots (
  owner_id uuid not null references auth.users (id) on delete cascade,
  account_login text not null,
  account_server text not null,
  account_currency text not null check (account_currency ~ '^[A-Z]{3}$'),
  balance numeric,
  equity numeric,
  floating_pl numeric,
  margin numeric,
  free_margin numeric,
  leverage integer,
  last_event_id text,
  observed_at text,
  updated_at timestamptz not null default now(),
  trade_close_count bigint not null default 0,
  long_close_count bigint not null default 0,
  short_close_count bigint not null default 0,
  take_profit_count bigint not null default 0,
  stop_loss_count bigint not null default 0,
  unclassified_close_count bigint not null default 0,
  constraint mt4_snapshot_owner_account_unique unique (owner_id, account_login, account_server),
  constraint mt4_snapshot_counts_nonnegative check (
    trade_close_count >= 0 and long_close_count >= 0 and short_close_count >= 0
    and take_profit_count >= 0 and stop_loss_count >= 0 and unclassified_close_count >= 0
  )
);

create index if not exists mt4_account_snapshots_owner_updated_idx
  on public.mt4_account_snapshots (owner_id, updated_at desc);

alter table public.mt4_account_snapshots enable row level security;
alter table public.mt4_account_snapshots force row level security;
revoke all on public.mt4_account_snapshots from public, anon;
grant select on public.mt4_account_snapshots to authenticated;

drop policy if exists "MT4 dashboard is visible only to the journal owner" on public.mt4_account_snapshots;
create policy "MT4 dashboard is visible only to the journal owner"
on public.mt4_account_snapshots for select to authenticated
using (public.is_journal_owner() and (select auth.uid()) = owner_id);

-- Existing closed events become the initial all-time counters.
-- Only explicit close_reason values or anchored broker-style TP/SL comments count.
-- If both tokens appear anywhere in a comment or conflict with close_reason,
-- that legacy event is unclassified, never both.
with comment_evidence as (
  select
    event.owner_id,
    event.account_login,
    event.account_server,
    event.account_currency,
    event.payload,
    lower(coalesce(event.payload #>> '{order,close_reason}', '')) as explicit_reason,
    lower(coalesce(event.payload #>> '{order,close_reason}', '')) = 'tp'
      or lower(coalesce(event.payload #>> '{order,comment}', '')) ~ '^(\[tp\]([[:space:]:]|$)|tp([[:space:]:]|$)|take[[:space:]-]+profit([[:space:]:]|$))' as says_tp,
    lower(coalesce(event.payload #>> '{order,close_reason}', '')) = 'sl'
      or lower(coalesce(event.payload #>> '{order,comment}', '')) ~ '^(\[sl\]([[:space:]:]|$)|sl([[:space:]:]|$)|stop[[:space:]-]+loss([[:space:]:]|$))' as says_sl,
    lower(coalesce(event.payload #>> '{order,comment}', '')) ~ '(^|[^[:alnum:]])(tp|take[[:space:]-]+profit)([^[:alnum:]]|$)' as mentions_tp,
    lower(coalesce(event.payload #>> '{order,comment}', '')) ~ '(^|[^[:alnum:]])(sl|stop[[:space:]-]+loss)([^[:alnum:]]|$)' as mentions_sl
  from public.mt4_account_events as event
  where event.event_type = 'trade_closed'
), exit_evidence as (
  select *,
    (mentions_tp and mentions_sl)
    or (explicit_reason = 'tp' and mentions_sl)
    or (explicit_reason = 'sl' and mentions_tp) as ambiguous
  from comment_evidence
)
insert into public.mt4_account_snapshots (
  owner_id, account_login, account_server, account_currency,
  trade_close_count, long_close_count, short_close_count,
  take_profit_count, stop_loss_count, unclassified_close_count
)
select
  evidence.owner_id,
  evidence.account_login,
  evidence.account_server,
  max(evidence.account_currency),
  count(*)::bigint,
  count(*) filter (where lower(coalesce(evidence.payload #>> '{order,side}', '')) = 'buy')::bigint,
  count(*) filter (where lower(coalesce(evidence.payload #>> '{order,side}', '')) = 'sell')::bigint,
  count(*) filter (where evidence.says_tp and not evidence.says_sl and not evidence.ambiguous)::bigint,
  count(*) filter (where evidence.says_sl and not evidence.says_tp and not evidence.ambiguous)::bigint,
  count(*) filter (where evidence.ambiguous or evidence.says_tp = evidence.says_sl)::bigint
from exit_evidence as evidence
group by evidence.owner_id, evidence.account_login, evidence.account_server
on conflict (owner_id, account_login, account_server) do update
set account_currency = excluded.account_currency,
    trade_close_count = excluded.trade_close_count,
    long_close_count = excluded.long_close_count,
    short_close_count = excluded.short_close_count,
    take_profit_count = excluded.take_profit_count,
    stop_loss_count = excluded.stop_loss_count,
    unclassified_close_count = excluded.unclassified_close_count;

create or replace function private.bump_mt4_dashboard_counts()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_reason text := lower(coalesce(new.payload #>> '{order,close_reason}', 'unknown'));
  v_comment text := lower(coalesce(new.payload #>> '{order,comment}', ''));
  v_tp boolean;
  v_sl boolean;
begin
  if new.event_type <> 'trade_closed' then
    return new;
  end if;
  v_tp := v_reason = 'tp' or v_comment ~ '^(\[tp\]([[:space:]:]|$)|tp([[:space:]:]|$)|take[[:space:]-]+profit([[:space:]:]|$))';
  v_sl := v_reason = 'sl' or v_comment ~ '^(\[sl\]([[:space:]:]|$)|sl([[:space:]:]|$)|stop[[:space:]-]+loss([[:space:]:]|$))';
  if (v_comment ~ '(^|[^[:alnum:]])(tp|take[[:space:]-]+profit)([^[:alnum:]]|$)'
      and v_comment ~ '(^|[^[:alnum:]])(sl|stop[[:space:]-]+loss)([^[:alnum:]]|$)')
     or (v_reason = 'tp' and v_comment ~ '(^|[^[:alnum:]])(sl|stop[[:space:]-]+loss)([^[:alnum:]]|$)')
     or (v_reason = 'sl' and v_comment ~ '(^|[^[:alnum:]])(tp|take[[:space:]-]+profit)([^[:alnum:]]|$)') then
    v_tp := false;
    v_sl := false;
  end if;

  insert into public.mt4_account_snapshots (
    owner_id, account_login, account_server, account_currency,
    trade_close_count, long_close_count, short_close_count,
    take_profit_count, stop_loss_count, unclassified_close_count
  ) values (
    new.owner_id, new.account_login, new.account_server, new.account_currency,
    1,
    case when lower(coalesce(new.payload #>> '{order,side}', '')) = 'buy' then 1 else 0 end,
    case when lower(coalesce(new.payload #>> '{order,side}', '')) = 'sell' then 1 else 0 end,
    case when v_tp then 1 else 0 end,
    case when v_sl then 1 else 0 end,
    case when v_tp or v_sl then 0 else 1 end
  ) on conflict (owner_id, account_login, account_server) do update
    set account_currency = excluded.account_currency,
        trade_close_count = public.mt4_account_snapshots.trade_close_count + 1,
        long_close_count = public.mt4_account_snapshots.long_close_count + excluded.long_close_count,
        short_close_count = public.mt4_account_snapshots.short_close_count + excluded.short_close_count,
        take_profit_count = public.mt4_account_snapshots.take_profit_count + excluded.take_profit_count,
        stop_loss_count = public.mt4_account_snapshots.stop_loss_count + excluded.stop_loss_count,
        unclassified_close_count = public.mt4_account_snapshots.unclassified_close_count + excluded.unclassified_close_count;
  return new;
end;
$$;

revoke all on function private.bump_mt4_dashboard_counts() from public, anon, authenticated;
drop trigger if exists mt4_dashboard_counts_after_insert on public.mt4_account_events;
create trigger mt4_dashboard_counts_after_insert
after insert on public.mt4_account_events
for each row execute function private.bump_mt4_dashboard_counts();

create or replace function public.ingest_mt4_account_snapshot(p_event jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_owner uuid;
  v_event_id text;
  v_login text;
  v_server text;
  v_currency text;
  v_observed_at text;
  v_balance numeric;
  v_equity numeric;
  v_floating_pl numeric;
  v_margin numeric;
  v_free_margin numeric;
  v_leverage integer;
  v_rows integer;
begin
  if p_event is null or jsonb_typeof(p_event) <> 'object'
     or p_event->>'event_type' <> 'account_snapshot'
     or jsonb_typeof(p_event->'account') <> 'object' then
    raise exception 'Invalid MT4 account snapshot' using errcode = '22023';
  end if;

  select owner_record.owner_id into v_owner
    from private.journal_owner as owner_record
   where owner_record.singleton = true;
  if v_owner is null then
    raise exception 'Private journal owner is not configured' using errcode = '55000';
  end if;

  v_event_id := btrim(coalesce(p_event->>'event_id', ''));
  v_login := btrim(coalesce(p_event #>> '{account,login}', ''));
  v_server := btrim(coalesce(p_event #>> '{account,server}', ''));
  v_currency := upper(btrim(coalesce(p_event #>> '{account,currency}', '')));
  v_observed_at := btrim(coalesce(p_event->>'observed_time', p_event->>'broker_time', ''));
  if v_event_id !~ '^[A-Za-z0-9_.:-]{8,200}$'
     or v_login !~ '^[0-9]{1,32}$' or v_server = ''
     or v_currency !~ '^[A-Z]{3}$' or v_observed_at = '' then
    raise exception 'Invalid MT4 account snapshot metadata' using errcode = '22023';
  end if;
  if jsonb_typeof(p_event #> '{account,balance}') <> 'number'
     or jsonb_typeof(p_event #> '{account,equity}') <> 'number'
     or jsonb_typeof(p_event #> '{account,floating_pl}') <> 'number' then
    raise exception 'Balance, equity, and floating P/L are required' using errcode = '22023';
  end if;

  v_balance := (p_event #>> '{account,balance}')::numeric;
  v_equity := (p_event #>> '{account,equity}')::numeric;
  v_floating_pl := (p_event #>> '{account,floating_pl}')::numeric;
  v_margin := nullif(p_event #>> '{account,margin}', '')::numeric;
  v_free_margin := nullif(p_event #>> '{account,free_margin}', '')::numeric;
  v_leverage := nullif(p_event #>> '{account,leverage}', '')::integer;

  insert into public.mt4_account_snapshots (
    owner_id, account_login, account_server, account_currency,
    balance, equity, floating_pl, margin, free_margin, leverage,
    last_event_id, observed_at, updated_at
  ) values (
    v_owner, v_login, v_server, v_currency,
    v_balance, v_equity, v_floating_pl, v_margin, v_free_margin, v_leverage,
    v_event_id, v_observed_at, now()
  ) on conflict (owner_id, account_login, account_server) do update
    set account_currency = excluded.account_currency,
        balance = excluded.balance,
        equity = excluded.equity,
        floating_pl = excluded.floating_pl,
        margin = excluded.margin,
        free_margin = excluded.free_margin,
        leverage = excluded.leverage,
        last_event_id = excluded.last_event_id,
        observed_at = excluded.observed_at,
        updated_at = now()
    where public.mt4_account_snapshots.last_event_id is distinct from excluded.last_event_id;

  get diagnostics v_rows = row_count;
  return jsonb_build_object(
    'accepted', true,
    'duplicate', v_rows = 0,
    'event_id', v_event_id
  );
end;
$$;

revoke all on function public.ingest_mt4_account_snapshot(jsonb) from public, anon, authenticated;
grant execute on function public.ingest_mt4_account_snapshot(jsonb) to service_role;

-- Preserve verified journal data while making newly ingested MT4 closes AI-reviewable.
-- Existing trades without broker-confirmed exit metadata remain explicitly unclassified.
create or replace function public.ingest_mt4_event(p_event jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_owner uuid;
  v_event_id text;
  v_event_type text;
  v_login text;
  v_server text;
  v_currency text;
  v_ticket bigint;
  v_symbol text;
  v_broker_time text;
  v_order jsonb;
  v_row_count integer;
  v_payload jsonb;
  v_revision bigint;
  v_updated_at timestamptz;
  v_trade jsonb;
  v_close_text text;
  v_close_date text;
  v_old_currency text;
  v_now timestamptz := now();
begin
  if p_event is null or jsonb_typeof(p_event) <> 'object' then
    raise exception 'MT4 event must be a JSON object' using errcode = '22023';
  end if;

  select owner_record.owner_id into v_owner
    from private.journal_owner as owner_record where owner_record.singleton = true;
  if v_owner is null then
    raise exception 'Private journal owner is not configured' using errcode = '55000';
  end if;

  v_event_id := btrim(coalesce(p_event->>'event_id', ''));
  v_event_type := btrim(coalesce(p_event->>'event_type', ''));
  v_login := btrim(coalesce(p_event #>> '{account,login}', ''));
  v_server := btrim(coalesce(p_event #>> '{account,server}', ''));
  v_currency := upper(btrim(coalesce(p_event #>> '{account,currency}', '')));
  v_broker_time := btrim(coalesce(p_event->>'broker_time', ''));
  v_order := coalesce(p_event->'order', '{}'::jsonb);
  v_ticket := nullif(v_order->>'ticket', '')::bigint;
  v_symbol := upper(btrim(coalesce(v_order->>'symbol', '')));

  if v_event_id !~ '^[A-Za-z0-9_.:-]{8,200}$' then
    raise exception 'Invalid MT4 event id' using errcode = '22023';
  end if;
  if v_event_type not in (
    'terminal_online', 'order_baseline', 'order_opened', 'pending_order_placed',
    'pending_order_activated', 'order_modified', 'pending_order_cancelled',
    'trade_closed', 'balance_adjustment'
  ) then
    raise exception 'Unsupported MT4 event type' using errcode = '22023';
  end if;
  if v_login !~ '^[0-9]{1,32}$' or v_server = '' or v_currency !~ '^[A-Z]{3}$' or v_broker_time = '' then
    raise exception 'Invalid MT4 account metadata' using errcode = '22023';
  end if;
  if v_event_type <> 'terminal_online' and (v_ticket is null or v_ticket < 0) then
    raise exception 'MT4 ticket is required' using errcode = '22023';
  end if;

  if v_event_type = 'trade_closed' then
    if v_symbol = '' or upper(coalesce(v_order->>'side', '')) not in ('BUY', 'SELL')
       or coalesce(v_order->>'open_time', '') = ''
       or coalesce(v_order->>'close_time', '') = ''
       or nullif(v_order->>'lots', '') is null
       or (v_order->>'lots')::numeric <= 0
       or nullif(v_order->>'open_price', '') is null
       or nullif(v_order->>'close_price', '') is null
       or nullif(v_order->>'net_profit', '') is null then
      raise exception 'Closed trade is missing required order data' using errcode = '22023';
    end if;
    if lower(coalesce(v_order->>'close_reason', 'unknown')) not in ('tp', 'sl', 'unknown') then
      raise exception 'Invalid MT4 close reason' using errcode = '22023';
    end if;
    v_close_text := v_order->>'close_time';
    v_close_date := replace(substr(v_close_text, 1, 10), '.', '-');
    if v_close_date !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then
      raise exception 'Invalid MT4 close date' using errcode = '22023';
    end if;
  elsif v_event_type = 'balance_adjustment' then
    if nullif(v_order->>'balance_amount', '') is null then
      raise exception 'Balance adjustment amount is required' using errcode = '22023';
    end if;
  end if;

  insert into public.mt4_account_events (
    owner_id, event_id, event_type, account_login, account_server,
    account_currency, ticket, symbol, broker_time, payload
  ) values (
    v_owner, v_event_id, v_event_type, v_login, v_server,
    v_currency, v_ticket, nullif(v_symbol, ''), v_broker_time, p_event
  ) on conflict (owner_id, event_id) do nothing;
  get diagnostics v_row_count = row_count;
  if v_row_count = 0 then
    return jsonb_build_object('accepted', true, 'duplicate', true, 'event_id', v_event_id);
  end if;

  if v_event_type = 'trade_closed' then
    select snapshot.payload, snapshot.revision into v_payload, v_revision
      from public.journal_snapshots as snapshot where snapshot.owner_id = v_owner for update;
    if not found then
      v_payload := '{"version":1,"trades":[],"setups":[],"plans":[],"aiReviews":[],"settings":{}}'::jsonb;
      v_revision := 0;
    end if;
    if jsonb_typeof(v_payload->'trades') is distinct from 'array' then
      v_payload := jsonb_set(v_payload, '{trades}', '[]'::jsonb, true);
    end if;
    if jsonb_typeof(v_payload->'settings') is distinct from 'object' then
      v_payload := jsonb_set(v_payload, '{settings}', '{}'::jsonb, true);
    end if;
    v_old_currency := upper(coalesce(nullif(v_payload #>> '{settings,accountCurrency}', ''), ''));
    if v_old_currency <> '' and v_old_currency <> v_currency then
      raise exception 'MT4 account currency does not match the journal currency' using errcode = '22023';
    end if;
    if v_old_currency = '' then
      v_payload := jsonb_set(v_payload, '{settings,accountCurrency}', to_jsonb(v_currency), true);
    end if;

    v_trade := jsonb_build_object(
      'id', 'mt4_' || left(regexp_replace(v_event_id, '[^A-Za-z0-9_-]', '_', 'g'), 176),
      'createdAt', v_now,
      'updatedAt', v_now,
      'closedAt', v_close_date,
      'openedAt', v_order->>'open_time',
      'brokerOpenTime', v_order->>'open_time',
      'brokerCloseTime', v_order->>'close_time',
      'symbol', v_symbol,
      'side', lower(v_order->>'side'),
      'pnlUsd', round((v_order->>'net_profit')::numeric, 2),
      'accountCurrency', v_currency,
      'lots', (v_order->>'lots')::numeric,
      'entryPrice', (v_order->>'open_price')::numeric,
      'exitPrice', (v_order->>'close_price')::numeric,
      'stopLoss', nullif(v_order->>'stop_loss', '')::numeric,
      'takeProfit', nullif(v_order->>'take_profit', '')::numeric,
      'exitReason', lower(coalesce(v_order->>'close_reason', 'unknown')),
      'commission', nullif(v_order->>'commission', '')::numeric,
      'swap', nullif(v_order->>'swap', '')::numeric,
      'brokerProfit', nullif(v_order->>'profit', '')::numeric,
      'mt4Ticket', coalesce(v_order->>'ticket', ''),
      'mt4Server', v_server,
      'mt4Login', v_login,
      'source', 'mt4',
      'sourceEventId', v_event_id,
      'followedSop', '',
      'snrTf', '',
      'confirmTf', '',
      'targetPips', null,
      'collectedPips', null,
      'setupId', '',
      'planId', '',
      'notes', '',
      'stages', '{"before":[],"during":[],"after":[]}'::jsonb,
      'isDemo', false
    );
    v_payload := jsonb_set(v_payload, '{trades}', (v_payload->'trades') || jsonb_build_array(v_trade), true);
    if v_revision = 0 and not exists (select 1 from public.journal_snapshots as snapshot where snapshot.owner_id = v_owner) then
      insert into public.journal_snapshots (owner_id, payload, revision, updated_at) values (v_owner, v_payload, 1, v_now);
      v_revision := 1;
    else
      update public.journal_snapshots as snapshot
         set payload = v_payload, revision = snapshot.revision + 1, updated_at = v_now
       where snapshot.owner_id = v_owner
      returning snapshot.revision, snapshot.updated_at into v_revision, v_updated_at;
      if not found then raise exception 'MT4 journal append failed' using errcode = '40001'; end if;
    end if;
  end if;

  return jsonb_build_object('accepted', true, 'duplicate', false, 'event_id', v_event_id,
    'event_type', v_event_type, 'journal_revision', v_revision);
end;
$$;

revoke all on function public.ingest_mt4_event(jsonb) from public, anon, authenticated;
grant execute on function public.ingest_mt4_event(jsonb) to service_role;
