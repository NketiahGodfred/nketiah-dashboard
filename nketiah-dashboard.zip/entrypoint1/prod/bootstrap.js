import { createClient } from '@supabase/supabase-js';

const config = {
  url: String(import.meta.env.VITE_SUPABASE_URL || '').trim(),
  publishableKey: String(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || '').trim(),
  ownerEmail: String(import.meta.env.VITE_OWNER_EMAIL || '').trim().toLowerCase()
};
const IMAGE_BUCKET = 'journal-images';
window.NketiahProductionBuild = true;

async function startProductionApp() {
  if (!config.url || !config.publishableKey || !config.ownerEmail) {
    window.NketiahProductionError = 'Production configuration is missing. Copy .env.example to .env.local and set the Supabase project URL, publishable key, and owner email.';
    await import('../app.js');
    return;
  }

  const supabase = createClient(config.url, config.publishableKey, {
    auth: {
      autoRefreshToken: true,
      detectSessionInUrl: true,
      persistSession: true,
      flowType: 'pkce'
    }
  });

  window.NketiahCloud = {
    isConfigured: true,
    ownerEmail: config.ownerEmail,
    projectUrl: config.url,
    bucket: IMAGE_BUCKET,
    onAuthStateChange(handler) {
      const { data } = supabase.auth.onAuthStateChange((_event, session) => {
        queueMicrotask(() => handler(session?.user || null));
      });
      return () => data.subscription.unsubscribe();
    },
    async signInWithGoogle() {
      const redirectTo = `${window.location.origin}${window.location.pathname}`;
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo, queryParams: { prompt: 'select_account' } }
      });
      if (error) throw error;
    },
    async signOut() {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    },
    async loadSnapshot(accountKey = 'manual') {
      const { data, error } = await supabase
        .from('journal_snapshots')
        .select('account_key,payload, revision, updated_at')
        .eq('account_key', accountKey)
        .maybeSingle();
      if (error) throw error;
      return data ? { payload: data.payload, revision: Number(data.revision || 0), updatedAt: data.updated_at } : null;
    },
    async loadMt4Events(limit = 200, filters = {}) {
      let query = supabase
        .from('mt4_account_events')
        .select('id,event_id,event_type,platform,account_login,account_server,account_currency,ticket,symbol,broker_time,received_at,payload');
      if (filters.platform) query = query.eq('platform', filters.platform);
      if (filters.login) query = query.eq('account_login', filters.login);
      if (filters.server) query = query.eq('account_server', filters.server);
      const { data, error } = await query
        .order('received_at', { ascending: false })
        .limit(Math.max(1, Math.min(Number(limit) || 200, 500)));
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },
    async loadMt4AccountDashboard() {
      const { data, error } = await supabase
        .from('mt4_account_snapshots')
        .select('platform,account_login,account_server,account_currency,balance,equity,floating_pl,margin,free_margin,leverage,last_event_id,observed_at,updated_at,trade_close_count,long_close_count,short_close_count,take_profit_count,stop_loss_count,unclassified_close_count')
        .order('updated_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },
    async saveSnapshot(payload, expectedRevision, accountKey = 'manual') {
      const { data, error } = await supabase.rpc('save_journal_snapshot', {
        p_expected_revision: Number(expectedRevision || 0),
        p_payload: payload,
        p_account_key: accountKey
      });
      if (error) throw error;
      const row = Array.isArray(data) ? data[0] : data;
      if (!row || !Number.isFinite(Number(row.revision))) throw new Error('Cloud sync returned no revision.');
      return { revision: Number(row.revision), updatedAt: row.updated_at || null };
    },
    async uploadImage(path, blob, contentType) {
      const { data, error } = await supabase.storage.from(IMAGE_BUCKET).upload(path, blob, {
        upsert: true,
        contentType,
        cacheControl: '3600'
      });
      if (error) throw error;
      return data;
    },
    async createSignedImageUrl(path) {
      const { data, error } = await supabase.storage.from(IMAGE_BUCKET).createSignedUrl(path, 3600);
      if (error) throw error;
      return data.signedUrl;
    },
    async downloadImage(path) {
      const { data, error } = await supabase.storage.from(IMAGE_BUCKET).download(path);
      if (error) throw error;
      return data;
    },
    async deleteImage(path) {
      const { error } = await supabase.storage.from(IMAGE_BUCKET).remove([path]);
      if (error) throw error;
    },
    async requestAI(body) {
      const { data, error } = await supabase.functions.invoke('ai-review', { body });
      if (error) {
        const detail = error.context?.json ? await error.context.json().catch(() => null) : null;
        throw new Error(detail?.error || error.message || 'The secure AI request failed.');
      }
      return data;
    }
  };

  await import('../app.js');
}

startProductionApp().catch(async (error) => {
  window.NketiahProductionError = String(error?.message || 'Production startup failed.');
  if (!window.NketiahCloud) {
    try { await import('../app.js'); } catch (_) { /* Vite will surface a fatal bundle error in the console. */ }
  }
});
