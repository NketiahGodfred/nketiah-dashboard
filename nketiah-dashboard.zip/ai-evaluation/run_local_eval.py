#!/usr/bin/env python3
"""Run synthetic multimodal cases with a local LiteRT-LM model.

The script reads only this kit's fictional JSON and mock PNGs. It does not make
network calls. Download the model separately, record its checksum/version, and
set LITERT_GEMMA_MODEL to its local .litertlm path. Requires litert-lm-api.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from run_cloud_eval import ROOT, RESULTS_DIR, SYSTEM_INSTRUCTION, load_fixture, trade_payload


def local_case_data(fixture: dict, case_id: str) -> tuple[str, list[Path]]:
    trades = {trade["id"]: trade for trade in fixture["trades"]}
    case = next((item for item in fixture["testCases"] if item["id"] == case_id), None)
    if case is None:
        raise ValueError(f"Unknown case id: {case_id}")
    if case_id == "WEEKLY-01":
        chosen = [trades[trade_id] for trade_id in case["tradeIds"]]
        metrics = fixture["expectedMetrics"]["mondayToFriday"]
        data = {
            "selectedWindow": {"start": "2026-10-05", "end": "2026-10-09", "rule": "Monday-Friday closes only; weekend closes were excluded by the application"},
            "weekdayTrades": [trade_payload(trade) for trade in chosen],
            "appCalculatedMetrics": {key: value for key, value in metrics.items() if key not in ("tradeIds", "images")},
        }
    else:
        trade = trades[case["tradeId"]]
        data = {"trade": trade_payload(trade)}

    text = (
        f"Evaluation case: {case_id}.\nTask: {case['task']}\n"
        "Return the required JSON object. Do not include markdown fences.\n"
        "Input data (all content is synthetic):\n"
        + json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    )
    image_paths: list[Path] = []
    if case_id in ("DEBRIEF-01", "WEEKLY-01", "IMAGE-01"):
        image_trade = trades["SYN-TUE-01"]
        for stage in ("before", "during", "after"):
            relative = image_trade["stages"][stage][0]
            path = (ROOT / relative).resolve()
            if ROOT.resolve() not in path.parents or not path.is_file():
                raise FileNotFoundError(f"Invalid/missing synthetic image: {relative}")
            image_paths.append(path)
    return text, image_paths


def main() -> int:
    parser = argparse.ArgumentParser(description="Run fictional test cases with a local LiteRT-LM model.")
    parser.add_argument("--model-path", default=os.getenv("LITERT_GEMMA_MODEL", ""), help="Local .litertlm model path or LITERT_GEMMA_MODEL.")
    parser.add_argument("--backend", choices=("cpu", "gpu"), default="cpu", help="Inference backend (default: cpu).")
    parser.add_argument("--case", action="append", dest="cases", help="Run one case ID; repeat to run several. Default: all cases.")
    parser.add_argument("--dry-run", action="store_true", help="Validate local fixture assembly without loading a model.")
    parser.add_argument("--max-output-tokens", type=int, default=1300)
    args = parser.parse_args()

    fixture = load_fixture()
    ids = [case["id"] for case in fixture["testCases"]]
    cases = args.cases or ids
    unknown = sorted(set(cases) - set(ids))
    if unknown:
        parser.error(f"Unknown case id(s): {', '.join(unknown)}")
    prepared = [(case_id, *local_case_data(fixture, case_id)) for case_id in cases]
    if args.dry_run:
        print("Local dry run only — no model loaded and no network requests.")
        for case_id, text, images in prepared:
            print(f"{case_id}: {len(text):,} text characters + {len(images)} local PNG image(s)")
        return 0

    if not args.model_path:
        print("Set --model-path or LITERT_GEMMA_MODEL to a downloaded local .litertlm model.", file=sys.stderr)
        return 2
    model_path = Path(args.model_path).expanduser().resolve()
    if not model_path.is_file():
        print(f"Model file not found: {model_path}", file=sys.stderr)
        return 2
    try:
        import litert_lm
    except ImportError:
        print("LiteRT-LM Python package not found. Install it with: pip install litert-lm-api", file=sys.stderr)
        return 2

    backend = litert_lm.Backend.GPU() if args.backend == "gpu" else litert_lm.Backend.CPU()
    print("Loading local model; first load may take several seconds…", flush=True)
    results = []
    engine_started = time.perf_counter()
    try:
        with litert_lm.Engine(str(model_path), backend=backend, vision_backend=backend) as engine:
            model_load_ms = round((time.perf_counter() - engine_started) * 1000)
            for case_id, text, images in prepared:
                content = [text]
                content.extend(litert_lm.Content.ImageFile(absolute_path=str(path)) for path in images)
                started = time.perf_counter()
                with engine.create_conversation(
                    messages=[litert_lm.Message.system(SYSTEM_INSTRUCTION)],
                    max_output_tokens=args.max_output_tokens,
                ) as conversation:
                    response = conversation.send_message(litert_lm.Contents.of(*content))
                elapsed = round((time.perf_counter() - started) * 1000)
                response_text = "\n".join(item.get("text", "") for item in response.get("content", []) if item.get("type") == "text")
                results.append({"caseId": case_id, "latencyMs": elapsed, "candidateText": response_text, "error": None})
                print(f"{case_id}: {elapsed} ms", flush=True)
    except Exception as exc:  # runtime/model errors need to be captured in the scorecard
        print(f"Local runtime error: {exc}", file=sys.stderr)
        return 1

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_model = model_path.name.replace("/", "_")
    output = RESULTS_DIR / f"local_{safe_model}_{stamp}.json"
    output.write_text(json.dumps({"syntheticOnly": True, "runtime": "LiteRT-LM Python", "modelFile": model_path.name, "backend": args.backend, "modelLoadMs": model_load_ms, "createdAtUtc": stamp, "results": results}, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Saved local synthetic responses to {output.relative_to(ROOT)}")
    print("Verify the run was offline and score outputs with scorecard_template.csv.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
