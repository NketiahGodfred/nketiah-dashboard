# Nketiah Journal — MT4/MT5 account publishers (MQL4 & MQL5)

This folder contains **read-only** Expert Advisors for MetaTrader 4 (`NketiahAccountLogger.mq4`) and MetaTrader 5 (`NketiahAccountLogger.mq5`), an end-to-end test matrix, and the event contract tests. Neither EA calls `OrderSend`, `OrderClose`, `OrderModify`, or `OrderDelete`. Each polls the account from one chart and POSTs observations to the private Supabase `mt4-ingest` function. Every event carries a `platform` field (`mt4` or `mt5`; the MQ5 EA always sends `mt5`), and **each connected account gets its own journal** in the app keyed `platform:login@server`, so several MT4/MT5 accounts can be connected side by side; the first connected account auto-activates on load.

## Agreed behavior

- Account-wide: it observes orders/positions on the connected account, regardless of whether they came from a manual desktop/mobile action or another EA.
- No import of already-closed history before first setup. The EA stores a setup watermark in terminal Global Variables. Orders/positions that are open or pending at first setup are baselined and followed; their later changes/closures are eligible for logging.
- The journal record is created at each close and contains the broker open time, close time, entry, exit, volume, profit, swap, commission, and net P/L. Each partial exit is its own closed-trade row. Records are attributed to the account journal for their `platform:login@server`.
- Balance/credit adjustments are stored in the separate broker activity feed and do not enter win-rate calculations. The EAs also emit recurring Balance, Floating P/L, and Equity snapshots (default interval: five seconds; minimum: five seconds).
- TP/SL counts use only an explicit close label/comment. Missing, conflicting, or ambiguous TP/SL metadata remains unclassified; close-price proximity is never used to infer the reason. (The MQ5 EA inverts MT5 out-deal types so long/short counts keep the position's original direction.)
- Broker account times are retained as broker-time text. They are not silently relabeled as UTC.
- One account currency per journal. The first imported close sets that journal's currency; later closes with an incompatible currency are rejected for that journal rather than silently mixing values.

## Data flow and security

```text
MT4 EA (device token only) → HTTPS `mt4-ingest` Edge Function
  ├─ account_snapshot → private bounded `mt4_account_snapshots` upsert
  └─ other event → restricted SQL RPC → private `mt4_account_events` ledger
                 └─ atomic append of each close record to the revisioned journal snapshot
```

The Edge Function checks `MT4_INGEST_TOKEN`; the token is write-only and owner-bound by `private.journal_owner`. Supabase's service-role credential remains in the Edge Function environment only. The browser receives only its publishable key and owner-scoped read access to the event table. Rotating the Edge secret revokes the EA token. Treat the token in MT4 Inputs as sensitive to other users of that computer.

## Install and compile under Linux/Wine

**MT4:** In MT4, choose **File → Open Data Folder**, then open `MQL4/Experts`. Copy `NketiahAccountLogger.mq4` into that folder, open it in MetaEditor, and compile it. Fix any compiler error before continuing. This step does not require or contact a cloud service.

**MT5:** In MT5, choose **File → Open Data Folder**, then open `MQL5/Experts`. Copy `NketiahAccountLogger.mq5` into that folder, open it in MetaEditor, and compile it. The MQ5 EA sends the same event contract with `platform: "mt5"`.

In both terminals: use **Account History → All History** for catch-up. Use a **demo account**, and attach only one EA copy to one chart on the intended terminal/account. To connect several accounts at once, attach the EA once per account (one chart per account/terminal); each account's closes land in its own journal and appear in the app's account switcher.

## Local test first (no cloud, recommended)

Yes—test the compiled EA against a loopback-only mock endpoint before deploying anything. It uses Python's standard library, stores only a local demo event log, and never connects to Supabase.

1. In the project folder, run the built-in local test suite:

   ```bash
   npm test
   npm run test:local
   ```

2. **Use HTTP's default port 80 for MT4.** MQL4 `WebRequest` does not support an arbitrary port such as `8787`; that produces error 5200 (invalid URL). Port 80 requires elevated permission on many Linux systems. In the project root, prepare a private event log as your user, then start the loopback-only server on port 80:

   ```bash
   touch mt4-integration/local-test-events.jsonl
   chmod 600 mt4-integration/local-test-events.jsonl
   sudo env NJ_MT4_TEST_PORT=80 NJ_MT4_TEST_LOG="$PWD/mt4-integration/local-test-events.jsonl" python3 mt4-integration/local_test_server.py
   ```

   Keep this terminal running. It prints a temporary random test token. Copy the token directly to the EA Inputs; do not reuse it for cloud. If port 80 is already occupied, do not stop an unknown service—identify it first or ask for help.
3. In MT4 under Wine, set the EA inputs to:
   - `IngestEndpoint`: `http://127.0.0.1/functions/v1/mt4-ingest` (no `:8787`)
   - `DeviceToken`: the temporary token printed by the currently running local server
   - `PollSeconds`: 5 (default; the interface itself polls the local server once per second)
4. Add `http://127.0.0.1` (no port) to **Tools → Options → Expert Advisors → Allow WebRequest for listed URL**. Attach one copy of the EA to a **demo account**. The chart should report `Connected` after its `terminal_online` event is accepted.
5. Run the local-applicable scenarios in the one-pass matrix below: transport/auth, account-wide capture, close/partial-close, pending-order lifecycle, balance activity if available, reconnect catch-up, and idempotency. Skip **Snapshot safety** and **Owner isolation** until the cloud demo stage. View local records at `http://127.0.0.1/events` on the same computer, or inspect the JSONL file. The server persists event IDs, so retries are deduplicated.
6. Stop the local server with Ctrl+C when finished. The local file is ignored by Git; delete it if you no longer need the demo account identifiers.

Once you complete these steps in the actual MT4/Wine terminal, the local pass exercises the EA compile/runtime, WebRequest allowlist, JSON body, token header, retries/deduplication, and local event mapping without touching cloud data. The workspace's automated tests validate the mock endpoint and mapping only; they cannot verify MetaEditor, Wine networking, or the EA runtime. The local pass does **not** verify Supabase RLS, SQL transaction behavior, or deployment. Only after your local demo pass succeeds should you follow the cloud steps below, generating a fresh token.

## View MT4/MT5 data in the local Journal UI (no cloud)

The `/events` page is only a raw JSON diagnostic. To test the same demo events in the Nketiah Journal interface, use the opt-in local preview bridge:

1. Keep the port-80 Python mock running from the previous section.
2. In a second terminal, from the project root, install dependencies once if needed and start the loopback-only Vite preview:

   ```bash
   npm ci
   npm run dev:mt4-local
   ```

   Use the `Local` URL printed by Vite (normally `http://127.0.0.1:5173`). This dev server binds only to loopback and proxies the preview's MT4 read requests to the local Python server.
3. Open `http://127.0.0.1:5173/?mt4Local=1` and sign in to the browser-only preview. While the page is visible, the local account snapshot refreshes once per second across every CMS view; the Broker activity list refreshes when that view is open. The floating account strip shows Balance, Floating P/L, and Equity in the account currency. The Broker activity page shows closed-record, Long/BUY, Short/SELL, explicit TP, explicit SL, and unclassified-exit counts. Each partial close counts as one record; these are not counts of currently open positions. The broker snapshot itself is generated on the EA timer (five-second default), so the UI poll does not make the terminal produce new data every second.
4. Closed trades received by the mock are appended to this browser's local preview journal. Visit **Journal** to review them. EA closes imported into the legacy manual journal before per-account keying existed are migrated into the matching account journal (by `mt4Login`/`mt4Server`, or the sole connected account) the next time the app loads; hand-entered entries stay in the Manual journal, which is hidden unless it holds data. Source-event IDs prevent duplicate imports on refresh. A currency mismatch blocks importing rather than mixing totals. Open-ticket baselines, market/pending ticket openings or placements, activations, and cancellations stay in the raw local log but are filtered out of the **Trade and account activity** list; other visible events and balance entries remain separate from trade totals.
5. **Multiple accounts:** the mock keys every event by `platform:login@server`. Connect a second EA/account (MT4 or MT5) and its closes land in a separate journal. The first connected account auto-activates on load; the Manual journal is hidden unless it holds hand-entered data. The live Balance/Floating/Equity strip only appears while an account journal is active; the manual journal shows no broker strip. Only the active journal receives imports and syncs.

The query flag is opt-in and works only in the non-production preview. Local snapshot polling runs on every authenticated view while the tab is visible; activity-event polling is limited to the **Broker activity** view. This flow sends no data to Supabase and does not change the deployed site. Use a separate local browser profile if you want to isolate preview data from any other local journal data. The `/events` JSON endpoint remains the raw diagnostic log, including hidden ticket and cancellation events.

## Deploy once

1. Confirm the existing owner allowlist row from the production setup is present in `private.journal_owner`.
2. Apply the owner-ingest migration if it has not already been applied, then apply `202610130002_mt4_dashboard.sql` after it. This adds the private live-account snapshot and explicit TP/SL/unclassified counters. Finally apply `202610160001_multi_account_platform.sql`, which adds the `platform` column, the per-account snapshot table rows, and the multi-account indexes/journals RPC used for several connected MT4/MT5 accounts. If using the Supabase CLI, check the migration list before pushing:

   ```bash
   supabase migration list --project-ref YOUR_PROJECT_REF
   supabase db push --project-ref YOUR_PROJECT_REF
   ```

3. Create a long random token locally; **do not send it in chat or commit it**. Set it as a Supabase Edge Function secret and keep the value for the MT4 EA input. For example, in a private terminal:

   ```bash
   TOKEN="$(openssl rand -hex 32)"
   supabase secrets set --project-ref YOUR_PROJECT_REF MT4_INGEST_TOKEN="$TOKEN"
   printf '%s\n' "$TOKEN"
   ```

   Copy the printed value directly into the EA's `DeviceToken` input. Clear the terminal history/clipboard if appropriate. Do not put it in `.env.local`, source control, or a browser variable.
4. Deploy the function:

   ```bash
   supabase functions deploy mt4-ingest --project-ref YOUR_PROJECT_REF
   ```

   Hosted Supabase Edge Functions provide `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to the server runtime. Verify those function secrets exist in the project; never pass the service-role key to the EA.
5. Deploy the updated `mt4-ingest` function, the updated `ai-review` function, and the static site. The dashboard loader reads the owner-scoped `mt4_account_snapshots` table on all views; raw `mt4_account_events` are loaded for the **Broker activity** view. The cloud CMS checks the account snapshot and journal revision once per visible second, plus the activity feed while it is open. This creates recurring database reads (two read paths per second on non-activity views; the activity view also loads event rows), so review current Supabase usage before leaving a cloud session open continuously. The UI cadence does not change the EA snapshot cadence.

## Switch the EA from local to cloud (only after local pass)

1. After every local demo case passes, complete the deployment steps above. They create a **new cloud-only token**; never reuse the local test token.
2. In MT4, remove the local URL from the WebRequest allowlist if it is no longer needed, then add only the project host:

   ```text
   https://YOUR_PROJECT_REF.supabase.co
   ```

3. Update the EA inputs:
   - `IngestEndpoint`: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/mt4-ingest`
   - `DeviceToken`: the fresh cloud token from the private deployment terminal
   - `PollSeconds`: 5 (default and minimum)
   - `MaxEventsPerPoll`: 10
4. Keep **Account History → All History** selected. Attach one EA copy to one chart on the **cloud demo account** and confirm its status shows `Connected` before running the cloud demo acceptance matrix below. Do not use a live account until the demo pass succeeds.
5. The EA has no order-execution functions; there is no reason to enable trading permissions for it.

## One-pass demo acceptance test

For the local pass, run the applicable rows listed above in one session and keep the terminal **Experts** and **Journal** tabs available. **Snapshot safety** and **Owner isolation** require cloud and belong only to the post-deployment demo pass. After local success, repeat the broker behavior cases on the cloud demo account. Inspect `http://127.0.0.1/events` for local events; refresh the app's Broker activity feed for cloud events.

| Test | Action | Expected result |
|---|---|---|
| Auth/transport | Start EA with correct token and allowed URL | A `Terminal connected` event appears; status says `Connected`. |
| Bad token | Temporarily use a wrong token | HTTP 401 in Experts; no row is created. Restore the correct token afterward. |
| Account-wide | Place one small demo market order manually; also place one through a separate demo EA if available | Both are captured in the raw event log; no magic-number filter is applied. Opening-ticket rows are intentionally hidden from the Journal activity UI. |
| Open/close fields | Close a test order | Exactly one trade row appears with original open time/price, close time/price, side, symbol, lots, commission, swap, and net result. |
| Partial exit | Partially close, then close the remainder | One journal row per broker-reported realized close; no duplicate when polled/retried. The row P/Ls add up to the broker's realized result, subject to broker rounding. |
| Pending lifecycle | Place a demo pending order, change its level/SL/TP, then cancel another; if appropriate, allow one to activate | Raw event log records placement/change/cancel/activation; pending placement, cancellation, activation, and open-ticket rows are hidden from the activity UI. A triggered order's later close creates a journal row. |
| Account cash activity | Use a broker demo balance/credit operation if supported | It appears in Broker activity only, never as a trade or win-rate row. Trade commission/swap remain included in each close's net P/L. |
| Account snapshot | Leave an open demo position while the EA timer runs; compare terminal Balance, Equity, and open-position net P/L to the dashboard | The account strip shows Balance, Floating P/L, and Equity in the broker account currency. The site can display no fresher data than the EA's timer interval. |
| TP/SL classification | Test terminal comments that explicitly start with TP or SL; include a comment containing both tokens and a manual/unknown close | Only explicit, unambiguous labels count as TP or SL. Both-token, conflicting, and non-prefix free-text comments remain unclassified; close-price proximity does not affect counts. |
| Cross-view refresh | Keep the local or cloud app visible and visit Performance, Journal, AI, Settings, and Broker activity | The account strip refreshes on every view at one-second browser cadence. In production, expect recurring snapshot and journal-revision reads; activity rows are fetched while the Broker activity view is open. |
| Reconnect catch-up | Close MT4; close an existing demo order from another terminal/device; reopen MT4 and allow account history to load | Closed order appears after reconnect. The already-open position at setup is included. A change made and reversed while the EA was offline may not be recoverable. |
| Idempotency | Leave MT4 running for several polls and restart the EA once | No duplicate trade or account event for the same event key. A new terminal-online event is expected for a new start. |
| Snapshot safety | Leave the web journal open, then import a demo close while also making a harmless journal edit | Imported trade increments the snapshot revision; stale browser saves must show the existing conflict path, never silently overwrite. Reload and verify both sets of data. |
| Owner isolation | Sign into the app with a non-owner test user | The user cannot read the broker activity table. Do not use real credentials for this test. |

A demo broker may not permit balance entries or every pending-order scenario. If a case cannot be generated, record it as **not testable on this demo**, rather than inventing a broker event.

## Known limits and test boundary

- MQL4 history depends on what MT4 has loaded. Keep **All History** selected.
- The EA polls; it is not a broker-side immutable audit feed. It can miss multiple rapid order edits between polls and cannot reconstruct edits while it was offline. Closed trades and balance rows can generally be caught up after reconnection if they are present in MT4 history.
- Some brokers re-ticket the remaining volume after a partial close. The logger treats each closed history row as a separate realized result; verify the mapping on the chosen broker's demo server.
- Linux/Wine support must be validated on the user's MT4 build. The source can be syntax-checked here, but only MetaEditor under the actual Wine terminal can prove compilation and HTTPS behavior.
- The repository's automated tests validate the event contract, trade mapping, idempotency keys, and the EA's read-only source policy. They do not apply SQL to the live project or emulate the user's broker/Wine runtime.
